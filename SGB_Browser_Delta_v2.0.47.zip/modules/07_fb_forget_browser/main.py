# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: modules.07_fb_forget_browser.main
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'modules.07_fb_forget_browser.main'
    _u = "5GAWt`zCjZ3<+5^Iibcu"
    _p = "QkN5|S>>ZRv4-7@hvEl?;ew)#<>wMM6MhITi-RR(!yh8%WUJ;e<D48V5;=qP$qsZ@{R$#8`@c~PB`Rz^r#?~kO8~D=7+WZ3)u`o)XooHhmdldiDy;t$)cwzBz+~oNxEl@Zu=8#cOs-f6f%O2digQ&n5r2*$G#o*vRIy{dhhHumYa1KVlJG#E1I(JCNA3NWODQ7S)XDP!htyTjcky&3(2*8MX<mL|h@Y6~NFlHcdSGM+oBD};o3Qs`U3`(**n5L5Q$Zy~qgd`@y`b{!y*=tiL8hGa_gTwsV?U^n_k@V2Ew;E=VAslL9zPOR-k)~vgNo9bLAox+w;6rnY!x|MvRoM%6l8xyl9z-*f@v(MEfU<l^rH0H2_-~yb1(gd0MtH>%kgng=i@gHjFoI%-8Pf"
    _t = "57f07f6f12e3e02ed389ea0434fd148748a7139b835f370dc3c19cc3812425a2"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
