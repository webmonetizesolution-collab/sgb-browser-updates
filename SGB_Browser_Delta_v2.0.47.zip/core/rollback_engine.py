# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.rollback_engine
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.rollback_engine'
    _u = "uDDPwS+t$d&|aE+CyB*$"
    _p = "GsOD{wl%Tl4mj51VuZPa%-MW|Ku6eB_IkMKhuGi>bT*-V4yWy=3{mDapP)1~({M&v&i{+GQ`Z=rXWNt@o+L$s4$=>CQE+4rBQlF&)@?TxuGXft;7@;>lwU`;Nj+m0+AvQZBmn~?+eGc0DUJ#E<J2k$B<UQ~2udw_x2fV`NtgPQ-`2Dx#lPxppII=&y^Bj8$|ZdQSE>Smi4kBVe6BXYj4slAW1jo)QeNnDj>4XZO2xPlmz0^@07H$;a1IzmqpV)$a5a;GFa7+lm7W%$r@TddFz|60Fy_l|AO|Bw?n3k~;W974k{puRH5y#5SAcL>HhmsFF82&e$SQ*5i6n3AN@dM~wQr7cIR<*%QYZ`)ARhY!=%->F_!*4>P>mQ5a_v#k#iV`78}riUis}6R95>VvNrNivV!K=PvY;ivRCncjRS5Rhv)z0}7JIGG49HBNkT|gy!XZxFEDqI(n^c9>AI180{%^2fi};OULGjsEg@=eFP3Zx(lEWIV;0exPZ`T10xxpltLzn~b369B<zxhHc%yzRN|HZ#KK3)7~R&ITB2SGVrD{f3?Bgi|5E=Y9x*H)*-X5tw`F<vYy?&CSVJ2T_(e$+FNZCM=NFj44bh1xj@+kjxC$+ozS@?#ncVLgdDRRvS2Xkus8%+~|Q_WE_@wJfV5Q|+oZz|XV^an`LihwhZFBdA}%Dg&)4!!0M}d))@2lIlr~cch)q{+jioDXnq_%T_%-lEfa{aE0n*&lk}UyeYhusJMe$FHw-FwPsAD0jRtdgf?HweFUFQi1eQ|y8hMP><{%HGZr?mVn-HwL-uEae&xm<h6Wu1GDPO*mdY$1&&G7&kuU*bNM^qa*asO8IP3se_-UL5VZYrsh(486C+&kmie1P}MXywOi59ob*kAQg5lxo1j^LYmdFn%=!NX^TH8PGJv|uwo2E>RP#rW)zf9#3bSKB#-gfXvuG+CMnWjP!o?pE~j&B~y_WQ9rwH<Z%6!-&D4?w}QQNk9FAsNihv41bIfzDJTPEwxqSbLqW_<3}!Ztkz_DLFG!QSjuboya9lyhN=Ro00N0>4Dvz<xDkE>S2I@9rsS^;bZq=I7@6jDO>j5t;Y#Dmr)jdYC`lTRHwYte|A|S)Fqn<{pW>SorF821hgTn_Njea)OO1*czAly(7u>bLcZ4PdHS-kexhnLbCtt#wy=p1zt1@alP#gY^Lri1aUazFANQyj#2K3CXA7wfc!Y0Yh<w!i#b!uS>4t9rF2ggBbe8BbWmY0y`&4x>DuxN<!aD3>QUZ&YOXOC3SvqhVNVZlE)=oz`r(0?l-miJfBz`iaY0LpY-)mDHg3e&S<F%_XoeEs)u0!N$gy$Wf>`UZndlQ2ENCMQ~|!jkD}VlQqV@>z@E;6>yWZXFj0In3N_K-OQ$5#wQysEUncq&UPAKHkMp>^pc<*%E4f3kc4r-=gXMc@Mn0*k>FeL|aFWx^#ewPy%9DT}XxfG7br%FwETjA3C@>Iue~**JRQw<=rLOfwya)8IRWh`T;m{cb(P-*vYQF{l2A;-QnNs4s0{IiSb{uPT=v!ZRS+F4w5$tdu-?^>{)x!;wu{x5MgLngTyR}^>g1fDtZcXF!c8d|15jD7573*Vt|?rx1U>(bM@VCVLdqerLa#puF?^ZrXkWG%3q&LH_2~5e;S1$)$PlWMhf5$3-}4(v)GR_&13{{fi(V1+qy*Jvm;?)QMA=(Y8$AQ3M@LY4@jTU+|jM61b9!dmD0ZyA{6jNd)V!+VN|a#8>{k~Sm76>J?0i{0vUHN>%ed47FG0pKOL}sydp&MxZr-j8JqAJjl?vmMZnfJSrJIS0O7#aBMz4WER_Gpq1zKaIkJX&iGGMey9-x+5w54>EO0Ln3K$wCL4XJRah~bP1o<8Eq^l}3fx^mO69m^z(?i`vE%d{oY#?3"
    _t = "93cb569866215f8765f42c8d4ae8fbab421a424e5c6a40316464bd4cd624b614"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
