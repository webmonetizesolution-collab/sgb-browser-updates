# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.license_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.license_manager'
    _u = "2mvNPh%T=Z)cL0^4E7Sr"
    _p = "R45w6X+Ku}vU6e{Kg5$Q6h#ijo;#08QE@A>2(U)JJ?Y#VV)cc>y(_5nmr3+RHiu}{_udfEAxf34U?sqaz+wL133Jy<)AYEv^O{Y{pH<iE$4(aA>NBA)9b#SwrWW7;ERTYi=P3hsf+g8%gHyOx0u`3R91EzIJ0o!K?ZyYrT}A^`%^^y_eGkeo45h?l)+42NDA`(C(-;Dl^;v{hPScaFu(&7TG<h({)ZFYiUIb+Ns)Bfi?5M(<vmj(rJX<l_V;o-*g}?)Y5eOk>=+<xQ(j1c00Bj)##A%^GkzJcAWtjQ<g7991>_)q87wi{^8Fa^j5B`&A<H$JX6xE<<sKuQfgSu7uX)dh#>&l#a8QvVRfO`~YoXyeIEGT;uxr@jz=ZVTSFOhF6f^mb0_xls9(b>N+E^;@+n)El7q4_I*^xDwSv@coyz076#SW4#V-vA8UdH)TXn|zf8S!n@PWQkCk|1uUf5=VOEpMOO`dp5M24FW1zu%Uq&ygJ~}7tqME?+$syffQ#Q+)jG}-Nh3<N3Xj_B>IeB)vJ>(VL>SwUyEGD1t@pj$}hexFMz6lQYpwci~7q6U;m8G_3S|jIN~{il%u)UJ))K+Culp1q-|alqYpe?kR+@I_m0ktZo^<w`5l0mV^fY;h-wnHZ>}krQiX`KV1qK?Z=~O|57g<5nm^|iS_Hx?<oC42FLO+jC>~c@W=<a?z`!{N1{9pylzzn?6BiJ3$1!3%LYM&0SIrA4{+}q#=1O0~nm0993f&W9xR=2gI}Ud}6ups1*hulARtBsB)0vNby*fp(k8${2KBplW4gj$Uv0iy1Hft73c5sowSV2z<bH+4Ec7x5}mu(8}l{joz@VB`Fe6w~_jtf?$t2J9d60(o(ZVs(VlmlMzNgLUEws)N0V8KzHZfAyr<2d&6l%Tt5FsbL9w>;*69tx8<IpV|WxkUii9`98>*g0D##b`8mV|nc(6eYXZ$GwV6Fu!;@mOmU31f4Y~U(>)H4JL`sNYA?p&qF;qK#$Q%_UD60_E6UuOPurh{$S2oPxLnvFuD5;p{x)}abp=GaT7PQm2YqE*>-m@kenEXGr(6?#xCQ1OC7&|MIhZoc^p5od3#vEN^AF$vbI(&(O9L&eKqh|P(tia1IJzEx*S3E%`$oo_RHg1V7in*>#?3dJJD;mj&6G@giGe)vQk?wvnX*RDGA|urxzT0xL7c9+vF@&Ioctt7>L19R9t}LYsxNxic<g;0*NtOi=ZU{XobTMo2D>=lt}c#COS<4+O!xY*7!BV5<Swn)`vypg&>0`MdosM_NhN`jT$A?vcokB{<y3nj53{JnfzBk<~$GL(9c|jQOSx;?B24xK>$8YXeCCQkJCySCPMWy`^g$}^3`Zj5|l(@FpP+3;WvwFc($}D!~=JYaqt%xTMnkc(5YK8wB|xDYZEOQbx{N+2&!8UgQV)gm|nR92$n+nhRLpbH}3kN)%o-v6N;Js&h;GFD$kXC7ub&toD<OzTm<hCY3|vtYY1**xO_jo!wY6&$|_IMz$T9JHej!CV|57TAU-kdMggbH;@??ZPW!DqaIT5%xChaY>If%Ok-u=&B#$F;q%4^#O`J5QXTSSX9NZGnMHBb$g@||>&TQ1Wli+9=gDWh!8eJ%^a@^CVf&LH>8Kl%kcLYb|13V$Z&;D~dt#ve9rxsDSh65Jq1^k-!Z648`Se{)6oq)CM^RJG@0`V}iTVzB<`M~gXK8HHgmR|<$XSRx7N#k^~Hmf@X#f=*Hl-}}hMOFdd>|>GapE*I5UUv`CbOs>8vP5sD582>t?Ji3~vlO_juy-v`Ga&3kR%osM#$F5I6gUQS|2-Zoc*A1b_DrV)oxhM@%#aGhUM4YhiHe;nG3F4WKH}=aPPILfx8t(wELGNE1qP|rLXOL^X%KqGBH>Ai_Ib`@Eh{qCrI84+5&*4t&Us@DgLoj$`B<?kzX}EHf7B(6-$QH<%H5?inK|Jq19zVr=wr)NSszsBy2<{mU>fi<KcE0UVpla{Hh$Y@^2O-x9-08l`4A2q2r6%gbna!u=a?o<oytzYYUsM{66IIk$M*ZkB;?>ap=WLjs$LOefvicvp372z#DApFh~wp9ClnO?<)!|#H8wy$!wZtCc&2aww^e^&facsM<HDBOKnMPi=WMcjObXm(H@~=hk%N|)kQ}V@G5X|>6$R|CYE=>a?gS=W^xy{|k6<o;80iU)mtq`&96F^?=_kAO@)lK#lRSADk$)cc7VhG}Ru^K+jc@pHc(@Z*23Y}FN$%GdBf^Dk*awQuHMn=4D|y)yqWk+ElQ&_5>P@Y!<?7;aMF)@|LisPtZZpT;X??N^NR;}2?>nDcbL+=e2fjV~(PZ)JH2?TcIE^Y!Dt*nPsUW$nK~hKaLf)`WrZeiYm1xC1Mkb$=SONZD%ibw|%4zO^Xrnv<+M$ge#gLo|{zd5!c~3!ly2KWDU^F}V{q<}YCAaL-pcRjm>`7|rtuwBN`=~QEL!M|da57^v2_zI7i~&|=LfK82WZ@J+TSJx3yzt^yzp20S{tC*2+-5)A_3_K}x_?Jm>=}uS=<k=xc?5dI%c+@MKc0$<mG%tIm*wM-Hr69ymj)XLOuI<>*XpyNLjm&h6eUbb{&s2xNfTxrkice_8lq>1{^71<SoAvUG1!7|%|<R5Zj%n5n2~!zaErJENQTq?UMyn)G`BWuZWkUV7m!<`%GW<gfEiu%Tq!!UZUz5wo}oQ=$3V)KgNu_6&-hK>u`-@++K4>Y>}c##tv+=+=W-g<UBrV?&m@T-cQQuRY|<fRan1C@z4glNO{bL8&s8(0lKJtP`j8lTYWvEoC684ni|=x+Og^T++thML{$+yoG1`$*j<m}twK6#^J2FaUpa+Ci-KWB+sGUZw;0C}O0P)j8Yq?^|JA{TH"
    _t = "be4f6e7c18338d6f8ceec63ebe3562be762cb5cc1522265b31b03172c96072eb"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
