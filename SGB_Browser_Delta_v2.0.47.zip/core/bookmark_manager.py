# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.bookmark_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.bookmark_manager'
    _u = "syQ2$4p0#{I-MkJ-AJMF"
    _p = "2({(I1gDuO)c=B-OO3nt^OH*Q^-~Sg_pmhKZHAKK#j}W39u&|Gmb~?)aD}1w@Np38!3;M|g+~zr794hGOq=ZWl{yHrQbxMtao<E=pZugiDGp8=*59i((16d|Ri#r;mv4gB`kY7KzC|pY5f$WL6uXBt@`s%-JYv7Q48xO5(d~+>2i7*hbYVH!$5YzZbMym+O`ur%CQsG0@lhFPK>?GbZB}QYEkc8v6(FS4y#{t+fkg=@jd!39>Y}&kS9P?G3OAAyX6}k&W>QBi1Y1a*hP`LJGE*J^=57pc`v6z<;BpfLR5|7pNdth?<CZ<~51(q^Na9qjAw4p-k}oYJLaS`GqXc5dVd$We%LM(6hxuZS@hdJTQK<(DPJnTmgrE~vT^-&Nc&vM+rF55l$KI6Q6+vzY1mYDj1DM4`U{37aegP_O{Uun5?>)UHJ`<a_#)oG3HY5kE7&{N@vgTN=J(){3D!Ayg-ftzW4!gA9fOEJ*3n4+Wz^k*IWwwPKY&(dfOe)qp?UJ-MOp4B$Lssm(^Hf^bNC&j`6Fl7E`=vDbq!6o<Fn@@Wu4gydwkNko4aqX;kt^U%qAiq+RVe;^1gvh*7<A*v{Q1k+sHO?Bk*<z^4WD%EN#kW9K}YE!88M&pZHhf+hM_+eZ=W?)0}KpGQ}m@eM))D;zfe28T#9%w=9kArS7bD9))UX?P5Kc%F1w}K0X|U$u~v7^7fuMPVPGOxo*CgT_D-r8xR-mMuKB-Id$$j#Z8ftFww*!+J<IQOiN5On8Qr9Y7H}E$TASzgp2BlrTEL_*Sw5Us9oCk&a0ad#E-!e%<p3R)E>_s#+f!hkd{y((MtGchx?|bLYxI-|+k+;$HY<NJ?dcJLVyQG>6{w1^5MJow%xeM5)G=V0HGAXPnxF9N^;5Pvt*-lYbp-<fu8&p5paRlbXB2h8*2!v_qyG#v$D@>PXgpQAl1E=LlW-*(SDvlGtlyrMM0yxF&Jl*c3w1WCg}0UHX+9m>f~NbPC{Eum!PY%%)t)Cag%@`(Q=(+h>28Z(f>5O9%1@YH2}FUc-6gzWI15N=x;aDdc^-{hoLsc6RTO)YHAl00W^oge6r%+E*4~8`pnY;4o^He?q{X3Gl>kbIp(|(+zS`*+pb1UT%d&xEyPK<C%fJ>*78d}eb!8wTP&NqEN<}%`wF-3Ig%ulgJwo*r3=U8g>H-R6i9G^LN)YHi*Ozqnp41$_G=#vY9S(rKSd@DIo<9~&*i9u*Fj%F-#wa7O|5{K6D1$yd&~ScTou-J}|J39ILaOV+aVvoPXQY~TmB*-Z=EqQ~ZD_&xJWNu!)oONeC@7&y3t;gxONBq0Y_XH(C14D^>X5D?ZPU~YNWPcUol)_^wCAHU>dtE3-#_Tl)2SYY@#B;ZJAfKn$bN^GJiVVMB`q9X-mT86$m$MF)0B>tW9GSxCe7T4+}f|KrGA2fdVdtSHBu~c<uy-)A*07oU1NvW@sllE8Fph1TN>4hB${DGQ8%;_h-H)pAONIyv=l(6Dv*UbXR30A`S1w-jYyDpXJ@|o5!%AjQYgU;mn~$Ua0Y%#Tw1Y{d$SJnRmb*Zo^>tH%O(lE-D?RQRX^x0Fn*YjA->XgKaMa#<#6hG80tk77nJdJ{EH-0*MGJlHlt(`0+#LFTBII^2rIl{Oq1H=)P8*+dJmQqQW`;uquzud#Ur+kLLzY3^xOU@SeI|(+GHXjoG%=)1o%XGBe^8QAM>hZVf@YyCMB8JeQ=bRnH=hk{3@Z&dA)QWXxG`k+I548<IrtIg2L4UfGv6B@I+f`ZG-W$(>yG6BxN+Ao)gAisIBgVZF<;R;3YK+5zUd+e;%~L6J*$?>0Glx?MkRrxnr%Agfv5giJZ^q2rIeQ`fAnZT@H;wE#8rgPOO8J4?`%=a^$n_Zc^M@TR12!4$Ul@(Kp3Udw)H&fs@k}U&XYHvfE;!ue)cz)jiItFHJqLE{q=S*JAWBT$?dc?^@pLLscSpa3%GhcE*P8)~kF#4X(&F|1>Rgf?jtU?s3}EvsHqvXt6k{-uSjuREd6yKO%IdwVfh}YREYmXH>EiUL{je=o7Dep{##JxrPIAIE<b|eB7`wF=u1jy2yQ&-^w-W<+Ry<7hVzyM!#t&wTVA*UH`|t<z-t#n_lf-V<hUtNb``7nTVq+Uq_9>>H%s}ntEcgaRO6A=ukw^;;0ywm+0PF%wPRjiIE2HAzgRf0Z-v0<@@{VLMyGQ{}|*AXwzh1<ZNC4p!r#ZN3U*x2>IztoCG-L`RF~B(;>@2zlYG$w9%(Qtl$i@8i<vO^fkg9yYU-927I04P-cd_V>m)sw6`!^`h<}b!6LZ4#<CQonboq^(RSjkK;~CBJc-|jjXzS_^yHS01Cf?#yiu|58tsjX%^-bFXy)3kjjl*TxDj0Pr3AQCzG%cVcky|O7uIZ_(w+jFhCNk>oP;TMo`FWKcvS!4cC!A2Cc-VIG~^#+Vvj@Qhd2S>-Eu3%%{w(kRika8E;WC6<ENuS3H4vC!tK)%w1+H&B~K#b7j&ToRsx@ezv(M<v@U0q#Y76l^^JFNMmR3s(&0p5^pxQ2QeD9ETqTLh9?B#XH7o~;VZr#T^kgn3uv{pFPJ@|TCV@Lnl!zKtE$u8r`pUEf#$l%sD<*92+s1?BMH|$F*_Yd{SaAheSRu>%F`e04V~m$81>AehzpM*XeVnM_IPymfey!YaoS=?;-%>QxK0UONA{ry69BE@#tV`FzCXiV8G+bHFYx?%MSW619CTGbhYf%{Vg?+Q`gCP4uiadR*k~=x833V|DPuEZBH?1R;D6Ht7S)I3fr|RX}#)UwP8vFXx-bXR#-hY@$xXP#JnMvS9tu}RMg2OTd=qb4%AfaBREO*uM(NlKgmwMGJUSBlrnfzrS3vU-7B|QR=>7*1WZ;?dB1>TS7jPNFTx$%#bxSEJU0gpgdHO}NL4d2fn@`4IiQ6@^Y<G!Hf6e`DWcQW7LK``BSzcGP8?YqhH8k;hEI^7;54t9lWs%tml%T4xqY<=Jso2Iai6wd)~yz+I6ciuSP3F3MkD(eHzgi7SJza;mSI9rb1H)T!DMwr+M9}O6((rhlZxg%TI)&6f1T170k_vC+b@+g5<{&K%ngLr^aV}k0v;Fv7UF1Rx2c))N%KQ7r-ejrB*WE0YM)L?H|4QVDv%+JEVu)S5Uq}U|@x&X&hXX{P#Bzv-rx@0f)@NH`Qm9}|26)*r^^gJ~Awp`K5K?wrjmjEGwYFd-9i~W;Sar2VEA$Zb~FP~sPz8HN4*AM5q5t2Nc%fwJJU$Sgb5Ac?UDBp$4YlMVYh8)kN$6`%ZKm<5Hxj@nj_TW!gCac}^<<@P1)0SDC*8_DwBmyI!8Th%fylstf2|ne)N#&Pxx{>{I6fji^8Ot!uSCM9G<9(oQN9-e6;251W1moUpJ3*oFYuikkf1!?mMep%OKK+-D4*Bx&FU?(_C_0q_+ys7<emoxnJsk|rN*3bD1n7CBxi#fAVjNUAeE)bJ01~RMf+-PJ8YI+Lo(gBW>?Jc9EG-C>5)*S<%u>~uCL{HN4fmY"
    _t = "a5a9944958d840a7672586a603a8a7910e784bf7fc53316186323ebddd5ad3ab"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
