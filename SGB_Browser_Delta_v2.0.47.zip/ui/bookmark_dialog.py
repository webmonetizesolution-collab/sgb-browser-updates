# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.bookmark_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.bookmark_dialog'
    _u = "dZxA$k}Y6hrtQxWp+Pey"
    _p = "L%fg!t=I9dUUL*_O)ouGl=c<uti<POlCr^*1lWYzh8U7YPtc)KcY!30_jbia1^l6JY09ou0mw#gzF}<I?y9H!G-}?f(o)l!ZWbAe$_QB~PEBs`4!L8qlQ;4B>rD<cdST^Vrmj2^RfJ)Sn`W1ZIo(%zQ+M*6t>UV*$6Nbsul|8FEX-7%lvxA}>>}^YKXus=Rh51gwIO7FR@F$@qbRU6<dg;3VZT3>s(>7Ky8t^dS}G8_Gg9aaDB$jRr@0nxI)nyth0tplw8c$KOQFc3NP?fD{`gQo2!gC|MvY(NtBT!mANgg<dIA|1Cwt(<&dMDWlE!oLgh%SXN`vDkOcMaZx9oAg13b~GAHM!BOVj^38%P-6O7<*AMoK{2=%JX^K`Tq<*-H1c0<=`(>FtX2#A|ns01E$~FN=2|=dVl#jKbF0&XGdR#ttDTi<ghE_B}gf06UDVg>g-8>1-u&THo5YMBBcOF8=LUEPbypXA%x=TQPAWCI{q$p9Z{Mj&aMHxs>j-oevIv;jF@Z!G$J<h5^>Q9{eO8JQ84nLegT5tym?C{g_4)uq+F(GZH#Sza*B5!t%B@hR5%cOzM>P$zAH&EMaj+69*5MWTg~gnSxQH5{X1{OD>sj3kSx8Kt0oP3^d&PFS+H&*VZ(rJ(Zq6>a}K&mA^}!djM12e<lWp%Q~+m3)7xo%l-=;Q@p|dW<)(4>>vyd({?thjFsoy^IY6-auE0{VyhShQRW9^4HQ(9Cvy2`NJg&~keuW{C@}1E(DtbEPjn0rU&yH<Y9|63zPHu90)sB<%qC9dAo0lzpJs^N$!4jc7mEjFZJJjUZ`4$_GMdM>X5oj1@M4p#i@fp<`6Et48ud!HboHsB{$>!ZlX+lH^M|!mESNYbco+kD8JsTf9iNd&*AnMACMDpj8Uu4x8RHMof^E}xkZ(vp@d=&FN0~ujDnULBAPVVf<n5+)7tnMqAf{SESbtVafh<31$MWiQ0T~GlaMjN{XWgvwLpNcO`R|5KUWjW=!=S-+_nDdecMPRs18mFT{0F4<D?tLkz9WzbEZV2^c~E_hqDg{BL1t8-#Jd?yF^7@F0@4-x3LXOsCM89=dT9}>rD%Z^T{O9k&5RhS`_~VfD8yMs1^La%K?w|0!0d)ic(*ueVBm1&`1oJb+Mc@7)DLanD8^@?f)^}X^u~<o`dg9YIr?J>!2=Y`F?j)Su`%BDt~Lf08gq=JNSg4oM}Y0_xS~SOhOpsQ1qpK~ad3M`QZ}ULF^_Bt?X!d6^(<hFurXP9i2{2KapO(3HVU-*XbZTi5cgi4?4djJqc0QDNG-PLDH&1xf|p49ag2NZ#VqQO1Z1c3VmT=v5<R7SkcQ_n=A1_iH-&1%Q=aUG$fFp=brzG-9#Pf7z&c^UArhO~t&KU1yM+v9T@E@yUK2W>My2*!P&RUnMJV{j?~DoL$JDjGfD3B(<aY`JVo!nkL<LH4O{})R^3K3ZN(5a0frF~@gON>gG(x)ylJ#f0BU+>H#1~xx|JXu}XIXdy)P3A1JaLR<B~hLu563q()RRY+uPZkNv_gI7;HCOusA08vj!@W{|JTL@cMikVmk|W2w?~rJ)sE(6QQtY0*EYF{)_M90Hjaj~uBA$;Gn1B+WX4D*`RE$Tc)Cx&$<RO~vyF??gocpKa4+1uT@_k{^|PReRTm@lNI{>V^bikK)B?Lpxk8YoVktSmZrg?c5rG~-Zkx_Os|-{!K&5R?m=-ZZB-i#SR`?$-)(Bf=s%4p;Iv-Q3s)lz^%iYnl<7lpiI&h<`1mYYTFfhAa2~`jWe5IPtAcbDh+Zn#Uea<KzSp{Jr5TGeL+53<2Lhz>auk2vB$(>jZ;y=l2*j$n-)Jr`wr^~Pb<InnbU40o=4W-n9Ug1QIah9Imhc!1>7zq+!!bw3b2(lq7#{sFbr?q41B%WQLpta{FxXPaObqkTsYC%V<;oaHdTHUdzMH>>S3b!vnHscYYi2!Mda}u~<2?veSeeL5bz>;tCmFO24*_x>THaa)ScG^=c%zc<T@HDy}%duf8XB`!A8{0ZOJQvm|S%b)Ug!xYvw!<L1UF|y{6pU7G#)BTjJW+LSLb>jQl~~Dy#eTa7z9Ju<D^M-D|F^EsNvU?g)^85fst`0n#=e6GYI$EL`x8Gp+s$@i;HW~fPy`q*LGN2<l7v7H+*+Kafv-%Oix&(5xT#pFvlHaO)y&?__}EumSGna)?BpHWmArAGgTm9%nf=I?vp*62xgx1J&Mj%{$Q<JZ;q=0Rdx7h&2e4LrM%IB>VAD!EC_{2UdFrAN?U}Uaa=SOTC>iCD)!NSlL=kK$tb_q<q!3@I<qE!54!uTh{MX3n@GgWzeIqOO0-(3clhwR43(-5jZWIa~p91I?_}yZ74r9z9xS?m30Le%-PWi{eJH>R78?x;qZ<7NqSvjaLAS6Tg^8y(%GIWX;xARi|c5d;Lmm(5m`J@s#jqh-e!Dv1v7kPjB<It&l6-l|BMQOLTfHbm>cE~2eTwBS`&dz{wuZkxDrp*Vh3^A~HJ#$ec1aE%VNIfZBzyvbz5VMSOqKSZ}2U7V&KyAGb8LFIf(OeXOk9w{h1A2NH^wve-qu2PcRlu%8@TQ_yqflYJfS@9Lm1-z%Pn(#9l|xL2?Ez`+eLG4NhQO1}j#+sujEU$`&hy!y<2#^O$eEz8O9KD`X&pFlk^(f?Dsc9Fvg>giu0y?E=JiH}T+{YtdQ;-85G|!w=_eqbGO3jpDBCD)e}hQuQ=*<E!u#xbQb5)B`AU=ZS0+{gve)b%Y6@lMZE>m+@Ph*)z3>Mq$3E&aB`g*@uLMeter5m`U+29pmVpDyQ3Yy-t$qVMNf%X45^KU}5sIkgW5oAxryEd>5aSo&*a#a#kB!xHO+Y+eqGcsTF&5k#_qRtLzFtoONjfUpe$VhY9g%e)k8E)w_Oqm$`yB6TzM8Hw8flXSa`U%2b&%~XDxJHxd&JnMkA*d45J@x$_d{W~B;`ILmTDzgP#npe{+kA&X()=xrV`IwJ}0AEQ%AAhj<qt&W`q?Ib<*l-V-?htiVe$iO<5;lu6?+w1@cRr`*MF;&b~gY{4z9`S(lgOkrk$I?roYz!r-O5+OWS6jOiPE_BmDQMsw@*ybO36pFzdjg6B5oxsD4S|3HaqO9I(|#2~MLyIzA(A%;>c=xd7{V;-@t>^G!x7S$@H$lsA>>IEi&pc@b<r2dIPJB8$FMO01)0Jq%;_RcUcyO&*31`evp9KW(r#jQv-(S)`Pg&pO`TOkDtWSevXO4{0_@bfQzhQmllX|y-S&mxhYJY6|j_lpH(+7*-?b^+c0Q*`7-fd{=N1m#3Wa845Ud&j-A6Y!<|!S_G1p8s$H0{xm5p$8=F7A!%7*R%FBo;EK9B#uRy)qkH4)T%lYE8rOHpXDTD)G*NnFJ6(9-@+fL9M#5kXE!NIk<j!%2OgLdca8WxRTQVT$Vs_4{ZL17I}l<$h>n}yEhB@W12C}=&{Lc;Av>UpQ*lnM8tKB42Tt(CR~|Eqff339m+w+CSgCOM+01cz@9z@blCl;UN}osn{lA;-#J{Os8OO>Yj3y`}FPE?Q(5|LeF)8L}omR_1P_{=`BXE~(44crSc_{NWMMfuFh1y`7BQ9WHGBVnZ?SnE3Pe=CsF!F3&SeCHPhOkPf$&wct+F6v!cnTUn@@__Cr{p&9bxH"
    _t = "7ae2951427d00c39f6f7696f74c160153da548b7dc7e5271ba9932e77e95e36b"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
