# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.smart_exit_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.smart_exit_dialog'
    _u = "5&nOYvoWbyNdm+Lm-;V7"
    _p = "x>BG&44nfo3^bvSey<;XkS=glSimvm{1fUO!lR4`+hEU1BoO}UCnW*19Qt++s&JTCU^pmPCy+zaJ4PZlrw-)*c^PmBhNDc0s5<jLN#Flg0@98x3XOV(ID0cj+ue&y;7RMN_`Y&}<6x0&6jRB3UVv^y1J#COfs{N7!>XlzAEq%}bVH`ts@pb7#sjFs<?7?F5;=^Zk4MQXmw9&>mH6RE&haQUTX9d1<9M=v$RG^4kLDr7u?Qi8W?9}fBT{)vj)(g0t4bA(g(I{wia?ZLrfJ~Jc_VEXiolRLz^)D?xEIQ4%ewT4eJ2yXv%4c7n452x+7wQA&hEt~BSrrJUJAS^Bv)QZcJh%-hS!8P3HlY8RkAQ7z6VhCI-KtdBN@1U>s-|Qad#8ESl|bUoV()NTwqS!pE|q?QtF*)6poE7!VL?H93gW`<WA0#Kq>y2FMZ_}lnx<)2bFvfuiRH69r3`Wrh~{w$)3E2dL=;^Ul<RCvAMKuf3!)Z;0nQG%zTjw`nkR-by`_MVnEl_E&sBSf5ag^ID=@Q)WSkn?LPcrlPec|P1kD0=NoX0lB>)5baIkXfN#nQcF%yL&b9C4nzXUyAaS`bIf|YGpmW}^fY|?1Z#HPyDuaCITz$CKT<s}>-;HA5#07<!El#8VOjtfZZ?h#8>Pjubf?e;}?$gA^TWZ3l*|GuhY?jGKmCP{HM3$JR*(p?!06NJ^b3Z15cE+jLnh1z61l#C`sm>;=8&RX(<t<4~JL`%F)>m;X-#bg-y2rX3YS9*`WkX>^kcBYtbT{2L5Sq<0IRrB%F0gu2oq&b4ydLV3@FV~VBM)7`Q=He<ocSHl+n`%LGn38{@>_F$Bo^>hZ`*H#U=fp9e+Z@?pE<C{m?s!q10PS30+{a}pW~d{em3%f7Rltq2X~-H9%IhF-EvxLv9}2QA`?Y9^mbjO)u+~_*Ua7esR+x_-B#(lc+WN<eN7k>6&quWZNi(9N2D_TiNw*WzH{m*KzqMhSuw(Flfl0O@a~fCgr)@rDZ0XZfPmL`U2X#Z76v1tsLYo<BoAOzv;jI+m7JSTvd<NqrBM|zd4)OB=dvf_(Zj9Y_=0prGX6IqGibMOZiR~%9^3Knqx!iVLc-cx*W1gNWk;WRi)2$5V=6h*>54xUInD+Ui}h5@u&(unxP7UH@pv#*xjuQFhgSv>DTCe9`g}&Jx_K5CZ)h$#3H~>8SU;%xtAYTd>>2{ZD3nj+8@1Bm149#m%mc@d6PG|_Q`H-5pR#bB3tWIE&{yP?zehx-!tSs9)PMC!GXyz#^4(?(m3#_YXCY5vKgff(DHOZ~o4b;O^snj8CVF`K8mb2Jsvg4aJcbi^=!7Vk79;Fnu!N*z*7V|dzy1;?>H|aPc-4vG%^W4qeSKszWq%>i${&UjQ55wt1_d?Z6n?7(QO<WE{hoXt<OvnBT@S=@hE;6^2&%&%9seNrTYF9xy|?Ookp>cnW|emb;Q4iL<@eixc5X;nYK!XWC)%hI^6#edoScQ6PpT&7S%;A-0c(K_=R<G5LOleUXdPhP@fdb+aU#0lW#7dJ`Iqng-VH?(_j^{Q*RNgf$B5nl+-aRIR7azI06z&bTqZTp*$XPqfMjuwk#f&#%OG%THRPXz@FnH#+rKJJbibs1$BKEv&3HJ;s`$N$(-!wk(}?eJb5*{PHBI)65bUb8;N%frHVk-9jO7igqpSLLhGD~Q7Y=Ntx3bfyQ7V|Qpn#0=8hTzD9Iyq#lg1<t%?ZT(#72pUvqu_2?$Vs=@_nP<e!5?;J3|^1s#QM`ho5b1!yunsE&&$nmUM$=@6dY;9V@S+D{BnYCNo}rbc$RymmgcqlJ9gg)iG0b!p(uZOSNJ|49eDViM?wZ*3yIbdXFd?X@+4N9;rT;sL~RI5~PUag_REsw`cGAfig7|9rGKygI#{zf{4=e(^v|NcVQ}g`0@dzV2-mXonLuDESTPxjQ>fPW^^0g{uNaheDyGQs=HKoga`m0J+|V$K=J5i!Sfi4G^1!Sk8L0p!{u9Fo#=y;lZNjTtY|oZfG4DGO(|>morlG6ICbUU?^j3?gXSZRVWG!~TV|X>;;SOuaHmRPWMZT<cvjLfi)o$+aCSkcm6omlUn_^L#FLF&UXMI&SdUWJMft3|rSx$f*G+s#DfOUFuG_l@!QFU9{iHgKW9Y@43N+Nh{ZrYzz>#%hrJ>yL>pWl"
    _t = "a3c6859302f8a982b3722d548796dfe182f0857bae395fc8747f57d7e4d7e687"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
