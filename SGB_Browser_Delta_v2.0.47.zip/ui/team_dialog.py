# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.team_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.team_dialog'
    _u = "SUA$|-(T|%IjemUG*azm"
    _p = "f9YzHBKqOs@X0j_FNnHPVj^oB76SfTvn!wFZ;=ZSip_4uwnDa|`W6|&oxiS$T<W{<Kizuo>v{lrfkzt@e$=gH;YeswONXuwOGKkdS&`?+Uk{ZIjhPtMk9O>^Ado>vpS^$=PeRg_k)hu9>zZsO9Bq}E;ng8u|M6kfQ`it*hKO3@dy#kO&AEDq;X%Xjk~sY7L`lsOO!9DFFEOdZSdbPwAt(e`A}W!`rRBSIsIMEE+ds=Dl~^%}mepMvQp%l^TjD&3Yaj_)ENOS*zMKV75<ZUv!8t$M7`EBgf$@3Lnj@W{Ep7l8zU*z&bAgb8OkPw1*>_k-AW=ALI5t8>cLtj*oVDC<M-Q<SUFXFCv$!U{L>%fn;QpDNdU!A2lvq4@XS~8vCI4s&PLuhfDSV@c!5mYLnX}>`C-@kITNoljDbonB{vKjjhTs2`p?K_9U3s8&UR2aq(6%r)J?)hi3m2-jqudJh;*`c|lA_!%4dyx;ZPe%Il4v<Y&R7J!?RWd_qk2tTKM2P4_70CI7AD11Ijl<~G;jIYQ?#xt0-b*o9%G?){d#3zu)J2n&kGoXeuPJ_h#hM`$jA8^=D$yF;V<+jD_E#=<h>*1tiJ?X?Fh8<0Lx|@q3hWRrC9_eeVSU?e>n;vdqu1{LoB-ovh``2H>_=@C49=+J?+i-ND<K#Y!XlY^wCHnAY>a@H_ak!&&R@WyeH0x^gidk+0(+WCE6(pl*|l=Fia0c?G5%=&%N|X>lDd&`C@Rb(C~1n)auy;6rZvCcuaO3LXl)DnwKT;_WNv-<+`5t$=n(!L%(_mdTk3)!Lu?2LesgRfI_v$3x(MJjJ7hg)HNM-5}%gnA5UBtfNhj%5no@Zko|%DFjb&7mgaW(FXT#FUHb$YMo&iVw}Pd&N~7{Fr_@OLhvm@-f4Qu+-ozj&mRf#~qiPMec)F9$CwH>7?(<<#;c4#Y=i;^#{XBX9n~7Q<KpSa2^!x+PM^Ix{06QN!Fcl?H_)JL#ZG<6By1!J?hpC3*ZD#tlEOJ-o`JUqV^f(tNtAsC@0u~C(IaMoBaeK2*)ph8qPQOt9@%WjY4i)fgoSd&cyL)A5Ml;|;I2X9x#~^>n6I!g|j|$`kt*{-O1r(u#F&q1pM!j##j7s8PD`X;kT7mAh>QT?X;j=?0I4G2Zwlwrp-06xJq(sg(m%!yNS5{bpNa>5!_e=p5&uyt25l`I2!UWe*PC5G7#mJpHzl%Spd?~CscWAKbCCXl5&6gLanZm<tX1ACo+|xmt6;RI~@?DRk?%)C(l*+{fzU-CbH${7Y#Uth%7-2NK+5ZPupwc;Mi0J#0)?``B{{jjdFG2A;ta3spX_9qw?cT9zA*0N&ZJl#C@_6qT4s#l+h=wEWx4%-+?wwyCy2A(Gvj6hEw~+GN1_su9@}J_EksX<1FS-NqKTHnNtd5Dib+LQN5wguS+7I%U=Rb(Lpf3Cw`)sx>^OhYj!0rtAg3=1yU_a=erA6;)x5%mx?_MFwSAmdYs#$tn?7XD#gl<J~)j9qc!sV$h!gyFQu{vj>v#Uvu{xaD6bW*BNXLsb6&+Z3&34@W{>F7p56F(-5#uyUlPp+nu);no;i((K8W3!$*Wp05my^{&CA!dT~2DdKf+b1nP"
    _t = "62ad0087ce3f54c8bcf024ecff91783a31c35e1bb8fd948fc111ee1d67f83906"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
