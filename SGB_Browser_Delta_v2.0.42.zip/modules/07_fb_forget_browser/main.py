# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: modules.07_fb_forget_browser.main
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'modules.07_fb_forget_browser.main'
    _u = ";TY=<>==(MvRH@sAX1Ec"
    _p = "$gs>1S1L%2GON91iVnZrSxE-=I^~F`3^<TGAOvwLu+=Y?UB1|1;6MAIf8x-w@%RO2-XFVG-tfD_)%nO6o4xypuG!*doMh{?*m>*n7(Ok=aGOc#&LN@(-Q0DrAYyN#%&$FUJI;Ya@x@k4QQvyecxmk+v(Rr1kc4~KgI%+9v~S3Nq*&fO$#jbiF_e3#x!E`G5LGA=?e;Hqynb{+kE-2M*_zs%a-G345!JHZbCgtBg^<DCs`o_?|8dhwB63ya?*-ZUAAWe@#|-USWJXf{_UWk`1QOX(9_vWAe7u~+wx&@*0wpkxe@2aR&70UJn?fi}!>77sv2$C+df%iD7hI-hROPx5=1=V1N=V6admc|fr_hl-rVcJ=>`aRdAN9Q*AF@hLKgRq`geZT@7;N+<dWRM"
    _t = "89560305b6c99deb9a8e431d76178de531181f98e3cf2f7b8a2e5cad1828af84"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
