# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.bookmark_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.bookmark_dialog'
    _u = "bA_5may!uSo}S}Jm~n_V"
    _p = "gTr}auQv=0;3o8qEqJiQ6OkUJ!*5(61D2txE;Lcb#|5m+$B=Sr23$T!PF~mxh_qB?v)Y#%5t!OiIr_l|5&>@%>Y6M^d3yxe%87|BuGwn)b88&96nk3pUw&S5py_}Gz#FKt$cr2QZ#c|;wg9<1w`ks@6r<6glFrI%4g_xQyp1QA^}<cRJ8kXS+~+(YltwhF4UT?@9R5!SDssnkbb%AGm5W9zMoo}LVIU`b`!FMX&LY)f;<ZROP1`tDK7>2Fr{RPx-b<f9eBQ3}znjWn4_;)TlwqR*Cva<{Lr?PDVsNzOgST;~)Ur!11`ROY^2bFZ`F5Q2P21*8+G?EeIISc=If;_Y4{)0n4s}7*)?VyVfZ*dlYa7?xqdP%L8C-s0T2={bP6!rrIa#|5VUL?nG4!}H9?s#8x8!J?Xt!W*1nB6F!OKEW8-Fusl#A(uE5EuZd|LIom!|a690<!vktyLJ3#3zZG=@JGo;j1X7m7i<!m^Ck8<(1fK^MqL%yy2<*jUeW!C?<gyuq=-VSpRIAgpX`KiBy=VbJd@HakxG9*<EiX}+%b_tIAG66EUBJVER7G37|;9?Q6nI5P~R%dFGauLYjfl=IbWmMG(dfpsXaN56-1#SHQ-9!5~j#qU>iFGsb(Gf@o<OO;f~Hf*8D=%)dkigXD3A$HMZ>eUkg_{ril78NYslVVV6v6ESx$de>+E5*TBiHuXR+|l5q7(Kq84^GUPOa|CioZWR+hMF>W26x-4%xk_QnKZ}f_%#^Bdd(H<Ci>;Wl)hnszP+L`_z<si8Hd{m&YKf?#LqN8Dz1nf)E58vk{JXfHXdRaYs3W#_$6Bej6cA|&ZFRZfPDOvsW~0zuKfPsiPF0I7<EQa|H_yAxey~CYD9$#V6{BO{zA8oy{iD>qpfVy56uhg+@*R>C$(K-F}TWUXW2DpwAXsp+Y#9C`oia6NcsMLA%#4JOZ_v>ejh?Onhc>p9JL+T#;R`#9>Hj+0Y#y=fF<2LogNE=G4p(aGYwwV6yDGE(Rrk0lSeW+*w`eVFzB8zKOwNJ^l;IKXmmP;B4oU`TQEB0L=BMrJ``P%hrU-J?4vGOITml3ETEEbgxQ--^nw8n$sgV@1KYe*+!{&&;uPf_OSDb;r6@1yv$`_st_(hp%+^h1<<&ZJ@ey18!`!^gZuCdA3vFnrQ)pmO3RXwLrqcTJ8udV@tl3pk(!@F;eLb!}ECQ*m!>OX3id))vaK7$!o%O_J$-M!ETHb~<a`+Un#2@vor>sI62_HJO72tg(?hW9DvcIZ1mFNtb+;0np3?_ZGu~R<<(LBeAe7R%Pk!6ZIx{ucsUp7E((kx!I)L(G?nx~$^90_^DQ_6DfB%!rPwp|3;^gj<WyG!$$Z>RZP#aZR>9SmoA>1ov|k_Q{``}{^Kcw4b((g8)>raO}XmX4r*<+t5+e>Kjm&>vQJvEeN=t5DsAa8M6?0tbxwe@!ZrR7GhyzqyCk6d$)w@npuhYqiy|gN*RRP%aW6YvBn#Dok}9o>~=5N+pMx+e1M_JPsrAT0XlHW&WZrV*k)PB(wg5DMvMD3jar>%V08#q950M`)Pih)?51|8GOH%&`dw5gLRQb)7FZ+(oL&GbQA&4u`NWoE@1j5mKzf7d7A)SizoxK`pz7atzgoQVikdax48RjMLtO{guUQK`@{s^ch+x1-6G#J4#R8sClx-W*2`frvFKW=qIsDJf6^rV(SQhUR9i!YsmChdj>>pb@GoODiG&YQf=Vdpslr;G6IYyWb`9h^qC!VwGdG$<(}maawPlt5t^f;$^dw{jWPVn)C;delBh~RG9Ka3h6u!r_!IwM(NB0vQ>uD+5?8*xgfeXMc^>F5~YEImzpty}T!<qn1_YfsAexlLq=z?@SO3hjdcGNy+n?7agpBMXG`b|o3!l_@W{Pxl$bHrk?n`F3{6g{)h)XM;f1FN{r#OC-Sblc9hkLDs27L3yCcq1h=(0qP33NzSqhOTVH<dkz3SP#KDrCFxq&XDjiYYZfl-UA@M^z4i=YuB75h}#0}iVuj0tB!R9Sw<$e;$}w|f8BiqBw1J=_)ih3%jeWu?R1?f`08ykAVjymR{%pp0phUd2I)?FgOw1_tTuG}@>-8l!BebekrN1ADWP1Y1V13G_CmqR*vo4nI|r4II@&b9P4s^;EELzpcs^5*_tJglAgG0ugBE?4FL<!uZ#ZoXc<^Knj68lAFKqc1Qdo-QHsl1=^NsIPoVh3JBDQjuzB>LuVt2}Hw#T;=9HZ`IKkOHIP05tWp06o;uYhAuFngRmXG?@s&<wyo0mHU-yvBJZ0}1k0n>Kv#D%4fet({0+DZ79gbnVXZKd?ewhSBy<of6aE<eo@)k(rb43_8~sv64u|Q;L|3(B(a9P$*A;ChPs5yPQZ`cOPz;JD<w%kf2LL;m`?2{fosAO^cD(Y?p>vtAQ79WYnIRjv2#e7#JUTsXXA<7d8|zztfeN8;0Kw7r=9Ato;y57ECC4&c8is8x}?O#4V}q!$JCb4cSE2+|^JWZ!1)9ZsjjAlG{`d1p%=;k1A>1{SE!6A+qofQakw+Uv&Es#14_d+MM1wXxk5b9zKd>aQ@6&W+SZ@!V6M1XVDWNWq`)t$*;^qH3<-I5*j%y#}(4eWM44?e@@%gbRwcorRjY(>93gzA?rB#4-f|{4jkNY*EDkN0*AKlw!eE<EN^}id!9s{yZX7|t5KztBpUSkVA-Kpz+tZIGtP8rJqEkf3%>$ozwN-XUc&A{AqiNl%tvcMxzYcg3McfHHeu4`60UTdH-r}%KsCHi#Z`oeqrGTceKnW&c5vo<VSLyopskOdQEB4+&(p)BY~N_qqx3T1C_p6=yJ$FRti~2GG1s9P-Owm#$)>#A`D}``2t21=`mt+cgxkqZ1ceTuaYQ7+D?=j3Yyvyag6=5BzKgl~f0B^ZHhj3vs>?@pl}%ftF?*-6*I$1X%#G(PQ9nJX<9(&KYZ#WBwJy8nApC_!)^PyN$mdzy^#8bOq~uQG`?;rD7|&wDjeG1Ynguo=v3JxTV|j&J!=K)4ScyLKih0muD18pNiTy8~=|oPYrB9`a#EZD6sRob18Xf%P2=5~e+aVM>{BRGZn;O9vAfY`jXTifUv{})Jj>t&5GNB&>u&m<kE_rc*VM>CZUViN^+y}?kd6YeiVTZK2V7KF<?K0e%nqCKm4G0izrVSo~s;xqSQSuqDsj^p`J{IwwohBiLF-kaiB_x=d9el((qFN?<Z}Ud^4+3Q(EF?!bJ2tBUInW8Lo9p;mYpC268j-ohIK)zTNi>9TKSrV-b&tc(w(@hF49lIG5dYVBxZYY`s1+m};m7_es(IynhvFsNbqbvh&O^@>6#m%O&#Kp#Djk7o>=CSFYdCk)6p>u$EaXb{x>Lf>Mkd510c)<z=5SxqONA4CFYXM7nmC!a(&XE<XB55-D6aMJsKdSW6+$lLDeeobLWOJZ36-$0Goisi`+1ll*HP)#xI;Tw?1Vl_jC#HHc;B-DkIjuTtL$5hj^B(Fp+l@NPd8?xMO*1c%f4Q;hFHtDRYf+{`XA@Cki(XLV@{_8hv9{%B;cC-N)qMcQU&IQLX7!G3LPs@a)fm;r~uScNJNd+?JN$PE7$mJbhC2tlGAob!^E;*E$kFa0Z?>a9m<6Y_zl+DN=PP1Z1-<I@hCDgH<wH?!Fv"
    _t = "4a87683c65082eb7b19696fc444e8fcc67499e94ff04c7bed6e4f54a8b1374d7"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
