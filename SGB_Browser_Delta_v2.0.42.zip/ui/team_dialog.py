# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.team_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.team_dialog'
    _u = "cKV)1DX!)^qc>T!*i&{("
    _p = "=|Jc5>4@}(5s@ZacUIvsCxRR@(F)hluLiW>_8A$i61rC9gY2-RkJ{{mOC<gwP37gPO>tObB<o?l-WJ78)Q(;OcQCotdqgtdA9*Ig79+Po+=Ufa20)~R80^dDHPXIv04KMSADocR!tFR?u2Lb#{`#HhSs7qi9dk7*xmEq)f2k+4_%!@BqD6%#NYX7&zDc_)F~<Hw3bgrE!66ECuU~$1RDvRV)6zNxSREB%X8Od_KYRp)I3}rf-C}m`)%NZBqKXyP1>b$vOr%dK8^>g&iaD{&IXS?G9V3b=A9-IX&5J(-d2^3}b5+$*@y{b;0*-tr#rIP~(&hoOK{zuV+1|3qFyToji9$?tWVBIdN5%NTg}BK1JvLW0O^vOO6K~^kLMp#f9X_BJPB<iurI8n(do0OU)87Sg0PtxNhKz$MfOfAW>wYNe2OjAH7&Fq)x6+>eva9*2;=*LkjNO?Q^3U)`jEeTEzK=Q~bs-U^)5E~esVcrn<hR^|p{oAv!&kN4{{jv(+vh6b4hDxt#Rt~Tot!`(akgwLy8R#QCJAqqOJTfW|4}l~Yl=ZE7<4m7F*mMbyK({SD}+uyBnXy*NL?Qg35`%Dj(Te)ES9G3Rq@87+U}nr`Cr>Ee?tlKXROBMqC{PXnw<;(zk{{2H?n&`c^h6Tws}EwM4J^A=FE(N5TFEi*)1Yum}And{BpxIOoR&FCkka7MRt%7P(X0Rm|RP8PSlCWf7+q^NI?-1!1CBKp*7{<VX=MP6u^qi$_n)f!_|k{QVriJ)`HNw*rC+igLBTfb3rD{bGEk3*hNHxE@$>|UNM&ThoZGPc->8O&yg)uh=1Gl^cv@W#MF=CWbIKd0A%H(4u>D!mzV<}4JSrFm1qB_-LZMa@q`B*>Cl*BM9mq)RNrp>Sx~BE44nNn&fD4t0puULHJEwS4W*Io^SpWUdc<gAq{)OYFD*x6q8r*2q|7Fe8tK<Sq?kMqLV!rV*Q&T-qzgM)w+W?9RKV=@Iid_i|6<|*{BGgcyw*kIBG<5d!|!GD#JC354nd%oYE?yK<S2xCBCnBw0cD|YGeY;qq!VG<dP&5GmNlymd$4pHh^a7)M((f;&t}Pbg7pl;t?N|??|B_74N|5(Evf5d<Nq1+dw_rPnC#%=5ByA}ZSKE`;;x%nt7jGyOpSQJ*@;3+YcoO)H1JzA;vn>=e|AB(0GH4<8cpH&3vPu~aQ`QAW}eZMPqg)qShy485z=bbbW#rodgdrlI0ySmepK%dVs)y$g1}!FklQG0A5Wtj<D71fgXha1$&9^3A}AX0hf0s?;v@U((n`<OX2z1^Za;mz-1G|A(rPzM9htz@_`2ea`SffvnxCYekZyigREd$G=5IB(W^@M6)B@|4xv+0{lP(zmDJi0E(QoX23PW?o$+|>$dIHc-oPzZw0Ei$B_XeHeP9lTsBY^QrJ67WHQS9cVjaM9)x6UF?poHLiD)KLDU)+Tn8iQ}27tOz3O#^3E%oRxs(z2#y3-Whot5}T>cS1>}l>@XdoOsmD=+)vymQJCN=2tf8FgJP;Ju7JBh9V7`sWWGi!HaINvj*-%#oW^R;#rd^%3(k_7T-}-?`Dq@S_)2)#JgX6{+Oi)vpo%Z(;&!FE=!5d>vaEo"
    _t = "8c5824f924c2a1306b2aa8caa8ae9749c90330a4ee9b7b21a3718af4c1413a39"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
