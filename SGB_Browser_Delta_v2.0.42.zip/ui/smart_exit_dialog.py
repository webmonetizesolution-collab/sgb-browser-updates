# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.smart_exit_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.smart_exit_dialog'
    _u = "dZ9_Wnpn@(#r*#~3hKK-"
    _p = "I>om~-*sBBk+Sw=7o1n-sj|(g+y__kDL!VTO|I`OQ<g2*C$_00=P3;;_Y(CNszmq`hK5xhwm9d4Qong{Un$kZp(pwzTg^^IJV*C8kizxYuPjIs<G>1{15dy}IWX#t%JETGl5S=@bAo=G4F7|^h~o!XK|&X4nBmZPt^-iJ<A^7}1L!_a!GrKmNx62|vy1`VjvUm7XjtPo@2SgFP0qfV(1sC4g8oF!1ZD5>0SbvgxeUIepTj%C2c-hv9a$a4Dc2u@tFx<=#v$mSZ9XI&{BCv;geGHf{5O=7;CJFK>A~Y)q?m^TK5e+;@M3~i@RQ{(FGprX#ZTfRTwRrI8ifi0Wkve1oMvBW?ok+PKIz?z5lJVxX@98ph|PL(00Su!!FTS1>4kzD0F<*_;u1lQ85@?>J4l=V;ef-jUI7HJ2u3S1{>*l^#DQ}tzX(`w+mf~Hh#sRj;oeyFMytr2wI@?_L^StZ){{e5PC{6Ysy6^Lx}SZMQA^%gw`DR+H^z)}Cc0pEC!&|{YasU>9N#Hwg`U@{pa*+RvGZ}74VWK2ML?6S!|<Jq+#p!AjO-MLQy^>EEgmI96B5?8NxB04Whr1b+Ood&y|$f%9k#`G*Nl5BaLwwrACYG*!REl^ECt?A0%H*&w|lYYWLR&6KspAOdXFg~w*K(e)=FQFl#7a_l1L6?4e~+Ehl!Ng5jd{;A3TT~B&V;_xmgXUZK;eZ4$-7{NNVWbNgShWB9#Y^2&m-9EU~yKA>Sp%!hvW^)E<z&xJCB34xb|2b*(@bVY?j0_r;uD$D9o%GHBO(jxbw@52Pg7_I8Gb)s<#CfV){kBF`(cPt1yTZuvP*Z>=eEvPH1h`C17wmv7EM)GT?y$95@@B7E!IU>Mo+`D6bCGXan0=9%9Oa#Ry0??-;BU|594lXx(>LZ{LS0-RyTPH@|I<bNEdnZKx#!ne6QdxtqM=m|RuU?{I&TD#Hsyrs<vzqRWtEC}=fzy7Xyq&R|%teYz!L<NmAJS|-Y+W2WlWi#JAL=-UNy>%wN|8<6~`T5Bc(*s!Hg~;f~nxwYezMIQFq5=@@N@q$BVQo{@Vr2m9lE<WG6KPr;7DbGUKwFfGF#i+?IM_A4qr%WBeX$g=8@(bKTM96ql~3J1ZWJJz3A+68Ec7K#T;8>Y%(}-c!kl>cP5j3OeLl#kcF4}&iz0g8v$*@OFvXIPg1ouYesZPg&-;p4ONF{eOX?rJBuYH+sdFv;TWkAYpJYIo)Fid|Lm=l9J^Yio(g-Ic62`0nlDyMN=UPb2`StMDZkw+p!WvQ3x28Ov4O~E|kLi13Pd8Dv#EN#h0GWB>aj3x&{U_9Py)L_#tA?mN=_pEpk>ZS`@>^`_K*kVCdw~<G7AybM<SF98F6e9&5m3@5QpCB5Y9E?G#^SF_Tr&mqpyq0#(XxcI;AODYbavFA;q1LW`mtifuAQZAg5n%O_?%jfU}XJd_Za<EL&@hY8T;hHO28&AWGk~qoBts>8AQ~`xL4X{)S$aMI<$mUHnaUTlGJ&rR~5|)Rp6$>zlpmTEe%?r_fdKA_ksRBKYi#hXRFWoBJ=>CpV>Z|t!;k1vbB_UTtxgDPTK?JFQK_hXtRYI%dZ`EVd|$Ny*4QxE@<f$=REVz>eToju5}#>j&u2DfX+tf$OIr#2LQcBYJ3RZ+f~y9IE<1t;+KNh{tr9Rir1KBfoqwlkQa&xGgSdsu&NO}S#Ki7`dXhJvM`t_OSz=m(^dYgjGgf#_j4}NYj}j|?tnm_n+aqfh<Q~Xdv}J`osb8GWH+j68xvKwJ-{@2YmxU}fA+HlMl;bhBg-_OuX)pzskB;1q@^$EFx{Za8Qf{x0L(k87Snb{p%1X%p>`lFtr6^?&q*gDRi$jV%DS7z&i5$^tAUZbRz1)h#AT%q-XGBYe4BU83?V6D59|GM;79wTCY2e~TOJmb;t6LdpK}vpndBdRg`Hups>30WCkZ)bzpJ8;M}-l@2Z8p)ZYiL0p>)@}0gEK7$8^Y74F3wzKGj>YQEy{!j0Zah;wxd!C*Bw+ZAu~)zd08N!T{wg6Z)x)-hy0NJ}S@%0aGSt!C}<JvAd5HUxDA-z?ZKr<S#!nXx+XXL36o%A{GQgL6J^Sl;7Mr7+LpCtS6b0Y9>FyI~H>sYO&yxoh$ndrr5||GN_Z~unQz~3sJ9^XHCnBgdn4ty+eiQEk^lZ9xhP"
    _t = "d1e995c13f50c117d0f84a0b69cd082da7d5e80fec2376d3d7e15a1e3656432c"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
