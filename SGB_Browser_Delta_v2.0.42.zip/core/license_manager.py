# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.license_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.license_manager'
    _u = "q=+74y(mXgYoJLr84BBu"
    _p = "dZP(v3F6i7WfClJYRTr#ul*qlylzRzbxyV{M)A|%cfP9f-r(MW`rE!|`Hz2C8_^v98x)}A%QH=9V1PbK_$I*+P$mNM%i70ZFFgR7Em(*LlXN$&FU9<WP&FW#qrGPE0&iX7w`)zG^b^1NN?%g?4y&8GH^|RscuFyh-NH><2Y2zjhPFLMk{DpA=3-l<LyJe2_(on#E`K*UG&68{<mrkSv{X+b(2nB#b3wmp|C2nhn#VNJK>QIz)X{Ttff>qS2RJ3&BnOdrsA7Rj0~1y)m2|{9LQ_gO)KJGf{<fc~QYp*0cnQT*iIs%MVIR9#(P@Gl?9^cmx9xTTgcvr29{a3rH*rpxB7<LC?9~%ybxrEME(GE`GJ^aZ9UJd5OX#OXlfzGscXRp^c+K*)AlN!g@+aT`{(#GsF(MZ^lME99?9n;Hl0^u~PbAu{#e$~e^Q{(M-p{30OEk^|j4WlH1d%MK*KIpHn7>RbIYU|NqS1_`B`o5B2gtgogRB?wba#G2&<&=%d_gqOZlh0Ou=`fD<i(+PpXaQA*Hg99G6#t?Gsm+wS|`Z@!zTFaM&2JXWKJDl!@H=d589>~t=Ai)F?^F^Dx*miyJSb>tS28@zlg^@D-X;lh8F3QwCjR57r(F>9=~VS<k2=l<s0cOUUOw!;F~P~Hq3|V<81|Yl5tb^Koj=Sx5d>zkGT&H@BU8spBGebtJf2dfp3iNpgEx+<T%+B$~En{1m{fXq%(p4ptI{Mw0Qh+zP=NYZr9Li*plP5W1W&>n)HAB5~+n=3PbpBKFxOAg|q9`^|Oa%+<vt1a3WcCMS|T9p!BADFEiYNYYj++*afpa)K2^7YAC7CZ=5Q)xTpu{=RhP?$^;Ax2sra-40qQGG8pAU!rS|xC9@D+<Ei~E9BPCUPG)5Mr=9c>$wLh=OS;*{%(Ur0SnP)bE`sT1zA#^FBQWdwn6T|%d&2z0ksR9oWqj(o&aWeK5D{+rgH83dcAc+U#-lS@1AEu&)}Sl%nVEmsQ)(b(hOOQqmp+e3Lz<wE7k|_>R(R%8UKXX*J|rFFE(FQ)4tOR8fN`?S;Yry50wI@qMON|}S12}A+;)l7+`Qv?k(3s6yIBVp4&QG25F5HFK5J`!oAI4HLVfYK(lAxHHOU6Tn=kd^LgK&}p2-$_LN|q%7oY$ubf-rOps+R@Q#HMO%*r#sq!yz(2#l-NAWA3h^9vLr6bA`anAC=3EV5FODQ~;G!UTL;QC(H{vspP&plKJHs3J0JmMp-T2l8SnPD?C>KG&Am1$hPy7RrUGuTuO=yA`Qy+?D@2wC)?kG@ts7W)}Q?!hgZ91cR`NJW#0IZ|T#S;LV-B^U3~8KhgCm!FU22;FCc+Hf_rgI!Q&Xa^tvUJffYt-p?zK*bDml2x2hW@9UceOEam8&wOX?{K!1nCE1zJACV)L;Cmb@`uWPM8TDzJ9udcameV$F@{a)iX9*-pLtr{e=Ml$V+eBu5hRz?qw8hp#bnL<>`x!Q{Ny$mvZpTU1gIys<W)P9W7i+;#0Ahq)Cj)o6uDhT2+(zkIZ+Kdjul1otTs`aTNx2*9?vAddg)86Vf&IB+QZ}f4(+Jj08P@cmO*#&5+#B#S3>y5~%zW)n!E<UFBt~%<6glxykH&a{eiszvLv2Y9`k-6*2Mm}yl3G`Z1<VbxqNxXW;5b9(luS>=@<c65<_jwY+E-O8L3~}tt^Z{L0LJA^q08YsZq9i@uX)>eTNW^mA2=qjp>9@S7In&pa_a$wB%gX3wFdV%(aa*atVy8n6g^dm43<JwxZ!HPsqpc2xPL&W0Qj~-hA0|bHGHOylG(gsf((DDuG2VA52f6Br&OQ(QCnpQ7=v+RW@v+>6skSPeO+|au?%UB#_qdTI-zO7jQKBa<!|;&3DHvC0X3<qh^!UE$i3=4CrM$IY`Igry}?dh)EE#=c7GDI+Q{~ekY=iEqAn$d7}V_-dr!pcsj#FEK}Ld+>MVy0e%pLcHZaG9u>Q?CDyE(b`CJp@U2zJrEY7Cvs`u?L)ep)Y@c@iVrAk?(Nno@X8|N?nS%39Rjkg5{ED1BZOyWr8zMwzrhViD7p#z{8Atu`Vc>fKt(^dJ#yD|EF6c<|`HO;{yD+3<vB^{ZUkIZT=UgS_M#g(9XCZBzf{$Q|^Z4eWRXQuhJ<B4Q6PCIrg?W=}?@ViheHMYsJ18<*+pMdOqc{0Td1l4o*AQdr%uDkdb>yzW(<=hh{gUR*b&3%pbi}03c#gqgMtU(2M8Y4+L&nGj?6$%4C7FlS#^-qwSv-sICc3x^jw|AMSR3X`R<KSnEOKXPTV3~17&lZaS`xV{8JbqYB39#TRYl#I~BSLN#@1lHvBLD4gm!}7xI$s=Lj83_a5uoI3oRohHLq-~6Yk##_@cFrWD81%vWBZitOj=0Dy&4Ul&VG`mar(xJNYC8#cLP3VekY?f0etjX7&jl~G^>fE0*k18YHviY35<-$)2Z&V49DW6QBH8J=vZ$1?M5}1VjctGC}E0GZXQ_2F87a>Zwy0E1#R)IRrPkF8W28oUEt4Hic>T8ZoMPpMduD%A20UOEbFCMubV~JRNoKYQ9Mo$^gi>Z@54IHy%k|o6J>`LHUWQ$@-5)}P)PPixQ$>%FxvJ<CrGJjE(b;IJ?3Oo^DRM5EE$$gz-yiUR7U{zcx~#l`C@(-ulv88vnFKPW74^9xU}7F-$i6etXi+yX#%R@j&Q)-1b{^g_B%;A)TmhS68pS*bBldC91@SAl`WsTrVZAXO$#$Z+q~6-SELV8WCat3{u+KA{ez>)nIPLYeF4bEVxvxmwR3W58@_>S1b^VXBh@2m=Amo2TLMO|0Fg@j%25%WWbeRm|7`MEKer>+@d3u*_v^->(N6b*eZ8#eG=7Z^kBle7im$95Md4ycfLvfx2;@Ss>AnicFUL9"
    _t = "bb9f66c11df60105bbed98e588c57436e120408ed93c1cd0a6ba70d2e7292b8b"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
