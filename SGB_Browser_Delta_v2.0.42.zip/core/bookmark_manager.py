# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.bookmark_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.bookmark_manager'
    _u = "t>OtzTPGmh)-!)q74LM}"
    _p = "@NO^WcAu}Z$(2GuMbhRz6&hj6sL`F<2(}I61e3vTdo8~mpEv&a%jqvBFd+h~s-P>voS%=w=G^}$mx5CaRJL5KIPz&dg$|x>+k+rg;8$H#DMU%N(jUOKv+p7jQ=~%&!;;9gknl7S7A5zOO%Lv(<Zrl{TP;`3g3{lF>#=i0MVLYP&w(cioEO!|r4dhOL(-*KoUdW00`l8r70emWqY3Um*Vs%U+>(-wN{JogQ3nKE8or)+fEB)Wg{^UP+J(MrN@1>WiCe?6OY_#7FBzh_-BnYm?O>GkDpZ(9M#tK;^_rv{r1EL$f4yaalD51lPJtCRDx$nHjnH?Ddm&vmkA70$4)h=ENArx^GPIyfU0#43lE{kH#rJ`($MZ`F%=zbJ(puq^J4>i4I-FwfA1B8N|2Co9kn+Q&$ix|qB-({LK0kX@51Y4+{eWJwn;&v$PHc|lUivC|!>J*zJe5!OA#Yf9ZvxZRq}j*+9zKJ#!;D+#CcPcrtHEYr#O49M9yCfA=JP2sAO83o@k}KpRmG{>;Nexagz1mF1+eEn>500X2DRCP`oNF)y0E(W<QU`{UL8&yv)Jg#S<YL7_`O!b!7=T>R(*ng|293MoYKHuE+TS&AhKrOjsDD+oCbEq>`d~#xv(Y-5@l7btsUh|e2>Lp8(XTg?QZZT8e`QoWRS*QsW-U62#P>7fw)X&YhLIrN?#Rn<DaZn&y|vwwNC3?x;L{sXL+|d?V}^EbbG02&^wb9zjwCw0QUXln(?{h`bD~1_TE~>*sPR2tUlF%4&0>NHKg(PhN*KUfq7OHXGM2qH|!wlEzr=PGk9Cn-G4Gk(rKr5`ov!}TsTXGo6c7lg<sNo%^!3eM7F6PrP64Pvj#59NY(;>3tsBV_yk0qrmaTs6NI{IUc>2yzC+v`;0wd3K`M>m$f*eI*T6)Sp@pl(u}@3iskgwP?xaHJA8k+145T!>W$vPcmx0U85ZeEQxv)<jak7Wk#WaQFS0zHM-6VMP?961Es|btbNcZa2CowCqv89Nct<h>Vo3o)qd*iOnvvyt0@dI~hOLVR+EpGdGLUtwUO=8=5S~`x5SoVK;<3Zr$Xw)Op6iSnV@-EI&160By-CZW{FqV6&T<_5Zrzw-h?VnxuKkC78f;3EAPUnmaNRB7cO;pm`j-lC51-5YTgrF_k0ofU6ykQu&Ar}Q@K(~yq4nE(SA^(}?Kqw={B=%0DL4=?kXR&x?!zjtNY)ICYF{-4WcT?!3Ia*PWH>j1)ND_XCShA?@b8&eLEDgo3-Uz54dF_ZAn8ley>ll13{qK1LfVe=mOb6J1(_dF+h!h5J>BLDy+0Kvc(F)L#86n)(Ym?dG6{P9r#+|(2tv^5WM$FEAxxGw*sAB2L%5_VMYb>C7wtX;m$XR>tJTozAwsEikfB)qruBnjx@tS83bSXr(+Rd-WaOeJikk2Ff?@wvQgVX!2$m-3?1>12*92P`nCW+5#P(x8Qy*---=p&S&jo=?y#fu@>a|h6Z$a&;{<Vnft)eze#e@9K_+vrrCtkm$u6De7%W>RH8Cy*)xXe0TvNk-Xmw1Vk|W|cTlEhvw-%FCfRA(1m3KjoQYDQb)r)fW8&3XkZ-k;@$5X=u}C{A`kUv^X737qhZo5j=vfc$C0UOm+Cx7-a@6iAJ-Ui1=`A>I2<}Xxp1mKOn8sYP1U7;Ch*j3w+|^ioj1a8G3@Yl1O}3M`$qaB~{xLfeoeoo%iKw-Gzo9)IEI$c}}fxu#JDM8&PZ2?b(<Jra!0-*kyp2`X?7G%7IacsHJc3Lqs50GZ2|p)2Xhtx#kiW-dBx!ON>jCSy+>6t!Y%)lS4Im2^P2g2|xXEBF#;5l;epM(^Zwj&=8AfM)YR3!-Mx#*FCoXlYX&4#VST)>&d@U1jV>X=CppaJD~|t(UP1nt@BTvKX}6o0ztG}wglI)XA9_RrMONaK@y?SB=YVJGbU+FSM8%REmy1cIX*PMJ@pwpCUlU5<=s~Wpj9wq8({ChHdQ_ZgmiD><Dl935i}XBr2ESlM0giJipcA!lxj^t<Cdh!;T!dtxnP&7cZIP4ZD(*h)T6ANSEi(y{Sb(5`!!-##H_VPK)D_i_uv7bi{=#W^KN$->DCoMbO1wV&{f_dpv*^;LbISp33kVrRk99!1D^TL=o8erzZtHH2%E?hSv9IY#Sy#OkX~(G@8|aRUaAX}yM**m9Za>K9n$%2{_pjr%yQMdEZMTI<v68k#KXIfY_ja!TS|1P=kA*UyPlCCEEi?Al~h+xTI;U~^SB*ogB;L^$-%O@rG-|FTaT@k<NF_t>ya+8{(w&f3V4lLi)(@K9~U(>vCw@#PhQ&+P~qhL>7E{a9-;hDwSfhu<#<g=IM<zy+d@V~+a{W_fQPpm_KbP*ymb7bQl<uucnH6Lda{f;#dVHr8Yi7r%+(I>dRF;)|Navow`i<x)lJaP3K)1@t6GMTuu16Kg+BrO+NE6_bn+<{v}Bnd1^cJ!OOFxxe~nJrti@klx4Q8<w8~QTqBvQu`4Q!D@DrMj7$BC{#c=Q>Bt&EB^PRPK5(-qF&mh`n2w8AqxZSmj423I<_MX>dZSyg`Od?xt*T|QRHW{V=LrSGb%lj-67RLWdRYW44uDUqbV;%mFc{3*;9l)Jt<avHK6RYgZ3B)?&^ADfb6FO}xXY1D6k)J7D1fwL*$<oq2C~KxeX!5C>yr}0)1lLJ)dsA1cdW*O5d-aC=@nMIz;lNa=11+BW<+w6)bMam7NZs5i>;km5ghL5Q1`$ju7)0IXISlT8_@o4yhYB!R$Zm*^0XM}j|4;U)+7IvtFGCK9_fgnNmvAqh{@!)JS9qk}dIbAPb&p0&Fn}H<ai$~M-C17vhWgc%NzdUlZ>Z8oG@2FwO2IDqqv8<fmX3sB`qsST*M%{?3CBFIh+n6!5dalwpK`#I>gH?SW98fqEXEp44nt;OWbI{k1hPYSXxlO+BJewE^6q5K&-Mr~tFF<BY;0{nNgaw9<t^2KY5Wz6Z&}`LCLLdWkEVE^24;wJ(%#BJ?3q3Q^5sYM_Ut<oPidjlUX6x=$Zx`KDB*O>0Hp?Ex8A0zs;@eRo#xKcn{6j=qu)4Q6Ov^ke#7(*hX83$E_MuX_KlT2!0cJhJ&>wLxlxfG0G)NZ|1tlaWeqnljY95svyLR6k}ZREyk&T*SAh&Cjv_z-$fGWoU&Vv4Q_rUkCRCyt2~zg#Mn!x%nvigqHEF$5z&82Mb<#K)u{{mgs1bREj3`!=y#vz%V~!KBp?c0Cz>jsy_mp+AY>3m&vO9NVy`Q_iuTzG=FYJ@2aED9${iRx7%@#lLzFL{P_zZ!{mWa7#7CeRW1dH(#zkY)~CqyfT?qL4)vR^#?j(70qK~5OlxBRJCy%Q1LogZl#$8JlRwmK?1T9t>%=;&&BQa26vga1r|RpIv@Obv|Cge+|G{yt3C<>rkZqsy$zY6wCTtW~|-#4uvxN%IStnS(i5;2~d+u^4PM8^-51N0*CC#MnPtF+FrrUIOMP;VFHcCdyP3L#&L8uvrm=tI0^eFZUY-s=Iw5u1&Q"
    _t = "813385cad9fb0162020ddded84d2e92e26338e483ef86af36652b94c5bc33013"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
