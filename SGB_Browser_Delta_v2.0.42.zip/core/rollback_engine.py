# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.rollback_engine
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.rollback_engine'
    _u = "&$|}|BYy=!^AH-}4+>^7"
    _p = "a_c82K8J<;FbW~0HF-Ap^Ych5`+0}@A+Ww_1DgigVxvxjX?r><s(HQC8}%d$2!W_jC<X`R2U)XB(y`+-;C~}_K<HC(pO@mLYz%K#X=pY$(R~T2;E$zgu|B9!@3j|p|EQA0WjU$`T`FK?q_|nQXRl$T<IbJ2gXzEO)DumJroEdRS<vJwDoITu2hh}G(w84P%gbA=hWGGJRJg{>Bpo#z4>a;-d2%I|^6!DjP-nF{MdVJdNtsh-y|GcB@Ij*RHwi>9k7hN%W@;rynK42OQYg*ue7OO>T7*Y_&0i3$0l~yrH@yw9s)W~uFZev`J4@+Nj|$3e<4OtZS53EZuA7b2_MJypOk?l<>#|I=3GCfudcI*FRE}<Qlh(+^$%U1)IZWka-y{{XsE4C$F9&1l9lo8K27RQRJ-^^L{wyb=PU!%MzDrI7Y4F*=t9i?Nl4+|}^|eCqWp=_edof<YqKvU~qZbt=@glkYmitvdesL1J|JT#Ev^vk+S760AWGA9z#NcwkG`)jq2;t9$p+W|&0gXM}YMNpt34e{i(20IU=}z;_E!5v_cj?eH%CaTyR?N(EOWIyIHhsE;*ZYEG95|tYncfc<)8zV+{ksz0987Lj!;t>)MRGE#7U!P)`Lx!y+VXG@bO)P^qBVs^i*Sq~8uNIMjve$$>Ka{AqS%(2l2$XP>v{$-cyZy>Eg}Jq2c^oXzzoCksaNUzUTcynx_zg3U94?<Kmu3ORq&}J_G`sxS!3(rnx+!PXBMc+tsSf|dTS)}G@R9&P?3#DEyRdLK#Tc(pMvmId*R=bRtxC0p4gzk5DDrmQ^%2MB4sJ@nuUU}cYVNr+jk;Nye*mIl~mkse5Fe*?+rQQEgH^nSe%<O<HMkd);`mm@&22wj`Uz69R>^_9O(gCP+X|L!fvSJ6CT8Z%Gr%L&y%k*8{A9r{d5EGy9)=^Ugxy$m+~U4P6ZWT{=BD3iME*VHfpWbs_queK?PQrk&e@5jkvj<Qmwt_mf`aexx$1*$ax3hLg19ONHx*^<|sVgYM!FZRfU_nnR)~Ms^c~19QM>+xa5*-x_b%}TB+;5`VErP_HE~e&GBw?R<50c*N}~sF%yIKcCwSaUBto#E`eJMJG+*411b&PNr3fm4TIGT%e!hmPW*b)+9H1|iKA4WacOYPj#cvnArcqq>9WGskg}#PPz~rHM&?*%!+2Vx5-Pc*q#$$UM0y0M%s<s2;>I`AN{tWwWMhqD(ch-GlR#Q$5N^v&BfJNchh<kXWqcy-+DIXWThXP0G3D@yD*?+?ScMlu!|oTs@)N?-k80OaYBE{aRu76_>QwD^cjOezBI(WoK!(T^x}fNeNTA7nPvI`(=a#AP&?_XPE8vP@I~QjBLt@SKOJ#U)UXguB`+3GUriHa>L2cMHCXe2h%bv04fSpbqPw{2%GVhVOc+jcyZwL9VL3@{ay&H4Y3)C`fm=fK5yi(|wNcQ{h6KICTy6;DtWM;|p@$N>rRa$4eaASwT?Lv&xe|^>MRtv!X89?q@&1Y#TUxLzXEo&;TUTeS%0t5~bdJDJLMihip@3+4G({Y7ZzD53p8rUc|PdH=?D06{d%$IzT;DlcziANWjd{-QRHqLNHIbEh!a$AW9<F!N4)OK_35M-5oHk@T&yG(-0_*VD}herQe?&mtH*9i>26H}Ix6?GKn%$)X4KbA~;$+Fe~XtiKZAoPjvs+?2#R3#<3`x=ry*yIw-<KB$p;T266JLDQ|se4c;9b1k{(&wIgg}H?R%o3H;3_}^4R=^TY&4gFaPX~xVIg%{c5Qr{T9zPKkBu`T0E0}P~#NuPsLQ-P+<ZyFy&dux6AkKWtk~N9}+LKPoN1JX>n7->n;TK;d%Bz;IJ?R>XcRqsX;^KVMn|Ufs^yOpPh~(dhmNNh=-o+NpDRBqB;na{>pKu5X3hVL"
    _t = "d293bc8129ff85739d8e8666e9c0eb3e84bfe2a3cf6ee7464b2cefd9a4f44ef4"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
