# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: modules.07_fb_forget_browser.main
# Protected with Multi-Layer Cryptographic Armor & Anti-Tamper Engine
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
import base64 as _b85, zlib as _zl, hashlib as _sh, sys as _sy, os as _os, ctypes as _ct
def _guard():
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
    except Exception: pass
_guard()
_P = "c-jGL0+jvUFEO4U8%x<%exju?YA>j)X1Ua#z9fl)LEytR2EQhRd=}C`R7I9TcDSl$BRKq{Ch?oV;3?CJSoo$*KhP1VLs{!~a(b2zH=Lt>B65S3E$Eon%T}tzUiIH79_cXECNjiRNln;B9iNv&9v_341kRw6sVUB+XvN?HE!!NgA#Bw^UPi(kXRWYrBrevhB=gk5v|#PacjMSKTFd~nTUqO1bZ6olJM6K3IC77l0@bnY#zxG)48M$J5%4FNEj5@DNL<7kM45|T4+V~e1l81?v@7<44!MA50qZB#LR0W(cWvo*UY_e$a8Uf}YoVRgw0Wb2L*$Gu9KR-nd@{sSPe6<~H|*jnYI^+YIQWO0<Y@PU0{Ox;7wsX{KQNR+5+b}*Wuvbu8Y7RRFXY0U#eLL*NcYJz0lz$ue{;r08+rFaXP~QTD=xLAC5w{4`(&eyPS46H0QfM8P=3Z;Ok2}HNV%&jBR8z2IrY@^)=%u2OZC_V0PrG?YHsI7PE6ljQ>CM3B|X-_FXWPv`Dp5e1i6+?QonWGZfwL71_<YKXS}XsDLbg6B=6eW`g-?@Li5RQTa|U)FFf5;8%EhiH?6XIa8Uf}YoXMVv?=17T(FU6Bi<#AV|CY4PeIvSKfk+qWIL{{J*fVYv?-&HK=+J#QrQ=~U~bb_Pin+nV85q$87`@=BJQx;^=0gg1i7YXQonVXV|$uGQ%AuXKE~oIYI?7;IIoe){e7#7T;PHt3i>wHCN;h|Qcjj_NTQ=>F9n0@cD&S(%U14+MgH>`P^DkpFFcfAT0z(vKE|1bI28"
_K = "{SO?pGCL@?G8fFk3QAhs%1eRtvXlvf>nxD0M{=K4"
_S = "0d2315b98b0c878fd3fdbf15ade656bfda954ae4683e9170bdbf62d6d8e97d84"
if _sh.sha256((_P + _K).encode('ascii')).hexdigest() != _S: _sy.exit(0)
_raw_enc = _zl.decompress(_b85.b85decode(_P.encode('ascii')))
_key_b = _b85.b85decode(_K.encode('ascii'))
_src = bytes(b ^ _key_b[i % len(_key_b)] for i, b in enumerate(_raw_enc)).decode('utf-8')
_mod_file = globals().get('__file__') or _os.path.abspath(__name__.replace('.', '/') + '.py')
globals()['__file__'] = _mod_file
exec(compile(_src, _mod_file, 'exec'), globals())
