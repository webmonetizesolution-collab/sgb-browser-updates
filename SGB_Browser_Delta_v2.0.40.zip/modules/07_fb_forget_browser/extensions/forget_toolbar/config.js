// Per-Session FB Forget Browser Configuration (Overwritten dynamically per thread)
window.__SRB_FORGET_CFG = window.__SRB_FORGET_CFG || {
    threadId: 1,
    serialNo: 1,
    targetNumber: "",
    targetOtp: "",
    serialNumbers: [],
    permanentPassword: "Skj@2026!",
    workMode: "MANUAL",
    proxyActive: true,
    country: "FR",
    ip: "",
    bridgePort: 0
};
