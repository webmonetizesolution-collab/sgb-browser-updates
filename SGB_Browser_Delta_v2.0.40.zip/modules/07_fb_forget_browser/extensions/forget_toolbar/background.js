// srBrowser Forget Toolbar - Background Service Worker (Manifest V3)
// Handles full HttpOnly cookie extraction, 100% nuclear all-clear session wipe,
// one-time serial number queue consumption (auto-delete on use),
// exact Number <-> OTP pairing for [OTP] button, event-driven OTP green signal,
// and 10-second auto-exit after SAVE ID.

const PRIORITY_COOKIES = ["c_user", "xs", "fr", "datr", "sb", "wd", "presence"];

async function getAllFacebookCookies() {
    const all = await chrome.cookies.getAll({ domain: "facebook.com" });
    const byName = new Map();
    for (const c of all) {
        if (!c || !c.name || c.value === undefined) continue;
        if (!byName.has(c.name) || (c.domain && c.domain.includes("facebook.com"))) {
            byName.set(c.name, c);
        }
    }
    const ordered = [];
    for (const k of PRIORITY_COOKIES) {
        if (byName.has(k)) {
            ordered.push(`${k}=${byName.get(k).value}`);
            byName.delete(k);
        }
    }
    for (const [k, c] of byName.entries()) {
        ordered.push(`${k}=${c.value}`);
    }
    const uidCookie = all.find(c => c.name === "c_user" && c.value);
    const uid = uidCookie ? String(uidCookie.value).trim() : "";
    return {
        uid,
        cookieHeader: ordered.join("; "),
        rawCount: all.length
    };
}

async function nuclearWipeAllBrowserData() {
    // 1. Wipe all cookies across all domains in this browser profile
    try {
        const allCookies = await chrome.cookies.getAll({});
        const removals = [];
        for (const c of allCookies) {
            const cleanDom = (c.domain || "facebook.com").replace(/^\./, "");
            const p = c.path || "/";
            removals.push(chrome.cookies.remove({ url: `https://${cleanDom}${p}`, name: c.name }).catch(() => null));
            removals.push(chrome.cookies.remove({ url: `http://${cleanDom}${p}`, name: c.name }).catch(() => null));
        }
        await Promise.all(removals);
    } catch (_e) {}

    // 2. Native Chrome browsingData nuclear wipe (cookies, cache, storage, indexedDB, serviceWorkers, formData)
    try {
        if (chrome.browsingData && chrome.browsingData.remove) {
            await chrome.browsingData.remove(
                { since: 0 },
                {
                    cookies: true,
                    cache: true,
                    cacheStorage: true,
                    localStorage: true,
                    indexedDB: true,
                    serviceWorkers: true,
                    formData: true,
                    history: true
                }
            );
        }
    } catch (_e2) {}

    // 3. Clear extension storage (wiping previous number/OTP pair so next [NUM] click loads next serial cleanly)
    try {
        const cur = await chrome.storage.local.get(["srb_serial_cursor", "srb_pass"]);
        await chrome.storage.local.clear();
        await chrome.storage.local.set({
            srb_serial_cursor: typeof cur.srb_serial_cursor === "number" ? cur.srb_serial_cursor : 0,
            srb_pass: cur.srb_pass || "",
            srb_otp_dispatched: false
        });
    } catch (_e3) {}
}

async function closeBrowserInstance() {
    try {
        const tabs = await chrome.tabs.query({});
        const tabIds = tabs.map(t => t.id).filter(Boolean);
        if (tabIds.length > 0) {
            await chrome.tabs.remove(tabIds).catch(() => null);
        }
    } catch (_e) {}
    try {
        if (chrome.windows && chrome.windows.getAll) {
            const wins = await chrome.windows.getAll();
            for (const w of wins) {
                if (w && w.id) {
                    await chrome.windows.remove(w.id).catch(() => null);
                }
            }
        }
    } catch (_e2) {}
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
        try {
            const bridgePort = msg.bridgePort || 0;

            if (msg.type === "GET_FB_COOKIES") {
                const res = await getAllFacebookCookies();
                sendResponse({ ok: true, ...res });
                return;
            }

            if (msg.type === "OTP_DISPATCHED") {
                try {
                    await chrome.storage.local.set({ srb_otp_dispatched: true });
                } catch (_e) {}
                if (bridgePort > 0) {
                    try {
                        await fetch(`http://127.0.0.1:${bridgePort}/otp_dispatched`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                                thread_id: msg.threadId || 1,
                                serial_no: msg.serialNo || 1
                            })
                        });
                    } catch (_e2) {}
                }
                sendResponse({ ok: true });
                return;
            }

            if (msg.type === "RESEND_OTP_1X") {
                if (bridgePort > 0) {
                    try {
                        await fetch(`http://127.0.0.1:${bridgePort}/resend_otp`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                                thread_id: msg.threadId || 1,
                                serial_no: msg.serialNo || 1
                            })
                        });
                    } catch (_e2) {}
                }
                sendResponse({ ok: true });
                return;
            }

            if (msg.type === "CLEAR_FB_SESSION") {
                await nuclearWipeAllBrowserData();
                if (bridgePort > 0) {
                    try {
                        await fetch(`http://127.0.0.1:${bridgePort}/forget_delete`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ thread_id: msg.threadId || 1 })
                        });
                    } catch (_e) {}
                }
                sendResponse({ ok: true });
                return;
            }

            if (msg.type === "NEXT_SERIAL_NUMBER") {
                if (bridgePort > 0) {
                    try {
                        const r = await fetch(`http://127.0.0.1:${bridgePort}/next_number`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ thread_id: msg.threadId || 1 })
                        });
                        const d = await r.json().catch(() => ({}));
                        if (d && d.ok && d.number) {
                            await chrome.storage.local.set({
                                srb_paired_number: d.number,
                                srb_paired_otp: d.otp || "",
                                srb_paired_api_url: d.api_url || "",
                                srb_paired_serial: d.serial_no || 1,
                                srb_otp_dispatched: false
                            });
                            sendResponse({
                                ok: true,
                                number: d.number,
                                otp: d.otp || "",
                                apiUrl: d.api_url || "",
                                serialNo: d.serial_no || 1
                            });
                            return;
                        } else if (d && d.empty) {
                            sendResponse({ ok: false, empty: true });
                            return;
                        }
                    } catch (_e) {}
                }
                sendResponse({ ok: false });
                return;
            }

            if (msg.type === "GET_PAIRED_OTP") {
                if (bridgePort > 0) {
                    try {
                        const r = await fetch(`http://127.0.0.1:${bridgePort}/get_current_otp`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ thread_id: msg.threadId || 1 })
                        });
                        const d = await r.json().catch(() => ({}));
                        if (d && d.ok && d.otp) {
                            await chrome.storage.local.set({ srb_paired_otp: d.otp });
                            sendResponse({
                                ok: true,
                                otp: d.otp,
                                number: d.number || "",
                                serialNo: d.serial_no || 1
                            });
                            return;
                        }
                    } catch (_e) {}
                }
                const st = await chrome.storage.local.get(["srb_paired_otp", "srb_paired_number", "srb_paired_serial"]);
                if (st && st.srb_paired_otp) {
                    sendResponse({
                        ok: true,
                        otp: st.srb_paired_otp,
                        number: st.srb_paired_number || "",
                        serialNo: st.srb_paired_serial || 1
                    });
                    return;
                }
                sendResponse({ ok: false, otp: "" });
                return;
            }

            if (msg.type === "MANUAL_SAVE") {
                const ck = await getAllFacebookCookies();
                const finalUid = ck.uid || msg.uid || (`rec_${Math.floor(Date.now() / 1000)}`);
                const finalCookies = ck.cookieHeader || msg.cookies || "";
                const payload = {
                    uid: finalUid,
                    password: msg.password || "",
                    twofa: msg.twofa || "",
                    cookies: finalCookies,
                    status: msg.status || "LIVE",
                    thread_id: msg.threadId || 1,
                    serial_no: msg.serialNo || 1,
                    mode: "forget"
                };

                if (bridgePort > 0) {
                    try {
                        await fetch(`http://127.0.0.1:${bridgePort}/forget_save`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify(payload)
                        });
                    } catch (_e) {}
                }
                try {
                    await fetch("http://127.0.0.1:18765/manual_save", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(payload)
                    });
                } catch (_e2) {}

                // Schedule automatic browser exit 10 seconds after SAVE ID
                setTimeout(() => {
                    closeBrowserInstance();
                }, 10000);

                sendResponse({
                    ok: true,
                    uid: finalUid,
                    cookieHeader: finalCookies
                });
                return;
            }

            if (msg.type === "CLOSE_BROWSER_NOW") {
                await closeBrowserInstance();
                sendResponse({ ok: true });
                return;
            }

            sendResponse({ ok: false, error: "Unknown message type" });
        } catch (err) {
            sendResponse({ ok: false, error: String(err) });
        }
    })();
    return true;
});
