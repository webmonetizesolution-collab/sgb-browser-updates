// ==UserScript==
// srBrowser FB Forget Ultra-Slim Floating Toolbar & Smart Recovery Engine
// Exact 38px 2-Row Architecture with 8 Buttons:
// [FORGET] [NUM] [OTP] [RESEND] [2FA] [PASS] [DELETE] [SAVE ID]
// Instant European/Global Facebook Cookie Consent Blocker Auto-Accept
// Dual Gateway Support: Old (limited.facebook.com) & New (m.facebook.com)
// Event-Driven Green LED Signal (Strict OTP Dispatch Confirmation)
// One-time Serial Queue (Auto-Delete on [NUM] click) + 100% Exact Number <-> OTP Pairing
// ==/UserScript==

(function() {
    'use strict';

    var CFG = window.__SRB_FORGET_CFG || {
        threadId: 1,
        serialNo: 1,
        targetNumber: '',
        targetOtp: '',
        serialNumbers: [],
        permanentPassword: 'Skj@2026!',
        workMode: 'MANUAL',
        gatewayMode: 'old',
        gatewayUrl: 'https://limited.facebook.com/login/identify/?ctx=recover',
        proxyActive: false,
        country: 'IT',
        ip: '',
        bridgePort: 0
    };

    var state = {
        lastPassword: CFG.permanentPassword || localStorage.getItem('srb_forget_pass') || 'Skj@2026!',
        twoFaKey: '',
        lastUid: '',
        twoFaSetupActive: false,
        ledGreen: false,
        otpSignalNotified: false,
        pairedNumber: '',
        pairedOtp: '',
        pairedSerial: CFG.serialNo || 1,
        usedLocalPrimary: false,
        serialCursor: 0,
        cookieDismissedTs: 0,
        resendCount: 0
    };

    function getForgetGatewayUrl() {
        if (CFG && CFG.gatewayUrl) return CFG.gatewayUrl;
        if (CFG && String(CFG.gatewayMode || '').toLowerCase() === 'old') {
            return 'https://limited.facebook.com/login/identify/?ctx=recover';
        }
        if (window.location.hostname && window.location.hostname.indexOf('limited.facebook.com') >= 0) {
            return 'https://limited.facebook.com/login/identify/?ctx=recover';
        }
        return 'https://m.facebook.com/login/identify/';
    }

    // Instantaneous Facebook GDPR / European Cookie Consent Auto-Dismissal
    function autoDismissCookieBanner() {
        try {
            var now = Date.now();
            if (now - state.cookieDismissedTs < 350) return false;

            // 1. Direct attribute selectors used by Facebook mobile & desktop cookie banners
            var directSelectors = [
                'button[data-cookiebanner="accept_button"]',
                'button[data-cookiebanner="accept_only_essential_button"]',
                'button[data-testid="cookie-policy-manage-dialog-accept-button"]',
                '[aria-label="Allow all cookies" i]',
                '[aria-label="Allow essential and optional cookies" i]',
                '[aria-label="Only allow essential cookies" i]',
                '[aria-label="Decline optional cookies" i]',
                '[aria-label="Accept All" i]',
                'form[action*="cookie/consent"] button[type="submit"]',
                'form[action*="cookie/consent"] input[type="submit"]'
            ];

            for (var i = 0; i < directSelectors.length; i++) {
                var btn = document.querySelector(directSelectors[i]);
                if (btn && !btn.disabled && isVis(btn)) {
                    state.cookieDismissedTs = now;
                    try { btn.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (_es) {}
                    try { btn.focus(); } catch (_e0) {}
                    try { btn.click(); } catch (_e1) {}
                    try {
                        btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
                    } catch (_e2) {}
                    return true;
                }
            }

            // 2. Text-based detection when "Allow the use of cookies by Facebook on this browser?" is shown
            var bodyTxt = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();
            if (
                bodyTxt.indexOf('allow the use of cookies by facebook') >= 0 ||
                bodyTxt.indexOf('use cookies and similar technologies') >= 0 ||
                bodyTxt.indexOf('allow all cookies') >= 0 ||
                bodyTxt.indexOf('decline optional cookies') >= 0 ||
                bodyTxt.indexOf('allow essential and optional cookies') >= 0
            ) {
                var candidates = document.querySelectorAll('button, [role="button"], input[type="submit"], a[role="button"], div[tabindex="0"], span');
                var acceptTexts = [
                    'allow all cookies',
                    'allow essential and optional cookies',
                    'only allow essential cookies',
                    'decline optional cookies',
                    'accept all cookies',
                    'accept all',
                    'allow cookies'
                ];
                for (var p = 0; p < acceptTexts.length; p++) {
                    var targetPhrase = acceptTexts[p];
                    for (var j = 0; j < candidates.length; j++) {
                        var el = candidates[j];
                        if (!isVis(el)) continue;
                        if (el.closest && el.closest('#srb-floating-bar-root')) continue;
                        var t = ((el.innerText || el.value || el.getAttribute('aria-label') || '')).replace(/[\s\u00a0]+/g, ' ').trim().toLowerCase();
                        if (t === targetPhrase || (t.indexOf(targetPhrase) >= 0 && t.length <= targetPhrase.length + 12)) {
                            var clickTarget = (el.closest && el.closest('button, [role="button"], [tabindex="0"]')) || el;
                            state.cookieDismissedTs = now;
                            try { clickTarget.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (_es) {}
                            try { clickTarget.click(); } catch (_ec) {}
                            try {
                                clickTarget.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
                            } catch (_em) {}
                            return true;
                        }
                    }
                }
            }
        } catch (_err) {}
        return false;
    }

    function syncStateFromStorage(cb) {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get([
                'srb_pass',
                'srb_2fa_key',
                'srb_2fa_setup_active',
                'srb_uid',
                'srb_paired_number',
                'srb_paired_otp',
                'srb_paired_serial',
                'srb_serial_cursor',
                'srb_used_local_primary',
                'srb_otp_dispatched'
            ], function(res) {
                if (CFG.permanentPassword) state.lastPassword = CFG.permanentPassword;
                else if (res.srb_pass) state.lastPassword = res.srb_pass;
                if (res.srb_2fa_key) state.twoFaKey = res.srb_2fa_key;
                if (res.srb_2fa_setup_active) state.twoFaSetupActive = true;
                if (res.srb_uid) state.lastUid = res.srb_uid;
                if (typeof res.srb_paired_number === 'string') state.pairedNumber = res.srb_paired_number;
                if (typeof res.srb_paired_otp === 'string') state.pairedOtp = res.srb_paired_otp;
                if (typeof res.srb_paired_serial === 'number') state.pairedSerial = res.srb_paired_serial;
                if (typeof res.srb_serial_cursor === 'number') state.serialCursor = res.srb_serial_cursor;
                if (typeof res.srb_used_local_primary === 'boolean') state.usedLocalPrimary = res.srb_used_local_primary;
                if (res.srb_otp_dispatched === true && !isIdentifySearchPage()) {
                    state.ledGreen = true;
                }
                if (cb) cb();
            });
        } else if (cb) {
            cb();
        }
    }

    function saveStateToStorage(patch) {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            try { chrome.storage.local.set(patch); } catch (_e) {}
        }
    }

    function sendDirectBridgeHttp(payload, cb) {
        var bp = payload.bridgePort || CFG.bridgePort || 0;
        if (!bp) {
            if (cb) cb({ ok: false });
            return;
        }
        var ep = '';
        var bodyObj = { thread_id: payload.threadId || 1, serial_no: payload.serialNo || 1 };
        if (payload.type === 'OTP_DISPATCHED') ep = '/otp_dispatched';
        else if (payload.type === 'RESEND_OTP_1X') ep = '/resend_otp';
        else if (payload.type === 'CLEAR_FB_SESSION') ep = '/forget_delete';
        else if (payload.type === 'NEXT_SERIAL_NUMBER') ep = '/next_number';
        else if (payload.type === 'GET_PAIRED_OTP') ep = '/get_current_otp';
        else if (payload.type === 'MANUAL_SAVE') {
            ep = '/forget_save';
            bodyObj = {
                uid: payload.uid || '',
                password: payload.password || '',
                twofa: payload.twofa || '',
                cookies: payload.cookies || (document.cookie || ''),
                status: payload.status || 'LIVE',
                thread_id: payload.threadId || 1,
                serial_no: payload.serialNo || 1,
                mode: 'forget'
            };
        }
        if (!ep) {
            if (cb) cb({ ok: false });
            return;
        }
        fetch('http://127.0.0.1:' + bp + ep, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyObj)
        }).then(function(r) { return r.json(); }).then(function(d) {
            if (d && payload.type === 'NEXT_SERIAL_NUMBER' && d.ok && d.number) {
                if (cb) cb({
                    ok: true,
                    number: d.number,
                    otp: d.otp || '',
                    apiUrl: d.api_url || '',
                    serialNo: d.serial_no || 1
                });
                return;
            }
            if (d && payload.type === 'GET_PAIRED_OTP' && d.ok && d.otp) {
                if (cb) cb({
                    ok: true,
                    otp: d.otp,
                    number: d.number || '',
                    serialNo: d.serial_no || 1
                });
                return;
            }
            if (cb) cb(d || { ok: true });
        }).catch(function() {
            if (cb) cb({ ok: false });
        });
    }

    function sendBgMessage(payload, cb) {
        payload.threadId = CFG.threadId || 1;
        payload.serialNo = state.pairedSerial || CFG.serialNo || 1;
        payload.bridgePort = CFG.bridgePort || 0;
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
            try {
                chrome.runtime.sendMessage(payload, function(resp) {
                    if (resp && resp.ok) {
                        if (cb) cb(resp);
                    } else {
                        sendDirectBridgeHttp(payload, cb);
                    }
                });
                return;
            } catch (_e) {}
        }
        sendDirectBridgeHttp(payload, cb);
    }

    function isVis(el) {
        if (!el) return false;
        var st = window.getComputedStyle(el);
        if (!st || st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
        var r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
    }

    function setNativeVal(el, val) {
        if (!el) return;
        var prevVal = el.value;
        try {
            el.focus();
            if (el._valueTracker) {
                el._valueTracker.setValue(prevVal);
            }
            var proto = Object.getPrototypeOf(el);
            var desc = Object.getOwnPropertyDescriptor(proto, 'value') ||
                       Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
            if (desc && desc.set) {
                desc.set.call(el, val);
            } else {
                el.value = val;
            }
        } catch (_e) {
            el.value = val;
        }
        try {
            el.dispatchEvent(new InputEvent('input', { bubbles: true, data: val, inputType: 'insertText' }));
        } catch (_e2) {
            el.dispatchEvent(new Event('input', { bubbles: true }));
        }
        el.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function showToast(msg, bg, durationMs) {
        if (!document.body) return;
        var t = document.getElementById('srb-toast');
        if (!t) {
            t = document.createElement('div');
            t.id = 'srb-toast';
            t.style.cssText = [
                'position: fixed !important',
                'bottom: 16px !important',
                'left: 50% !important',
                'transform: translateX(-50%) !important',
                'z-index: 2147483647 !important',
                'padding: 6px 13px !important',
                'border-radius: 20px !important',
                'font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif !important',
                'font-size: 11px !important',
                'font-weight: 700 !important',
                'color: #ffffff !important',
                'max-width: 92vw !important',
                'text-align: center !important',
                'box-shadow: 0 4px 16px rgba(0,0,0,0.65) !important',
                'pointer-events: none !important',
                'transition: opacity 0.2s ease !important'
            ].join(';');
            document.body.appendChild(t);
        }
        t.style.background = bg || '#2563eb';
        t.textContent = msg;
        t.style.opacity = '1';
        clearTimeout(t._timer);
        t._timer = setTimeout(function() {
            t.style.opacity = '0';
        }, durationMs || 2800);
    }

    function copyText(txt, successMsg, bg) {
        if (!txt) {
            showToast('⚠️ Nothing to copy yet!', '#dc2626');
            return;
        }
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(txt).then(function() {
                showToast(successMsg || '📋 Copied!', bg || '#16a34a');
            }).catch(function() {
                fallbackCopy(txt, successMsg, bg);
            });
        } else {
            fallbackCopy(txt, successMsg, bg);
        }
    }

    function fallbackCopy(txt, successMsg, bg) {
        if (!document.body) return;
        var ta = document.createElement('textarea');
        ta.value = txt;
        ta.style.cssText = 'position:fixed;left:-9999px;top:-9999px;';
        document.body.appendChild(ta);
        ta.select();
        try {
            document.execCommand('copy');
            showToast(successMsg || '📋 Copied!', bg || '#16a34a');
        } catch (_e) {
            showToast('⚠️ Copy failed', '#dc2626');
        }
        document.body.removeChild(ta);
    }

    function getUidFromPage() {
        var m = document.cookie.match(/c_user=([0-9]+)/);
        if (m && m[1]) {
            state.lastUid = m[1];
            saveStateToStorage({ srb_uid: m[1] });
            return m[1];
        }
        if (state.lastUid) return state.lastUid;
        var html = document.documentElement ? document.documentElement.innerHTML : '';
        var m2 = html.match(/"USER_ID":"([1-9][0-9]{5,})"/) || html.match(/"ACCOUNT_ID":"([1-9][0-9]{5,})"/);
        if (m2 && m2[1]) {
            state.lastUid = m2[1];
            saveStateToStorage({ srb_uid: m2[1] });
            return m2[1];
        }
        return '';
    }

    function checkIsCheckpoint() {
        var href = (window.location.href || '').toLowerCase();
        var txt = (document.body ? document.body.innerText : '').toLowerCase();
        if (href.indexOf('checkpoint') >= 0 || href.indexOf('identity') >= 0 || href.indexOf('approval') >= 0) return true;
        if (txt.indexOf('confirm your identity') >= 0 || txt.indexOf('help us confirm') >= 0 || txt.indexOf('account locked') >= 0 || txt.indexOf('suspended') >= 0) return true;
        return false;
    }

    // Pure JS RFC-6238 TOTP Generator for [2FA] button
    function base32ToBytes(b32) {
        var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        var cleaned = String(b32 || '').toUpperCase().replace(/[^A-Z2-7]/g, '');
        var bits = "";
        for (var i = 0; i < cleaned.length; i++) {
            var val = alphabet.indexOf(cleaned.charAt(i));
            if (val >= 0) bits += val.toString(2).padStart(5, '0');
        }
        var bytes = [];
        for (var j = 0; j + 8 <= bits.length; j += 8) {
            bytes.push(parseInt(bits.substr(j, 8), 2));
        }
        return new Uint8Array(bytes);
    }

    async function generateTotpAsync(secret) {
        try {
            var keyBytes = base32ToBytes(secret);
            var epoch = Math.floor(Date.now() / 1000);
            var counter = Math.floor(epoch / 30);
            var msg = new Uint8Array(8);
            for (var i = 7; i >= 0; i--) {
                msg[i] = counter & 0xff;
                counter = Math.floor(counter / 256);
            }
            var cryptoKey = await window.crypto.subtle.importKey(
                'raw', keyBytes, { name: 'HMAC', hash: { name: 'SHA-1' } }, false, ['sign']
            );
            var sig = new Uint8Array(await window.crypto.subtle.sign('HMAC', cryptoKey, msg));
            var offset = sig[sig.length - 1] & 0x0f;
            var code = (
                ((sig[offset] & 0x7f) << 24) |
                ((sig[offset + 1] & 0xff) << 16) |
                ((sig[offset + 2] & 0xff) << 8) |
                (sig[offset + 3] & 0xff)
            ) % 1000000;
            return String(code).padStart(6, '0');
        } catch (_e) {
            return '';
        }
    }

    function setLedVisual(active, tooltip) {
        state.ledGreen = !!active;
        var led = document.getElementById('srb-led-dot');
        if (!led) return;
        if (active) {
            led.style.background = '#10b981';
            led.style.boxShadow = '0 0 8px #10b981';
            led.title = tooltip || ('🟢 SMS OTP Dispatched (' + (CFG.country || 'Active') + ')');
        } else {
            led.style.background = '#ef4444';
            led.style.boxShadow = '0 0 7px #ef4444';
            led.title = tooltip || '⏳ Waiting for OTP Dispatch...';
        }
    }

    window.__srbSetOtpGreen = function(active) {
        setLedVisual(active !== false, '🟢 SMS OTP Dispatched Successfully!');
    };

    function isIdentifySearchPage() {
        var href = (window.location.href || '').toLowerCase();
        var bodyTxt = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();
        if (
            href.indexOf('/login/identify') >= 0 &&
            bodyTxt.indexOf('enter the') < 0 &&
            bodyTxt.indexOf('we sent') < 0 &&
            bodyTxt.indexOf("we've sent") < 0 &&
            bodyTxt.indexOf('confirm your account') < 0
        ) {
            return true;
        }
        return false;
    }

    function detectOtpDispatchSuccess() {
        var href = (window.location.href || '').toLowerCase();
        var bodyTxt = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();

        // Reset LED if user is back on initial phone search, method selection screen, or ANY WhatsApp/Email prompt
        if (
            href.indexOf('/login/identify') >= 0 ||
            href.indexOf('/recover/initiate') >= 0 ||
            bodyTxt.indexOf('choose a way to log in') >= 0 ||
            bodyTxt.indexOf('get code or link via whatsapp') >= 0 ||
            bodyTxt.indexOf('login code via whatsapp') >= 0 ||
            bodyTxt.indexOf('code via whatsapp') >= 0 ||
            bodyTxt.indexOf('send to whatsapp') >= 0 ||
            bodyTxt.indexOf('sent to whatsapp') >= 0 ||
            bodyTxt.indexOf('check your whatsapp') >= 0 ||
            bodyTxt.indexOf('login code via email') >= 0 ||
            bodyTxt.indexOf('send code via email') >= 0 ||
            bodyTxt.indexOf('get code via email') >= 0 ||
            bodyTxt.indexOf('get code via sms') >= 0 ||
            bodyTxt.indexOf('send code via sms') >= 0 ||
            bodyTxt.indexOf('get code or link via sms') >= 0 ||
            bodyTxt.indexOf('enter password to log in') >= 0 ||
            bodyTxt.indexOf('find your account') >= 0 ||
            bodyTxt.indexOf('find your profile') >= 0 ||
            bodyTxt.indexOf('enter your mobile number') >= 0
        ) {
            if (
                bodyTxt.indexOf('choose a way to log in') >= 0 ||
                bodyTxt.indexOf('get code or link via whatsapp') >= 0 ||
                bodyTxt.indexOf('login code via whatsapp') >= 0 ||
                bodyTxt.indexOf('code via whatsapp') >= 0 ||
                bodyTxt.indexOf('send to whatsapp') >= 0 ||
                bodyTxt.indexOf('sent to whatsapp') >= 0 ||
                bodyTxt.indexOf('check your whatsapp') >= 0 ||
                bodyTxt.indexOf('login code via email') >= 0 ||
                bodyTxt.indexOf('send code via email') >= 0 ||
                bodyTxt.indexOf('get code via email') >= 0 ||
                bodyTxt.indexOf('get code via sms') >= 0 ||
                bodyTxt.indexOf('send code via sms') >= 0 ||
                bodyTxt.indexOf('get code or link via sms') >= 0 ||
                bodyTxt.indexOf('enter password to log in') >= 0 ||
                (
                    bodyTxt.indexOf('enter the') < 0 &&
                    bodyTxt.indexOf('we sent your code') < 0 &&
                    bodyTxt.indexOf("we've sent your code") < 0 &&
                    bodyTxt.indexOf('we sent a code') < 0 &&
                    bodyTxt.indexOf('confirm your account') < 0 &&
                    bodyTxt.indexOf('confirm your profile') < 0 &&
                    bodyTxt.indexOf('enter code') < 0
                )
            ) {
                if (state.ledGreen) {
                    state.otpSignalNotified = false;
                    setLedVisual(false, '⏳ Waiting for OTP Dispatch...');
                }
                return false;
            }
        }

        // Strict check for OTP confirmation screen across BOTH limited.facebook.com and m.facebook.com
        var isOtpUrl = (
            href.indexOf('/recover/code') >= 0 ||
            href.indexOf('confirmemail.php') >= 0 ||
            href.indexOf('/confirmation/') >= 0 ||
            href.indexOf('account_recovery') >= 0
        );

        var hasOtpInput = false;
        var strictOtpSelectors = [
            'input[name="n"]',
            'input[name="code"]',
            'input[autocomplete="one-time-code"]',
            'input[aria-label*="confirmation code" i]',
            'input[aria-label*="security code" i]',
            'input[aria-label*="code" i]',
            'input[aria-label*="digit" i]',
            'input[placeholder*="code" i]',
            'input[placeholder*="#"]',
            'input[type="number"]'
        ];
        for (var i = 0; i < strictOtpSelectors.length; i++) {
            var el = document.querySelector(strictOtpSelectors[i]);
            if (el && isVis(el)) {
                hasOtpInput = true;
                break;
            }
        }

        var hasOtpText = (
            bodyTxt.indexOf('enter the confirmation code') >= 0 ||
            bodyTxt.indexOf('enter the 6-digit code') >= 0 ||
            bodyTxt.indexOf('enter the 8-digit code') >= 0 ||
            bodyTxt.indexOf('enter the 5-digit code') >= 0 ||
            bodyTxt.indexOf('we sent your code') >= 0 ||
            bodyTxt.indexOf("we've sent your code") >= 0 ||
            bodyTxt.indexOf('we sent a code') >= 0 ||
            bodyTxt.indexOf('please check your phone for a text message') >= 0 ||
            bodyTxt.indexOf('confirm your account') >= 0 ||
            bodyTxt.indexOf('check your sms') >= 0 ||
            bodyTxt.indexOf('check your text messages') >= 0 ||
            bodyTxt.indexOf('enter security code') >= 0 ||
            (hasOtpInput && (bodyTxt.indexOf('via sms') >= 0 || bodyTxt.indexOf('send code again') >= 0 || bodyTxt.indexOf('get a new code') >= 0 || bodyTxt.indexOf("didn't get a code") >= 0))
        );

        if (!hasOtpInput && hasOtpText) {
            var altInps = document.querySelectorAll('input[type="text"], input[type="tel"]');
            for (var j = 0; j < altInps.length; j++) {
                var aEl = altInps[j];
                if (!isVis(aEl)) continue;
                var aAria = (aEl.getAttribute('aria-label') || '').toLowerCase();
                if (aEl.id === 'identify_search_text_input' || aAria.indexOf('mobile') >= 0 || aAria.indexOf('phone') >= 0) continue;
                hasOtpInput = true;
                break;
            }
        }

        if ((isOtpUrl && (hasOtpInput || hasOtpText)) || (hasOtpInput && hasOtpText)) {
            if (!state.ledGreen) {
                setLedVisual(true, '🟢 SMS OTP Dispatched Successfully!');
            }
            if (!state.otpSignalNotified) {
                state.otpSignalNotified = true;
                saveStateToStorage({ srb_otp_dispatched: true });
                sendBgMessage({ type: 'OTP_DISPATCHED' });
            }
            return true;
        }
        return false;
    }

    function findPhoneInputOnPage() {
        var selectors = [
            'input#identify_search_text_input',
            'input[name="email"]',
            'input[type="tel"]',
            'input[placeholder*="mobile" i]',
            'input[placeholder*="phone" i]',
            'input[aria-label*="mobile" i]',
            'input[aria-label*="phone" i]',
            'input[type="text"]'
        ];
        for (var i = 0; i < selectors.length; i++) {
            var el = document.querySelector(selectors[i]);
            if (el && isVis(el)) return el;
        }
        return null;
    }

    function findOtpInputOnPage() {
        var selectors = [
            'input[name="n"]',
            'input[name="code"]',
            'input[autocomplete="one-time-code"]',
            'input[placeholder*="#"]',
            'input[type="number"]',
            'input[placeholder*="code" i]',
            'input[aria-label*="code" i]',
            'input[type="tel"]',
            'input[type="text"]'
        ];
        for (var i = 0; i < selectors.length; i++) {
            var el = document.querySelector(selectors[i]);
            if (el && isVis(el)) return el;
        }
        return null;
    }

    function fillNumberIntoBox(num, serialNo, hasOtp) {
        var cleanNum = String(num || '').trim();
        if (!cleanNum) return false;
        var inp = findPhoneInputOnPage();
        var sLabel = 'Serial #' + (serialNo || 1);
        var otpBadge = hasOtp ? ' • OTP Locked ✓' : '';
        if (inp) {
            setNativeVal(inp, cleanNum);
            if (inp.value !== cleanNum) {
                try { inp.value = cleanNum; } catch (_e) {}
            }
            inp.focus();
            inp.style.outline = '2px solid #2563eb';
            inp.style.boxShadow = '0 0 8px rgba(37,99,235,0.65)';
            showToast('📞 ' + sLabel + ': ' + cleanNum + otpBadge + ' (Removed from Queue)', '#2563eb');
            return true;
        }
        copyText(cleanNum, '📞 ' + sLabel + ' Copied: ' + cleanNum + otpBadge, '#2563eb');
        return false;
    }

    function fillOtpIntoBox(otpCode, serialNo, pairedNum) {
        var cleanOtp = String(otpCode || '').trim();
        if (!cleanOtp) return false;
        var inp = findOtpInputOnPage();
        var sLabel = 'Serial #' + (serialNo || state.pairedSerial || 1);
        if (inp) {
            setNativeVal(inp, cleanOtp);
            inp.focus();
            inp.style.outline = '2px solid #0d9488';
            inp.style.boxShadow = '0 0 8px rgba(13,148,136,0.65)';
            copyText(cleanOtp, '💬 ' + sLabel + ' OTP Filled: ' + cleanOtp, '#0d9488');
            return true;
        }
        copyText(cleanOtp, '💬 ' + sLabel + ' OTP Copied: ' + cleanOtp, '#0d9488');
        return false;
    }

    // 1x Resend OTP handler in DOM + Python bridge
    function handleResendOtpClick() {
        showToast('🔁 Requesting 1x OTP Resend via SMS...', '#7c3aed', 3000);
        if (window.sgb_resend_otp_click) {
            try { window.sgb_resend_otp_click(); } catch (_e) {}
        }
        sendBgMessage({ type: 'RESEND_OTP_1X' });

        // Also perform direct DOM click on resend links if visible
        var nodes = document.querySelectorAll('a, button, [role="button"], span, div, input[type="submit"]');
        var resendPhrases = [
            'send code again',
            'get a new code',
            'send a new code',
            'send new code',
            'resend code',
            'resend sms',
            'send sms again',
            "i didn't get the code",
            "i didn't get a code",
            "didn't get the code",
            "didn't get a code",
            'did not get the code',
            'did not get a code',
            "didn't receive the code",
            "didn't receive a code",
            'get code another way',
            'confirm another way',
            'need another way',
            'try another way'
        ];
        for (var p = 0; p < resendPhrases.length; p++) {
            var phrase = resendPhrases[p];
            for (var i = 0; i < nodes.length; i++) {
                var el = nodes[i];
                if (!isVis(el)) continue;
                if (el.closest && el.closest('#srb-floating-bar-root')) continue;
                var txt = ((el.innerText || el.value || el.getAttribute('aria-label') || ''))
                    .replace(/[\u2018\u2019\u02bc\u2032`´]/g, "'")
                    .replace(/[\s\u00a0]+/g, ' ')
                    .trim()
                    .toLowerCase();
                if (txt === phrase || (txt.indexOf(phrase) >= 0 && txt.length <= phrase.length + 22)) {
                    var target = (el.closest && el.closest('a, button, [role="button"], [tabindex="0"]')) || el;
                    try { target.click(); } catch (_ec) {}
                    return true;
                }
            }
        }
        return false;
    }

    window.__srbTriggerResendOtp1x = handleResendOtpClick;

    // [NUM] Button Click -> Pops 1st available number from central serial queue, deletes it immediately from queue,
    // and locks its exact paired OTP in memory for the [OTP] button!
    function handleNumButtonClick() {
        state.otpSignalNotified = false;
        setLedVisual(false, '⏳ Waiting for OTP Dispatch...');
        syncStateFromStorage(function() {
            sendBgMessage({ type: 'NEXT_SERIAL_NUMBER' }, function(resp) {
                if (resp && resp.ok && resp.number) {
                    state.pairedNumber = resp.number;
                    state.pairedOtp = resp.otp || '';
                    state.pairedSerial = resp.serialNo || 1;
                    saveStateToStorage({
                        srb_paired_number: state.pairedNumber,
                        srb_paired_otp: state.pairedOtp,
                        srb_paired_serial: state.pairedSerial,
                        srb_otp_dispatched: false
                    });
                    fillNumberIntoBox(resp.number, state.pairedSerial, !!(resp.otp || resp.apiUrl));
                    return;
                }

                if (resp && resp.empty) {
                    showToast('⚠️ Queue Empty! All pasted numbers have already been used.', '#dc2626', 3200);
                    return;
                }

                // Fallback only if Python bridge was unreachable (consume each item strictly once!)
                var list = Array.isArray(CFG.serialNumbers) ? CFG.serialNumbers.filter(Boolean) : [];
                if (list.length > 0) {
                    if (state.serialCursor < list.length) {
                        var idx = state.serialCursor;
                        var picked = list[idx];
                        state.serialCursor = idx + 1;
                        state.pairedNumber = picked;
                        state.pairedOtp = '';
                        state.pairedSerial = idx + 1;
                        saveStateToStorage({
                            srb_serial_cursor: state.serialCursor,
                            srb_paired_number: picked,
                            srb_paired_otp: '',
                            srb_paired_serial: idx + 1,
                            srb_otp_dispatched: false
                        });
                        fillNumberIntoBox(picked, idx + 1, false);
                    } else {
                        showToast('⚠️ Queue Empty! All pasted numbers have already been used.', '#dc2626', 3200);
                    }
                    return;
                }

                if (!state.usedLocalPrimary && CFG.targetNumber) {
                    state.usedLocalPrimary = true;
                    state.pairedNumber = CFG.targetNumber;
                    state.pairedOtp = CFG.targetOtp || '';
                    state.pairedSerial = CFG.serialNo || 1;
                    saveStateToStorage({
                        srb_used_local_primary: true,
                        srb_paired_number: state.pairedNumber,
                        srb_paired_otp: state.pairedOtp,
                        srb_paired_serial: state.pairedSerial,
                        srb_otp_dispatched: false
                    });
                    fillNumberIntoBox(CFG.targetNumber, state.pairedSerial, !!state.pairedOtp);
                    return;
                }

                showToast('⚠️ No more numbers in queue! Paste numbers in FB Forget Browser dialog.', '#d97706', 3000);
            });
        });
    }

    // [OTP] Button Click -> Fills the exact OTP paired with the currently active [NUM] serial number!
    function handleOtpButtonClick() {
        syncStateFromStorage(function() {
            // 1. Ask Python bridge for the exact paired OTP (also resolves live API URL if paired)
            sendBgMessage({ type: 'GET_PAIRED_OTP' }, function(resp) {
                if (resp && resp.ok && resp.otp) {
                    state.pairedOtp = resp.otp;
                    if (resp.serialNo) state.pairedSerial = resp.serialNo;
                    saveStateToStorage({
                        srb_paired_otp: state.pairedOtp,
                        srb_paired_serial: state.pairedSerial
                    });
                    fillOtpIntoBox(resp.otp, state.pairedSerial, resp.number || state.pairedNumber);
                    return;
                }

                // 2. Check cached pairedOtp from when [NUM] was clicked
                if (state.pairedOtp) {
                    fillOtpIntoBox(state.pairedOtp, state.pairedSerial, state.pairedNumber);
                    return;
                }

                // 3. If no pre-loaded OTP was given for this number, check clipboard for 5-8 digit OTP
                if (navigator.clipboard && navigator.clipboard.readText) {
                    navigator.clipboard.readText().then(function(clipText) {
                        var m = String(clipText || '').trim().match(/^\d{5,8}$/) || String(clipText || '').match(/\b(\d{5,8})\b/);
                        var code = m ? (m[1] || m[0]) : '';
                        if (code) {
                            fillOtpIntoBox(code, state.pairedSerial, state.pairedNumber);
                        } else {
                            showToast('ℹ️ No OTP paired with Serial #' + (state.pairedSerial || 1) + ' — enter OTP manually.', '#0d9488');
                        }
                    }).catch(function() {
                        showToast('ℹ️ No OTP paired with Serial #' + (state.pairedSerial || 1) + ' — enter OTP manually.', '#0d9488');
                    });
                } else {
                    showToast('ℹ️ No OTP paired with Serial #' + (state.pairedSerial || 1) + ' — enter OTP manually.', '#0d9488');
                }
            });
        });
    }

    // Ultra-Compact 2-Row Floating Bar (Height: 38px) with 8 Buttons:
    // [FORGET] [NUM] [OTP] [RESEND] [2FA] [PASS] [DELETE] [SAVE ID]
    function initFloatingToolbar() {
        if (document.getElementById('srb-floating-bar-root')) return;
        if (!document.documentElement) return;

        var container = document.createElement('div');
        container.id = 'srb-floating-bar-root';
        container.style.cssText = [
            'position: fixed !important',
            'top: 0 !important',
            'left: 0 !important',
            'right: 0 !important',
            'height: 38px !important',
            'z-index: 2147483647 !important',
            'background: #070e22 !important',
            'padding: 2px 3px 2px 3px !important',
            'box-shadow: 0 2px 10px rgba(0,0,0,0.6) !important',
            'border-bottom: 1.5px solid #1d4ed8 !important',
            'box-sizing: border-box !important',
            'user-select: none !important',
            'font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Arial, sans-serif !important'
        ].join(';');

        var btnBase = 'height: 21px; color: #ffffff; font-weight: 800; font-size: 8.8px; border: none; border-radius: 4px; cursor: pointer; padding: 0 2px; line-height: 21px; letter-spacing: 0.1px;';

        container.innerHTML =
            '<div style="display:flex;align-items:center;justify-content:space-between;gap:2px;height:22px;">' +
                '<button id="srb-btn-forget" style="flex:1.05;background:#0284c7;' + btnBase + '">FORGET</button>' +
                '<button id="srb-btn-num" style="flex:0.85;background:#2563eb;' + btnBase + '">NUM</button>' +
                '<button id="srb-btn-fotp" style="flex:0.85;background:#0d9488;' + btnBase + '">OTP</button>' +
                '<button id="srb-btn-resend" title="Resend OTP via SMS (1x)" style="flex:1.0;background:#7c3aed;' + btnBase + '">RESEND</button>' +
                '<button id="srb-btn-2fa" style="flex:0.8;background:#4f46e5;' + btnBase + '">2FA</button>' +
                '<button id="srb-btn-fpass" style="flex:0.9;background:#d97706;' + btnBase + '">PASS</button>' +
                '<button id="srb-btn-fdelete" style="flex:1.0;background:#dc2626;' + btnBase + '">DELETE</button>' +
                '<button id="srb-btn-saveid" style="flex:1.1;background:#16a34a;' + btnBase + '">SAVE ID</button>' +
            '</div>' +
            '<div style="display:flex;align-items:center;justify-content:center;gap:5px;height:12px;margin-top:1px;">' +
                '<span style="color:#94a3b8;font-size:9px;font-weight:700;letter-spacing:0.25px;line-height:11px;">Owner &amp; Developer: SGB Browser Official</span>' +
                '<span id="srb-led-dot" title="⏳ Waiting for OTP Dispatch..." style="display:inline-block;width:7.5px;height:7.5px;border-radius:50%;background:#ef4444;box-shadow:0 0 7px #ef4444;cursor:pointer;flex-shrink:0;"></span>' +
            '</div>';

        if (document.body) {
            document.body.insertBefore(container, document.body.firstChild);
            document.body.style.paddingTop = '40px';
        } else {
            document.documentElement.appendChild(container);
        }

        setLedVisual(state.ledGreen);
        detectOtpDispatchSuccess();

        // 1. [FORGET] -> Opens configured Facebook Find Your Account gateway (Old limited.facebook.com or New m.facebook.com)
        document.getElementById('srb-btn-forget').onclick = function() {
            state.otpSignalNotified = false;
            setLedVisual(false, '⏳ Waiting for OTP Dispatch...');
            saveStateToStorage({ srb_otp_dispatched: false });
            showToast('🔍 Opening Find Your Account...', '#0284c7');
            if (window.sgb_forget_click) {
                window.sgb_forget_click();
            } else {
                window.location.href = getForgetGatewayUrl();
            }
        };

        // 2. [NUM] -> Pops next serial number, auto-deletes it from queue, fills Mobile number box & locks paired OTP
        document.getElementById('srb-btn-num').onclick = function() {
            handleNumButtonClick();
        };

        // 3. [OTP] -> Fills the exact OTP paired with the currently active serial number
        document.getElementById('srb-btn-fotp').onclick = function() {
            handleOtpButtonClick();
        };

        // 4. [RESEND] -> Triggers 1x Resend OTP via SMS
        document.getElementById('srb-btn-resend').onclick = function() {
            handleResendOtpClick();
        };

        // 5. [2FA] -> Fills 2FA TOTP code or opens Facebook 2FA Setup
        document.getElementById('srb-btn-2fa').onclick = function() {
            syncStateFromStorage(function() {
                var codeInp = document.querySelector('input[name="approvals_code"], input[name="n"], input[name="code"], input[autocomplete="one-time-code"], input[type="number"]');
                if (codeInp && isVis(codeInp) && state.twoFaKey && window.location.hostname.indexOf('accountscenter.facebook.com') < 0) {
                    generateTotpAsync(state.twoFaKey).then(function(code) {
                        if (code) {
                            setNativeVal(codeInp, code);
                            copyText(code, '🔐 2FA Code Filled & Copied: ' + code, '#4f46e5');
                        }
                    });
                    return;
                }
                state.twoFaSetupActive = true;
                saveStateToStorage({ srb_2fa_setup_active: true });
                showToast('🔐 Opening Facebook 2FA Setup...', '#4f46e5');
                window.location.href = 'https://accountscenter.facebook.com/password_and_security/two_factor';
            });
        };

        // 6. [PASS] -> Fills Permanent Password into password input & copies to clipboard
        document.getElementById('srb-btn-fpass').onclick = function() {
            syncStateFromStorage(function() {
                var pass = state.lastPassword || CFG.permanentPassword || 'Skj@2026!';
                var passInputs = Array.from(document.querySelectorAll('input[type="password"], input[name="password_new"], input[name="password"], input#password_new')).filter(isVis);
                if (passInputs.length > 0) {
                    passInputs.forEach(function(pi) {
                        setNativeVal(pi, pass);
                    });
                    copyText(pass, '🔑 Password Filled & Copied: ' + pass, '#d97706');
                } else {
                    copyText(pass, '🔑 Password Copied: ' + pass, '#d97706');
                }
            });
        };

        // 7. [DELETE] -> 100% Total Nuclear All-Clear (Cookies, Cache, Storage, Paired Number/OTP) & Reload
        document.getElementById('srb-btn-fdelete').onclick = function() {
            showToast('🗑️ All Clear! Wiping 100% Cookies, Cache & Session Data...', '#dc2626', 3500);
            state.twoFaSetupActive = false;
            state.twoFaKey = '';
            state.lastUid = '';
            state.pairedNumber = '';
            state.pairedOtp = '';
            state.otpSignalNotified = false;
            setLedVisual(false, '⏳ Waiting for OTP Dispatch...');
            try { localStorage.clear(); } catch (_e) {}
            try { sessionStorage.clear(); } catch (_e) {}
            try {
                document.cookie.split(';').forEach(function(c) {
                    var eq = c.indexOf('=');
                    var nm = eq > -1 ? c.substr(0, eq).trim() : c.trim();
                    if (nm) {
                        document.cookie = nm + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/';
                        document.cookie = nm + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=.facebook.com';
                    }
                });
            } catch (_e2) {}
            try {
                if (window.indexedDB && window.indexedDB.databases) {
                    window.indexedDB.databases().then(function(dbs) {
                        dbs.forEach(function(db) {
                            if (db && db.name) window.indexedDB.deleteDatabase(db.name);
                        });
                    });
                }
            } catch (_e3) {}
            try {
                if (window.caches && window.caches.keys) {
                    window.caches.keys().then(function(keys) {
                        keys.forEach(function(k) { window.caches.delete(k); });
                    });
                }
            } catch (_e4) {}
            try {
                if (navigator.serviceWorker && navigator.serviceWorker.getRegistrations) {
                    navigator.serviceWorker.getRegistrations().then(function(regs) {
                        regs.forEach(function(r) { r.unregister(); });
                    });
                }
            } catch (_e5) {}

            sendBgMessage({ type: 'CLEAR_FB_SESSION' }, function() {
                if (window.sgb_delete_click) {
                    try { window.sgb_delete_click(); } catch (_e6) {}
                }
                setTimeout(function() {
                    window.location.href = getForgetGatewayUrl();
                }, 250);
            });
        };

        // 8. [SAVE ID] -> Saves UID + Pass + 2FA + Full Cookies -> Automatically exits browser after 10 seconds!
        document.getElementById('srb-btn-saveid').onclick = function() {
            syncStateFromStorage(function() {
                var isChk = checkIsCheckpoint();
                var status = isChk ? 'DEAD' : 'LIVE';
                var pass = isChk ? '' : (state.lastPassword || CFG.permanentPassword || 'Skj@2026!');
                var twofa = state.twoFaKey || '';
                var fallbackUid = getUidFromPage() || state.pairedNumber || CFG.targetNumber || ('rec_' + Math.floor(Date.now() / 1000));

                if (window.sgb_save_id_click) {
                    try { window.sgb_save_id_click(); } catch (_e) {}
                }

                sendBgMessage({
                    type: 'MANUAL_SAVE',
                    uid: fallbackUid,
                    password: pass,
                    twofa: twofa,
                    cookies: document.cookie || '',
                    status: status
                }, function(resp) {
                    var finalUid = (resp && resp.uid) || fallbackUid;
                    var finalCookies = (resp && resp.cookieHeader) || document.cookie || '';
                    var recLine = finalUid + '|' + pass + '|' + (twofa ? twofa + '|' : '') + finalCookies;
                    copyText(recLine, '✅ Saved ID: ' + finalUid + '! Auto-Closing in 10s...', '#16a34a');

                    var secLeft = 10;
                    var cdInterval = setInterval(function() {
                        secLeft -= 1;
                        if (secLeft > 0) {
                            showToast('✅ ID & Cookies Saved (' + finalUid + ') • Closing in ' + secLeft + 's...', '#16a34a', 1500);
                        } else {
                            clearInterval(cdInterval);
                            showToast('🚪 Closing browser & starting next serial...', '#0284c7', 2000);
                            sendBgMessage({ type: 'CLOSE_BROWSER_NOW' }, function() {
                                try { window.close(); } catch (_e2) {}
                            });
                        }
                    }, 1000);
                });
            });
        };
    }

    syncStateFromStorage(function() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                autoDismissCookieBanner();
                initFloatingToolbar();
                detectOtpDispatchSuccess();
            });
        } else {
            autoDismissCookieBanner();
            initFloatingToolbar();
            detectOtpDispatchSuccess();
        }
    });

    setInterval(function() {
        autoDismissCookieBanner();
        detectOtpDispatchSuccess();
    }, 250);

    var obs = new MutationObserver(function() {
        autoDismissCookieBanner();
        if (document.body && !document.getElementById('srb-floating-bar-root')) {
            initFloatingToolbar();
        }
        if (document.body && document.body.style.paddingTop !== '40px') {
            document.body.style.paddingTop = '40px';
        }
        detectOtpDispatchSuccess();
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });

})();
