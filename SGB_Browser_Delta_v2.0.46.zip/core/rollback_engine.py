# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.rollback_engine
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.rollback_engine'
    _u = "584_DQ3H$3OuXMVcjRKR"
    _p = "1}AyeDo!0gHb`jgbcew)J%J_mP&7i*`Uk3%l{Z5a2wGL-@nUbjnW6Bb*zLgSrYOme6!KGWlThA&1p9xaR9J{xx8pCbU6xMsst%Ztdl9_~B>$k@jqBz634Qoe#DB;xiDGRKzs|=0<6-je$Q9nE)$=&}{7p`h)jNKHh$Tvv-_U#uXy<Q@%>&-w(hE2=jKFsjn8Gq?=-o_-W60b_4yP~T4}0<9z&FeZ;^yyhfqffLMC}qQdn8H$#TuI)F|9-5F#6)#cq`o;`K%}_EW9Gm_-cbxE}7{k*5Q3Z0~vOWKRF1j9TS-8ms}g(e-ct&`PU$09H0+VPVYp0>S96X;to9es~h?KWj8-mZUxjYXm1yc>l9uyRht?r_#_TM`2{2r(u`nNLN(he;Q^e<1?oJJh)W1Qk<Ur(;07n}u`0(To4hp@Y)}>9c5ba7|1o;s^PTPkz6+lj%5_V#x#~aiZHj4mU3pedypn=4+;PS7CQrw>ska8fs;rfVKOgGlGvq<?T>s5hhswA(%FT{Frh?3~4VZ2KWgsDyACa|SB)p&V(FsIz3MAM6^Ks0p)MrLY<%3TFhGzEB;!6T$jwkkRyR-2;v7CN<_8UxHatZ96=>D>oe$t6z&AqHvnMP_jPR4nS$k*s=T1A9=|6*W+@tPj*!W6IP1C`UCbU33~Pre&nxMk>9VGfdGS8OEB4CW~$7jAfHd;;zJIi)KG&lZNJ=G)Rn;|9adBkB|!>|l8GpXL0dS6{&0ezve0d~lcK?-OxZuv-?G?^@qDaG4EwBovw&mZNjEV)Gvgq`a&e+F*{oNP&$GB49*&?PB`ZFd4W6H0y7DP&^(kbJRbe)q~v@=p77(Zj*aJd2@r&hQir0e_8D=3)?dGQ4u18B0~K^7)_oy56RSXD)i6}Yxlwm6uYsFqQv%R=vS5A^eY|~e<5M*PwYtyu<E{WM9twQGuQr;miOUB1n`a^?l2l<_+v)v*{Ttgm<pb>oeTnlect6o#*E&AGLpL-UV5$A0lp&WvhlH1KF#bY$ym1F(X2bXP&;{2+Y=ZK#4Q=@`$uhca%1=uxAGX;2N^;MbM>2I1icJl#}mi`(UF==skA+#JEl$F7%5C9M-ZS*lqLDd`TB)3MdBal3{h=yxvp_Nj^NY_=tB4lq1ZzCLcq7&Ec$gP4gm%o3FU&h7|V**8}%7g<TmGosL+9~J#E9X82y#R=lGezGm^BbdSN*)!M|#(QLgodj3KQaS+PUERJKo<_?c1WVDv8p#8Km51`=PS3fwT8uaPlywe3$M5z+QL&_Qa{d9jg$e4VPH3qK5)f!w?%wcPV7S!4S!o<NV27kgHIfo?G71obtjl5DtuMM!V!9+HzjkKm|Ka+Mj9)>^6iZ5An2qK?fZBayCZGNFS0uO1o@EungB$f1r8!NVa#B{tHG{t*SCepqwMI|~q{>f{=X&@xbT?pqQih`QvW6upi81Z14&wcW<bY)m|>W94}M`7PiFvCx3Ftr=rR3U;|2B{fKMy*U2W&rjnG3}x0<#*TpB>dLFOiwG|qUM1(_Z0u4)Mbu`tV85jqVq}1wsJa7?qm8~QTU=<<L(bxw)L1YZ*|d@P?Vy?b0NGZ8F@Uk-V_liP#Rbn0a4`@8n5TF6Q!+9}8N$>@d0tSLyab$XB8o>Qodq3NxI;F?dGzW^qr%(=PG%43h+S5{=8&k<@VJ2SvSGmX&?T?k^uajc%BQ!`(x$8SbHlS;YBIGC@FueA6>p#>M)k7ok8Gu)Jd!XcG<s7)tjcNY;f<LZbt@+0t0F&1@t^-gYy?so@Jx7$hP8tAup^>lR5YFhfT2L$q~he()rO72c^#;ln~BH;*BLi;JYv61+u-*QO1;)@0C8asL|ILh;Q4J(Qs@L+4QtE*0@mK`Q!hi|{W`;&WdFB2i=vPYm9-ra((Di~K4V0j1(2c"
    _t = "ba7fa49c7c823a760d4319e92657369ad6eb093551e3f1be1a9c9193b45627df"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
