# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.license_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.license_manager'
    _u = "5Z4*x<*$?VnAKo*wa`8}"
    _p = "c;)mFB4Oe)1eE?8l94r%oD{!&gU4T}9$d7W&g(PX?*wN{O@Y?@P}@B=M&fgjb(q2=4$?k;>|qq9#-!TWYeE057wI*t;<rQhvEta`_1`m&i)IUwJQ~{6O;hM0{wR+Gp%fv9@_pg<!Yp7<eHHZ#BCI)CmSywJ)G2W^P>6|klcWK1?b1JJ<+!+H*b<@K9G%R38qqQjBP?1E>?nkLZqAP@23w3Ex0Zk(ye}xAh(|^y5bzDQ;2CT7&}e})<KfsP%1tU7lX0?q3GJWWd>15?MG`?4+yRYXF#u*_JRv)|H;;3NnpK8A4yenqi{l|45#+h7(2eWIP#Px%y&y1|6hC$uA+m=t{ER=@H4WCAWf&y7A_n`deTC3)E<-)bzk_<TUn|Kign!IuPnugFK7H@Dp|M{S-)gCb>P7q<OPtbfhTM)NoIat&YP%~U@6Z*`Y5U2kuMz30&<}fTO@#x~<t@l-rH5JL@O<ftQcep8JV~D)C`jp%&SbH}c1>31WvIBrY~M^5RQTm?>0M(+F+;YFM9WrQlqN4F#-dLnNuM&Hr`hO$IHL^tKvJno^yF()pRe^PgxC^GHCjF;Y&XEJbd^up00v*sZ*;)4kSvP-zKWEo(C+q=fU!E0C~TPLn+jqvJg2u-KmVvC5<!@G+^GY?APKh^dFj^ir%3O!G%*76SEd}sn)I}4RDW4`TBMwY3m5|A1@J(e#fFAYWVAmIZyaB&T)^}4#IR}dA1n!<4z8QoT>@M6Su>5)!V_t&Qvdfj?{dh1fX~qF*uA9Jo>+S*M~qK1TrAn<Pz`_0y9OxG;Th-?jEj0hsRwDtn6~dd0y~S+9!A?;wkLub?x|*wgT)*%Mod!DmullnjER2Dyi!mK7==dTtBV!atQWutgv5#>LWWOXC|Tb&=gk!hW)gTanp$J*B?37{CFp?D3_!wJsx@`v4DqZzEq8mv+sAcsYTI|17iG*5_Lp*p!nFHKM0QznjIWg1Im@psIvhqPJKfYToLRYGnHS#*AI935yF{fWhgPz|lB8w-pz8K$W(?doFPqj}nhme`=AK})8dBIXFBA_3&oyTJHK)?M))Qt#rwgWGX=7q!P0gueB0yO)fVQQ7jskrC_`|@}VH5Y37#QEqn3TQFWi*b<qo3io2zk-Q<6m4yzaO@^Bdkvu(rgudw_7GUVvKi26pI_<5D6=?WdMf1cHAsMG;$WZ7-rps`gRA0ygd)wJW&qle>apvFv83<`r23%E(jju#316qE+qjb-CnWE@@eCI>@AJAJKU2sL#3$KXJtq1kG>k3bcnGR8)Q0C5A|IX7_^6gf?zN&x=HO>Y~$XWV1&yEJa*sE-cn9()#o(3qcsMfAflJ@q&|DvC-D&amPH>&`P7_mZMjw~j0pv_Ad)k*tb=5_M%O~IsFvB0t4ddL2eRCf3H`U{cE;opWk^Wv_vE^6=>*k(OnKR;6fxa_$Hae4>mUgbg(jbXC<C~Y%-w;+Td_Xo(f-I&sRYF$MA9?2c039G`Wd`g8G{jr-)HY@sBEsz*d-;3xZyPmwxVtrwb@W%nAsqyZE-+ZI;@qrF~w!X5Xyq;tug8FO8P>dW{B2?{}>Z#?4Q3{@MFin8|hqu9rDEdOu3QQ|8R^~5mAbzL&A_Z-ESE|SWslg0+%U@lZAOKm9-<u1(uv~Aq)hPqG({skTJ7Wj7zL5{|SMtE4b~xfB!xxc6{r=<pGv}rh3x)#JLM6SC!vvmtdW?uh}rb8U^_RAxx*EO_8Xtb<*kA#CWf7m8*4|qFEs3szsKk5YHp=1Cb_~nI3Lv4L<JJZ9L>lF^AVFBPV%#U4V#xI{*s_?V#qy1XR;GQwZA5YTV?oX&_YSItsXfneQg70z+HyHKD-o7f7?~B<M64VFAmyE*b;;v{^pOLDYOeb(UxXJNIFiW1vqA!k#cEH#-#p$@^NXqewlfU(KN8qoPL~x@uPD%>*;xZ~tx3aoFME2Kr3M#Z$EYleG0&kW=~fWXkAI2rD8!au)c~bQAj)?@Qzyhx01tHDgSZ?X5&~jCKc}FLawKz#yJ#HqyEbF2mG)t_Oy6A<kTM+fE(3%EE^M@qDHyB^2V1p5jGm!7?=AQ?Xy0Ipc?G&Z7LeB+y}f<S)RJ_O0T~reTV#DLGlgmfZSDf!@LyS4{CqW1s$fp>%EctW#S`2H)nY1{~<RkuQ&Whd#%JQNWFtV->BkmR!n*hAmD1UceB8W9GM^UVh=C9Vp(4I~9Ilkge6p=*rKhUy{{O1x_hw_jKFx8Kz6mI}YNGJt}Q!LuXo$;XR<D{p7vAONjV5@caGrY1{N9XX5A%1Agm@Wyj;T*MIMp{b_DrlvxyU(`YUh`@{Yz?wz;}xc=!R!LxXS><354$;O}6?Sx41H3Yd7A>63j?}xY4PX-<{fUH*nK`so73CqF7(Jsvb4APeBnuU7$Eu<<|9pHtnDpSmB=Jzt!1MUVE6&ShzQLr){huFVfO^)|HHP8e#Ql^^ge~fcI&)3V{ZlnMz9I(`<;w4v?!Drs#4OKd5)Wd45A_io8B->H(J9&`^ahsrJGNpOuo$G~+7b({;KaZ#ECkxQUMHKiD`)^uEE@n9))`=eNz1i=iw#~VuM-m{}xHf(iwqq0bTe5Yr6?{RAU#I-;L_Y8nrt8+OA$v`UV+~)=r{JcCRXDDABz5X#h9_81$Ij*6OND-7^Eh*!$8)PGMwZZ2qHH#xyrtb&jv7nL4|kT3G!4rQw|BSfEpQQ_-Fkx14xVL)NScYps1cR)EFW?dObp=<%KH6=PstMjss#NBP7Y`LVNFIpGF5>scB!-bmBsUU9l*8qu}&=!G?3P45vMx!giIl4qOtC@9?m^LxF++^P3tQcpj!0ZM*5)=E?P}DLL@n5ApqW*30Ki?U6<1aY$;k#t$$|r(}%&#piYY4fFTT;"
    _t = "5425cb292c7044817909884617d04efd0a54dfdaee4f3d3b8ed8f6597c010048"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
