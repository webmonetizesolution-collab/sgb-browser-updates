# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.bookmark_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.bookmark_manager'
    _u = "kXt6!8w$iN2E7#-(B*|}"
    _p = "=QgihMaqViMU9hKjs6$3RM)DaCr-QXZ4A;UWdm7!Pnn}3^iz2tywO7=f-!*ertul0Z>bp|fHm+`-N-*qBHsCpa$I~~KX|Ofk4s3GLGwt8uR&T)e@wO~-pe#U(>;33SQsnBj0C(ktLi>bD{=u!`<#QP6mHCV|6a?EjyXhG?JM`iYtTk46NTT(B-jIj6rq$l!%i+3`gzOa2Y4D(ByyBI(CAy6aiC%)SOpfYD1#D{IjFt9L8zkcrR%az+l4;ovU19Fth8?VuQOFh&@~LfwJe^TLK>Q>A`T?3=hH^-xhk2o3HCj#{RD96KbJcVCkF-9in98!4hXiy4%Rn(kd7iune?<1T7UzCbPA(joG2_4w0;7t3GV*w+GzJlHJ2225Y-`juaN_o%MCCu$4j`-vw|bd6prWS)F*~9q15GrVX|?gzT~~7ez!YK5%FP-N&grr4&B<i)-mtuVequ%2}(4IQ4`<;J0Z+yxLvVY8VP2#yg$^zg}N?DXLT`Uo{KgTNq25|8PlX49uw)O)8Mn9&QGDKuCRLJ^#LSze-((nzN+9mg~#y*?dD+W2nlHA5zLl_^4$x3oN$vV0&+zLe@*^>d)DY{^U?P9h66WGZrA(bI|q2O#JS?gW7621jIS(+=+TD?o;(auBR$E&iAt{8?=)fZ_!hO?wUPw!OgDZmQYMjm9flQ#jol}n!C&h_k4#;}Zt8$Z9z=gh<Y>Q-roFmPu{OSdd@Km*ia4B8P?+WTsc2AHJyzLnZyP!Ik)%wlgTTFOfPauiq?1pMWG-OwL?<rK(>ixhPCo35d_oXnNj%|*4LV2N^0>wIa?r>JpZCQm(ONnXtdHba@AxwSZ&gVs{1mC;9bJokrhCZmwvl9i%LuIaazr&-mr-n1_$%|{S$_IsJ&ICNt)y)xBf@)&=ueO!Z5Livjq*e{zm$jK)??s>)U1;%bWf}EqCIHi%Nb0`uZF;HQLyQ$bK(GUvG?l`2sZauxP$_lNm7cQ3?1H)&6>9-+2)1WZfezkZ1YEU_ImJCm$yJ+VBtD?a0QHpHd;q8vb6~6`c$*&T~SzJPZ>KA=(0OuQcNDx9L@5Kobu0ReAymC-o)Ostos4O*!KnKb(}{1jGn=4$3z9KfxjIZUa;<b0&7EJL~VmU8-|cESzsVunMX`>i)=q_-*rRyJu*2~%99V<xioA?H10WF4|SRx7)6I<tY66b<TL;88M+vk+$5kyt^V(2&DQX$XQ0$#CQUBC0D*Gzu3gPOOuO-1z0<vATx(!WRjpyx<B?|d0f&jIS@S4W;kJ7Zn{t8^t<7&sly@`<d5yX;;V=d?NIHII5lQ^MZnzNfC~3`+F#lJ&jctNyWz$$ERNJOX(<zd&ql{56={@bkOjfz9mV@>{lPUO0Cm24<hzA)5lk^sWGU7BExdX_G#addD)j(y&V(R}&CQm`0+8iYFT^|Pqr%sw%)r)^GzaJ@&d3JR@?H#TL`4LW1s!$OjS2L%^E&GHR44((_m9Ci`o|n&6N^S;sJt>Lm-j_`C`k#a|&ShNy2!nhN%m?x#U#V3KZ(dfTh)_F#AB2n&h|A447v|l2wwscDruIq5KC9hEzxhTH!Ft)>{YF$XJ^{_-U{AvBAMEaAfeP`bUn%*RfE{@_03PknG>G}+WBS}X&c(TULdVLgI;Se>7Av#5+Dxh?s#nY~dIOvG-svm3n<WJ?%hk9U-qwpBl$as7wYG(0Xz^T(`s*OPZb3;ujc40F^vSJTU+a$xj>4a~Vs%&R!{4`zVa{&^QD!!}gl4vX_XU7zHv7vr*8*lznzqDa$v-ukPO12shV2|W5^f-t{H3kpnJVQw@Fa<qpg0Y!nD3Tk7hI4!B{{YN--9_kWHl%IT`b{U!?F&G+}_$o2z{GcJi<C1+-lv1fUFgcDsiFJhnn^~ldEAOQ&(3+2-xfkgTdh^_h7#s{*#+@n|sMUnAFYtBA$EG^hmJL-g*P9A7K}(-9xtD(u3pTm!Aan^rN}O*^Yx1JDAAA$|6Mu_^K(Yz^Il;4<fabc+bZkwTJnXiQ@z&g1~Jhj3#350h5M%sKHK_0Ohh~^0QP8Y0#n;!c^lfYx1WSwX!p<i|BL8i%w4^BGo1bL);I(XEO+fEj%O<K>}|Tb9L|SXMal%-S8eNF_daM0_F@W+v6OEmDZ-L?p1}i9e9WcoqKe&<<Ef5ShmKO1}JKr7$t9{n5tvAFGm`H+iM-xqT#j(OZK6}{-m;^wlBQUAiaU`#a!kVN(Y)BD&0N;V^OfJkS-H6*eZg3VJcE0_gKH6_1d|VueHO<_Q6Z>5W}z!pzP`Wn!@&io*lWOG?o~)t(d!}d15$$?TA*co_IH2matJWU>MdHd+6Jp2<@sfp;)c=LaALJ$n*i;u<6kGl_<_;yJ7BA4%A67PgWmdH7C--YbU-^&x{w0a6BGsrTRF?Snn@VfRl50ySy!bD2I&|j`wW9;%z3B_6!*hpjB)#Iz+;v=8kh2{PUwEfinu~63{bobAJCVHfzsk71I9c8%$_5u)|=HtiaRCxznUyTA{s6U~y<spP22AALQQSkqR(lm8d`Enr}=rjwn9rnz!W*nzQRQ4?i%(;`QQInl1lQX)beEo>>m>Yg$>8^&chn+J<P)%OC@Jg&j!R1Uds@9?Ukm*)|6mY1n|HJb)VQiD9J@AE&i99dyEivAhu<qSGm-w{_6gZU~f|>fsR*=$yqnexr{%%W6$;iO%suA{vMYtB6PW8oxk5J*^@JMk9{zb<nrXV;<F_c|JP#uLN8s$0?ymb^VZ5*ZIz<!?_qW+Ved)#vEr`MXhRmW`)@G4sw)X5CyW68sky;AcJgnoH)%3J$=)*DW}1VNzQz-ioLD>;d#F*lR6tykhJ{8&uc3#kW**}!XFY=!pD|lWWCh#j@C+9wk=qCQGD=n3bWQ+o;au#QCTUMYMTS`Soz##Vh{LDFs3#&^ig5ON4*^yuPz0iDMLOir#aTSPbiun4f+JlwAcx2Q9Ui^M31sYK|={D>F10Y1%l?K-#pPBWW{o$03j}4BU*GngPG(Q<Fp5%X?EIvr2AH^bpYt--H{ekl6b9koxwE+)0JGEO3+p6f>0Ibxn*{yC#Hg}PwT{}{+VfHd$D7yn2kKjb}>&IJnKIWVh-7*fc_Rg^|Z&<YmI7`V{<*=E-Q|k>cg~i!hHuCEt>l&ZKukof^g-mic(=9dz5NLIURiId5-djx{Y68kAPoyN;~IyRCNvI%AkiBf6)=3x7hS1SlI4peSz+C-Hb8z12FY=@m57{DB7y1VQ)8FuIJbsq}2kt@$-T}BGUL3(;rc^Jr09>;1LUjE6oB)R(AoJIr9NYPK%Zh6I=HUSB{LtcP|&8f6<t<5o+1!m(oGcYKd+vr&K^dd!rh;d%h|t>z4Aj{WqmPF};mJ-cis{`7H2Q+Wp=hb1V!TArXd`A9BM06TahA{cN@>CRk6nnX-4aE$*qrpsU|mc|<#F<U;>0>g9GPXKc#uzo62)5^JX%^Cy*<AbT~8Q2o=(;+jw<6bsJs2rGU7NwCnss=n+pcf(Dl83?r1JuAJ`nVs("
    _t = "57821512bce583adc944d8681fa8dfcb5c94c219603ad7acb9cfc3a232e5984a"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
