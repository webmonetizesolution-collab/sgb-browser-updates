"use strict";

(function () {
  var savedListCookies = [];
  var currentCookieStr = "";
  var currentUid = "";

  function httpRequest(opts) {
    return new Promise(function (resolve) {
      try {
        var xhr = new XMLHttpRequest();
        xhr.onload = function () {
          resolve(xhr.response || "");
        };
        xhr.onerror = function () {
          resolve("");
        };
        xhr.open(opts.method || "GET", opts.url, true);
        if (opts.headers) {
          Object.keys(opts.headers).forEach(function (k) {
            xhr.setRequestHeader(k, opts.headers[k]);
          });
        }
        if (opts.responseType) {
          xhr.responseType = opts.responseType;
        }
        xhr.send(opts.data || null);
      } catch (e) {
        resolve("");
      }
    });
  }

  var SKIP_COOKIE_ATTRS = {
    path: true,
    domain: true,
    expires: true,
    "max-age": true,
    secure: true,
    httponly: true,
    samesite: true,
    priority: true,
    partitioned: true
  };

  var KNOWN_FB_COOKIE_KEYS = {
    c_user: true,
    xs: true,
    datr: true,
    sb: true,
    fr: true,
    wd: true,
    locale: true,
    presence: true,
    dpr: true,
    m_pixel_ratio: true,
    ps_l: true,
    ps_n: true,
    oo: true,
    dbln: true,
    i_user: true,
    sfiu: true,
    checkpoint: true,
    spin: true,
    usida: true,
    vpd: true,
    fbl_st: true,
    wl_cbv: true
  };

  var CANONICAL_KEY_ORDER = [
    "datr",
    "sb",
    "c_user",
    "locale",
    "oo",
    "ps_l",
    "ps_n",
    "xs",
    "fr",
    "presence",
    "wd",
    "m_pixel_ratio",
    "dpr",
    "i_user",
    "dbln",
    "sfiu",
    "checkpoint"
  ];

  function extractUidFromAny(cookieMap, rawInput) {
    if (cookieMap.c_user && /^\d{5,20}$/.test(cookieMap.c_user)) {
      return cookieMap.c_user;
    }
    if (cookieMap.i_user && /^\d{5,20}$/.test(cookieMap.i_user)) {
      return cookieMap.i_user;
    }
    if (cookieMap.checkpoint) {
      try {
        var cpDec = decodeURIComponent(cookieMap.checkpoint);
        var mCp = cpDec.match(/"u"\s*:\s*"?(\d{5,20})"?/);
        if (mCp && mCp[1]) return mCp[1];
      } catch (e) {}
    }
    if (cookieMap.dbln) {
      try {
        var dbDec = decodeURIComponent(cookieMap.dbln);
        var mDb = dbDec.match(/(\d{7,20})/);
        if (mDb && mDb[1]) return mDb[1];
      } catch (e) {}
    }
    if (rawInput && rawInput.indexOf("|") > -1) {
      var parts = rawInput.trim().split("|");
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i].trim();
        if (/^(1000\d{9,13}|615\d{9,13}|\d{8,17})$/.test(p)) {
          return p;
        }
      }
    }
    return "";
  }

  function parseInputToCookies(rawText) {
    var text = String(rawText || "").trim();
    var cookieMap = {};
    var orderList = [];
    if (!text) {
      return { cookieMap: cookieMap, list: [], uid: "", canonicalString: "" };
    }

    function addPair(rawName, rawVal) {
      var k = String(rawName || "").trim();
      var v = String(rawVal === undefined || rawVal === null ? "" : rawVal).trim();
      if (!k) return;
      var kLow = k.toLowerCase();
      if (SKIP_COOKIE_ATTRS[kLow]) return;
      if (k.indexOf(" ") > -1 || k.indexOf("\t") > -1 || k.indexOf("\n") > -1) return;
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        if (v.length >= 2 && k !== "dbln" && k !== "checkpoint") {
          v = v.slice(1, -1);
        }
      }
      if (!v) return;
      if (cookieMap[k] === undefined) {
        orderList.push(k);
      }
      cookieMap[k] = v;
    }

    // 1. Check if JSON array or JSON object
    if ((text.startsWith("[") && text.endsWith("]")) || (text.startsWith("{") && text.endsWith("}"))) {
      try {
        var parsed = JSON.parse(text);
        var arr = Array.isArray(parsed) ? parsed : (parsed.cookies || []);
        if (Array.isArray(arr)) {
          arr.forEach(function (item) {
            if (item && item.name && item.value !== undefined) {
              addPair(item.name, item.value);
            }
          });
        }
      } catch (e) {}
    }

    // 2. If not parsed as JSON, check pipe-delimited formats (UID|Pass|2FA|Cookie, UID|Cookie, Cookie|UA, etc.)
    if (orderList.length === 0) {
      var candidateSegment = text;
      if (text.indexOf("|") > -1) {
        var pipeParts = text.split("|");
        var bestPart = "";
        var bestScore = -1;
        for (var i = 0; i < pipeParts.length; i++) {
          var seg = pipeParts[i].trim();
          if (seg.indexOf("=") === -1) continue;
          if (/^mozilla\/5\.0/i.test(seg)) continue;
          var score = 0;
          if (seg.indexOf("c_user=") > -1) score += 20;
          if (seg.indexOf("xs=") > -1) score += 20;
          if (seg.indexOf("datr=") > -1) score += 10;
          if (seg.indexOf("sb=") > -1) score += 8;
          if (seg.indexOf("fr=") > -1) score += 8;
          if (seg.indexOf("sfiu=") > -1) score += 6;
          if (seg.indexOf("checkpoint=") > -1) score += 6;
          if (seg.indexOf(";") > -1) score += 5;
          if (score > bestScore) {
            bestScore = score;
            bestPart = seg;
          }
        }
        if (bestPart) {
          candidateSegment = bestPart;
        }
      }

      // 3. Parse Netscape tab-separated lines or semicolon-separated key=value pairs
      var lines = candidateSegment.split(/[\r\n]+/);
      lines.forEach(function (line) {
        var trimmed = line.trim();
        if (!trimmed || trimmed.startsWith("#")) return;
        if (trimmed.indexOf("\t") > -1 && trimmed.split("\t").length >= 7) {
          var cols = trimmed.split("\t");
          addPair(cols[5], cols[6]);
          return;
        }
        var semiParts = trimmed.split(";");
        semiParts.forEach(function (part) {
          var p = part.trim();
          if (!p) return;
          var eqIdx = p.indexOf("=");
          if (eqIdx <= 0) return;
          var k = p.slice(0, eqIdx).trim();
          var v = p.slice(eqIdx + 1).trim();
          if (k.indexOf("|") > -1) {
            var subPipe = k.split("|");
            k = subPipe[subPipe.length - 1].trim();
          }
          if (v.indexOf("|Mozilla/") > -1) {
            v = v.split("|Mozilla/")[0].trim();
          }
          addPair(k, v);
        });
      });
    }

    var uid = extractUidFromAny(cookieMap, text);
    if (!cookieMap.c_user && uid && cookieMap.xs) {
      addPair("c_user", uid);
    }

    // If genuine live session (c_user + xs), strip pre-login / recovery / challenge cookies that break login
    var hasLiveSession = Boolean(cookieMap.c_user && cookieMap.xs);
    if (hasLiveSession) {
      delete cookieMap.pas;
      delete cookieMap.sfiu;
      delete cookieMap.checkpoint;
      delete cookieMap.noscript;
      delete cookieMap.test_cookie;
      delete cookieMap["x-referer"];
      delete cookieMap._GRECAPTCHA;
    }

    // Build deduplicated ordered list
    var finalKeys = [];
    var seen = {};
    CANONICAL_KEY_ORDER.forEach(function (k) {
      if (cookieMap[k] !== undefined && !seen[k]) {
        seen[k] = true;
        finalKeys.push(k);
      }
    });
    orderList.forEach(function (k) {
      if (cookieMap[k] !== undefined && !seen[k]) {
        seen[k] = true;
        finalKeys.push(k);
      }
    });

    var list = finalKeys.map(function (k) {
      return { name: k, value: cookieMap[k] };
    });
    var canonicalString = list
      .map(function (item) {
        return item.name + "=" + item.value;
      })
      .join(";");
    if (canonicalString) canonicalString += ";";

    return {
      cookieMap: cookieMap,
      list: list,
      uid: uid,
      hasLiveSession: hasLiveSession,
      canonicalString: canonicalString
    };
  }

  function clearAllFacebookCookies() {
    return new Promise(function (resolve) {
      if (!chrome.cookies) {
        resolve();
        return;
      }
      chrome.cookies.getAll({ domain: "facebook.com" }, function (cookies) {
        if (!cookies || !cookies.length) {
          resolve();
          return;
        }
        var removals = [];
        cookies.forEach(function (c) {
          var cleanDom = (c.domain || "www.facebook.com").replace(/^\./, "");
          var proto = c.secure ? "https://" : "http://";
          var url = proto + cleanDom + (c.path || "/");
          removals.push(
            new Promise(function (res) {
              try {
                chrome.cookies.remove({ url: url, name: c.name }, function () {
                  res();
                });
              } catch (e) {
                res();
              }
            })
          );
          removals.push(
            new Promise(function (res) {
              try {
                chrome.cookies.remove({ url: "https://www.facebook.com/", name: c.name }, function () {
                  res();
                });
              } catch (e) {
                res();
              }
            })
          );
        });
        Promise.all(removals).then(function () {
          resolve();
        });
      });
    });
  }

  function setFacebookCookies(cookieList) {
    var exp = Math.floor(Date.now() / 1000) + 365 * 86400;
    var urls = [
      "https://www.facebook.com/",
      "https://m.facebook.com/",
      "https://mbasic.facebook.com/",
      "https://business.facebook.com/",
      "https://web.facebook.com/"
    ];
    var promises = [];
    cookieList.forEach(function (item) {
      urls.forEach(function (u) {
        promises.push(
          new Promise(function (resolve) {
            try {
              chrome.cookies.set(
                {
                  url: u,
                  domain: ".facebook.com",
                  name: item.name,
                  value: item.value,
                  path: "/",
                  secure: true,
                  sameSite: "no_restriction",
                  expirationDate: exp
                },
                function (res) {
                  if (!res && chrome.runtime && chrome.runtime.lastError) {
                    chrome.cookies.set(
                      {
                        url: u,
                        domain: ".facebook.com",
                        name: item.name,
                        value: item.value,
                        path: "/",
                        secure: true,
                        expirationDate: exp
                      },
                      function () {
                        resolve();
                      }
                    );
                  } else {
                    resolve();
                  }
                }
              );
            } catch (e) {
              resolve();
            }
          })
        );
      });
    });
    return Promise.all(promises);
  }

  function fetchEaagToken() {
    return httpRequest({
      url: "https://business.facebook.com/content_management",
      method: "GET"
    }).then(function (body) {
      if (!body || typeof body !== "string") return "";
      var m = body.match(/EAAGNO[a-zA-Z0-9]+/);
      return m && m[0] ? m[0] : "";
    });
  }

  function fetchEaabToken() {
    return httpRequest({
      url: "https://adsmanager.facebook.com/adsmanager/manage/campaigns",
      method: "GET"
    }).then(function (body) {
      if (!body || typeof body !== "string") return "";
      var m = body.match(/EAAB[a-zA-Z0-9]+/);
      if (m && m[0]) return m[0];
      var redirectUrl = "";
      var rx = /window\.location\.replace\("(.*?)"\)/g;
      var match;
      while ((match = rx.exec(body)) !== null) {
        if (match[1]) {
          try {
            redirectUrl = decodeURIComponent(match[1].replace(/\\\/|\\\//g, "/"));
          } catch (e) {
            redirectUrl = match[1];
          }
        }
      }
      if (!redirectUrl) return "";
      return httpRequest({ url: redirectUrl, method: "GET" }).then(function (body2) {
        if (!body2 || typeof body2 !== "string") return "";
        var m2 = body2.match(/EAAB[a-zA-Z0-9]+/);
        return m2 && m2[0] ? m2[0] : "";
      });
    });
  }

  function renderSavedCookieItem(entry) {
    if (!entry || !entry.uid) return;
    var container = document.querySelector("#list_cookie");
    if (!container) return;
    var existing = document.querySelector("#cc_" + entry.uid);
    var safeName = entry.name ? decodeURI(String(entry.name).replace(/\\/g, "\\")) : "Facebook Account";
    var innerHtml =
      " " +
      entry.uid +
      " - <span class='fullname'> " +
      safeName +
      " </span> <span class='delete' uid='" +
      entry.uid +
      "'>X</span>";

    if (existing) {
      existing.innerHTML = innerHtml;
    } else {
      var html =
        "<div id='cc_" +
        entry.uid +
        "' class='cc' uid='" +
        entry.uid +
        "'>" +
        innerHtml +
        "</div>";
      container.insertAdjacentHTML("afterbegin", html);
    }

    var rowEl = document.querySelector("#cc_" + entry.uid);
    if (rowEl) {
      rowEl.onclick = function (ev) {
        if (ev.target && ev.target.classList && ev.target.classList.contains("delete")) {
          return;
        }
        for (var idx = 0; idx < savedListCookies.length; idx++) {
          if (savedListCookies[idx].uid === entry.uid) {
            var cStr = savedListCookies[idx].cookie;
            var uaChecked = document.querySelector('[name="user-agent"]:checked');
            var displayStr = uaChecked ? cStr + "|" + window.navigator.userAgent : cStr;
            document.getElementById("cookieResult").value = displayStr;
            importCookieAndNavigate(cStr);
            break;
          }
        }
      };
    }

    var delEl = document.querySelector("#cc_" + entry.uid + " .delete");
    if (delEl) {
      delEl.onclick = function (ev) {
        ev.stopPropagation();
        var uidToDel = this.getAttribute("uid");
        var closest = this.closest(".cc");
        if (closest) closest.remove();
        for (var idx = 0; idx < savedListCookies.length; idx++) {
          if (savedListCookies[idx].uid === uidToDel) {
            savedListCookies.splice(idx, 1);
            localStorage.listCookies = JSON.stringify(savedListCookies);
            break;
          }
        }
        return false;
      };
    }
  }

  function saveAccountToHistory(uid, cookieStr, tokenStr) {
    if (!uid) return;
    var item = { uid: uid, name: "", cookie: cookieStr, token: tokenStr || "" };
    var found = false;
    for (var i = 0; i < savedListCookies.length; i++) {
      if (savedListCookies[i].uid === uid) {
        item.name = savedListCookies[i].name || "";
        savedListCookies[i] = item;
        found = true;
        break;
      }
    }
    if (!found) {
      savedListCookies.push(item);
    }
    try {
      localStorage.listCookies = JSON.stringify(savedListCookies);
    } catch (e) {}
    renderSavedCookieItem(item);

    if (tokenStr) {
      httpRequest({
        url: "https://graph.facebook.com/me?access_token=" + encodeURIComponent(tokenStr),
        method: "GET",
        responseType: "json"
      }).then(function (resp) {
        if (resp && resp.name) {
          for (var j = 0; j < savedListCookies.length; j++) {
            if (savedListCookies[j].uid === uid) {
              savedListCookies[j].name = resp.name;
              renderSavedCookieItem(savedListCookies[j]);
              break;
            }
          }
          try {
            localStorage.listCookies = JSON.stringify(savedListCookies);
          } catch (e) {}
        }
      });
    }
  }

  function fetchTokensForCurrentSession(showAlertOnMissing) {
    var loader = document.querySelector(".loading-example");
    var alertEl = document.querySelector(".alert-error");
    if (loader) loader.style.display = "block";
    if (alertEl) alertEl.textContent = "";

    return Promise.all([fetchEaagToken(), fetchEaabToken()]).then(function (results) {
      var eaag = results[0] || "";
      var eaab = results[1] || "";
      if (loader) loader.style.display = "none";

      var tr1 = document.getElementById("tokenResult");
      var tr2 = document.getElementById("tokenResult2");
      if (tr1) tr1.value = eaag;
      if (tr2) tr2.value = eaab;

      if (alertEl) {
        if (!eaag && showAlertOnMissing) {
          alertEl.style.color = "#d9534f";
          alertEl.textContent = "To get EAAG token, please log in and authenticate at business.facebook.com";
        } else {
          alertEl.textContent = "";
        }
      }

      if (currentUid && currentCookieStr) {
        saveAccountToHistory(currentUid, currentCookieStr, eaag || eaab);
      }
      return { eaag: eaag, eaab: eaab };
    });
  }

  function loadCurrentBrowserCookies(fetchTokensNow) {
    chrome.cookies.getAll({ domain: "facebook.com" }, function (cookies) {
      if (!cookies || !cookies.length) {
        return;
      }
      var rawPairs = cookies
        .map(function (c) {
          return c.name + "=" + c.value;
        })
        .join(";");
      var parsed = parseInputToCookies(rawPairs);
      if (!parsed.uid && !parsed.cookieMap.c_user) {
        return;
      }
      currentUid = parsed.uid || parsed.cookieMap.c_user || "";
      currentCookieStr = parsed.canonicalString;

      var uaChecked = document.querySelector('[name="user-agent"]:checked');
      var displayStr = currentCookieStr;
      if (uaChecked) {
        displayStr += "|" + window.navigator.userAgent;
      }
      var cookieBox = document.getElementById("cookieResult");
      if (cookieBox && (!cookieBox.value || cookieBox.value.trim() === "")) {
        cookieBox.value = displayStr;
      }
      var fbIdEl = document.getElementById("fb_id");
      if (fbIdEl && currentUid) {
        fbIdEl.innerHTML = "Facebook id : " + currentUid;
      }
      if (fetchTokensNow && parsed.hasLiveSession) {
        fetchTokensForCurrentSession(true);
      }
    });
  }

  function determineTargetFacebookUrl(parsed) {
    if (parsed.hasLiveSession) {
      return "https://www.facebook.com/";
    }
    if (parsed.cookieMap.checkpoint) {
      return "https://m.facebook.com/checkpoint/";
    }
    if (parsed.cookieMap.sfiu) {
      return "https://m.facebook.com/recover/password/";
    }
    return "https://www.facebook.com/";
  }

  function navigateActiveTabToFacebook(targetUrl) {
    return new Promise(function (resolve) {
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var tab = tabs && tabs[0] ? tabs[0] : null;
        if (!tab || !tab.id) {
          chrome.tabs.create({ url: targetUrl, active: true }, function () {
            resolve();
          });
          return;
        }
        chrome.tabs.update(tab.id, { url: targetUrl }, function () {
          resolve();
        });
      });
    });
  }

  function importCookieAndNavigate(rawInput) {
    var alertEl = document.querySelector(".alert-error");
    var fbIdEl = document.getElementById("fb_id");
    var tr1 = document.getElementById("tokenResult");
    var tr2 = document.getElementById("tokenResult2");
    if (tr1) tr1.value = "";
    if (tr2) tr2.value = "";
    if (alertEl) alertEl.textContent = "";

    var parsed = parseInputToCookies(rawInput);
    if (!parsed.list.length) {
      if (alertEl) {
        alertEl.style.color = "#d9534f";
        alertEl.textContent = "Invalid cookie format. Please paste a valid Facebook cookie.";
      }
      return Promise.resolve(false);
    }

    currentCookieStr = parsed.canonicalString;
    currentUid = parsed.uid || "";

    var uaChecked = document.querySelector('[name="user-agent"]:checked');
    var cookieBox = document.getElementById("cookieResult");
    if (cookieBox) {
      cookieBox.value = uaChecked
        ? currentCookieStr + "|" + window.navigator.userAgent
        : currentCookieStr;
    }

    if (fbIdEl) {
      if (parsed.hasLiveSession && currentUid) {
        fbIdEl.innerHTML = "Facebook id : " + currentUid;
      } else if (parsed.cookieMap.checkpoint) {
        fbIdEl.innerHTML = "Facebook id : " + (currentUid || "Checkpoint Session");
      } else if (parsed.cookieMap.sfiu) {
        fbIdEl.innerHTML = "Facebook id : " + (currentUid || "Recovery Session (sfiu)");
      } else {
        fbIdEl.innerHTML = currentUid ? "Facebook id : " + currentUid : "";
      }
    }

    var targetUrl = determineTargetFacebookUrl(parsed);

    return clearAllFacebookCookies()
      .then(function () {
        return setFacebookCookies(parsed.list);
      })
      .then(function () {
        if (currentUid) {
          saveAccountToHistory(currentUid, currentCookieStr, "");
        }
        return navigateActiveTabToFacebook(targetUrl);
      })
      .then(function () {
        if (parsed.hasLiveSession) {
          fetchTokensForCurrentSession(false);
        }
        return true;
      });
  }

  document.addEventListener("DOMContentLoaded", function () {
    try {
      if (localStorage.getItem("listCookies") !== null) {
        savedListCookies = JSON.parse(localStorage.listCookies) || [];
      }
    } catch (e) {
      savedListCookies = [];
    }
    for (var i = 0; i < savedListCookies.length; i++) {
      renderSavedCookieItem(savedListCookies[i]);
    }

    loadCurrentBrowserCookies(false);

    var cookieBox = document.getElementById("cookieResult");
    if (cookieBox) {
      cookieBox.onclick = function () {
        cookieBox.select();
      };
    }

    var tokenBox = document.querySelector("#tokenResult");
    if (tokenBox) {
      tokenBox.onclick = function () {
        tokenBox.select();
      };
    }

    var btnImport = document.querySelector("#btnImportCookie");
    if (btnImport) {
      btnImport.onclick = function () {
        var val = cookieBox ? cookieBox.value.trim() : "";
        if (val) {
          importCookieAndNavigate(val);
        }
      };
    }

    var btnGet = document.querySelector("#btnGetAccessToken");
    if (btnGet) {
      btnGet.onclick = function () {
        var val = cookieBox ? cookieBox.value.trim() : "";
        if (val && val !== currentCookieStr) {
          importCookieAndNavigate(val).then(function () {
            fetchTokensForCurrentSession(true);
          });
        } else {
          loadCurrentBrowserCookies(true);
          fetchTokensForCurrentSession(true);
        }
      };
    }

    var btnLoginNew = document.querySelector("#btncookielogout");
    if (btnLoginNew) {
      btnLoginNew.onclick = function () {
        var val = cookieBox ? cookieBox.value.trim() : "";
        if (val) {
          var parsed = parseInputToCookies(val);
          // If the user pasted a cookie in the box and clicked "Login new Facebook", import & login!
          if (parsed.list.length > 0 && (parsed.uid !== currentUid || !currentUid)) {
            importCookieAndNavigate(val);
            return;
          }
        }
        // Otherwise, clear cookies to log into a fresh Facebook account
        clearAllFacebookCookies().then(function () {
          currentUid = "";
          currentCookieStr = "";
          if (cookieBox) cookieBox.value = "";
          var fbIdEl = document.getElementById("fb_id");
          if (fbIdEl) fbIdEl.innerHTML = "";
          navigateActiveTabToFacebook("https://www.facebook.com/login");
        });
      };
    }
  });
})();
