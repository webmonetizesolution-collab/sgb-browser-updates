# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: modules.07_fb_forget_browser.main
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'modules.07_fb_forget_browser.main'
    _u = "fo+Vr<l{}~!f7EWd4RqR"
    _p = "fM-YhQpV8ju`*q74ps1|*eabyoi)wm`=%8ZWPT2O3^Zpb6H!Y3T&G~*w+>ycAa45|$34q`&S|3zA`I)&i1|^tp7080%y`t(V|Q|o<dgGWiArCwP}Yz`YtsR!^~Q_4U1FS#1uB!tleKUQ8tSGnI>{V<?gG7pcHGEmOhgD9^dh6>e!QF=f{t3E;W@$jW28JNa-OTdA^a!#1EX=T%Gp=l^s{H&znMdUCCWh6Uk5d=S~I;MB!+Rzxt>`gfL2LoU%54D%Am&N+mCrQuGaoco8#QC(tgo%W=hsnbXgHQI^ZvGg!I_^ZO8XuhLBH^Y+@_ty4w;`<|DNQ-aHa#D!oO~HnRzE?IT(l(4eP7Ygxz<dj<yQPAo>_l%yW)mcktEP02mbDs`s|0~Pdbp~mzBCVFW"
    _t = "eff9f27fd51a1450dda830e73f1e845270f02d6b0ecdceba8d8bf941ccba49de"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
