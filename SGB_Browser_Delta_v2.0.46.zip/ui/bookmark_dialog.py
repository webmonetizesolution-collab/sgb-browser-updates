# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.bookmark_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.bookmark_dialog'
    _u = "Ab-pj)jel&h|NW+0oQKE"
    _p = "F&eB*2DD>QAb{4|GQ2qAn|w|(Mz^c<N!>!PxPhI+Sgf84wwfgEY%?RDK*U#;qog-0k~V#JzPx&YE8+H!#{tfVuna0#DuEvL68si17Ej}4ZxU(PT=6NGjHviK(aT-M(QXh?ZK$kuTSIwO{4KxpJNUgKMGgS(w-2(OW=kG3wa8{?W|A%w-;{gNq(MG50R8G+waLzR8>8!#P^qz3$0q!+rdcBWz)&xu4Zb4@gBwK{6L}@v<=6rIPD<k*G4R6-NMl1I>I^WOTj&vq+8S_AZPQ<~lZ!rz{bJ;u;-;T{FRsp?MGBMy%?w0OhP?H7y?%>foI|i%A-})8f10Yh0*NzuazEN;HS|u=!!?U>j}l#Y?~)3Nd9>UXX|E=LSZ`{D1&M*9=&RDO5uw4@jqt_cXPeVy+k{((L=j!N8zQY&w;4>JcAf;qv-?$D*s55rRaPAb1{Z`BDL45yPoV2xEDMD0XQ0y-F0IpWL&>86FAZB4U}~%>uBxbE^u}{lnT!@YT+pcnXpeQ5s0@in75lSTL{Wf+>B@D_P;G&Lfynn}o#Q|hBiIO()KTxQIutcR>PI|Ig397}0g~&s?AI1*+N6lTFEQYKmT61bo$6J$<ubV<pJ?ikHQJh_sPY4AKUSX6V9?=X?F9N%oK&}uq6Lzz{#jJp73j-k?!PBwL}rRuya6fWnxfj&Axn^t8e1O*ZOOtZjZ)$=PXRJXZ58}E3g`7ByQU3IRc7z>byBT#V8s=`rqC)l&}b_?{J=~Kh1S+?oQ}?R81JMiMJpVq5>(eNWVlHIh8t(e*x>mfR+N89Lf$hfD;)R=w@xO8zS2{#iAyrn5VkykQH#F@&G4*g(H`|XPP@@3pGQJEJ*#T^*x|0CnAVPIEU015V=%L_ur%mlZ@%$6N1{%{%3H^g>hrIm{ocvJD-fq|K<=xO<xG12wj;3Ks&F5DUC?<5&9?2G#|BM&#*-kxkDjR3$2X_?p(lm~L{sQqk|(E!5NxWBYR+<N`JCg(2WuAJC#(6>nB3qA^qtkVNW`OeypP2Dw$U_WB9_X#Z0F<_Ou(?O1vR$W_d+USxN7v?e}|9-20n$E5HnDD4%EQ{B}L>h&NbU0l!(_AB?`kUaD*vFs;a1U^lBqOj_CxC_!d(&NM|8E{}2O%8>kUZ8Y{7i^i`UVzY84$Viu&n<R#lE$x<7d_u6U|E$aUho2qv_oS0syb$?>UTli1~Wc~J%E5ag_K->TeJ5EMuxYDK<$Jkq-wJ7T=xo;)ewaqT35^$*`)d&5JR%LA;^xYO(ck!t!Pr!MtEWN7-#`i1FN8bF~3QL3OBm{k=zl@OaL2t~kc0{;kdhNHXDwz@XCEKl4mGr@!a8?2`(_QV!iIga!VlMOdcH9j|6Dbb=@3*6i);9avk!5b{WeCbEv`=1DXV9Qq|M;nFq={xr$6KK{mXG@;S7#&}02$gp$1_vdW%nBtyF3e7l6H_Q8lXNA$oXH`B?;FtVe)raX_S-^_|XdWcs5HR)oZj&fhdSpFZdC_t}Jx~38lB7@U-{p+~;Hvc5&R{ke{cv@~!lk*8%N?Ng$c_(R?dekf;%PXi~O%`x0soSWogJhd)BG(1%Tw?HAo_dyV*Q?5qjXyH>oTM1Wn){MtLYHjwMkRP8D?X$4+^m<*bd;W1`RfOAHPA~{_`k-|z3vP+%8>zn4yi%^6tB<4D_@0qd?&$L^~itC@upT0VN0x>XbJBQ|F5M$o8ew|4plL|@!&6At5Q6eX~;_2U6v_JHhjFKpgCG6Oor_`*Oj%@ekGUAg<eiTacICmeAj}VP3I3g!v(5q)SO)*=r2oaU7W3CXf>h*|;2LGo|9L_^}`=@S`Bo;e8(pJ^-y0K59XK>$VU(k^EnwH*kZ5A`$%A1whnH|mx;D)PxbKG&?%YTj;C3&Jw-MJ}lw7@@YQA%^*%{vdopd{@`A3KnPgf8ZAb+TYFUo9FDG%p6sI%U>cT0<iDQ$js+otf*1mstb1d?rN4<g5NoDGcO^A`>cK5ELJd3I{M}l&0jW9>w6QWmA+k;10~|<+ZUrp8(w}*wL*_^?TF}*RPudA}xjUrD9}6ugRt?z%+ekF+?;Lu_C?I)u}>rnR9|&ipZ^9XfnB4!he-m`O}f2VI_{xc$n{zlzXscBavKzXgXD4;*qFnVHqsb`I1p{5r1_7%4Ydq(#wi!1y&6$4Y<a$G%h@!8<*v2be*95!dS@2S03dJwC}6nBngd;tC1hb&B6u$^xM4f_2>;Pw5nq#?gQwJ4okveLEgyX8_WsFE#{P9Ds}f@acyg!#Z6kJJrU-^OA6VHRS!%-?M{>x7VOtSzpihxo%IQJYeNa?Ss^3J(Sa5EZM%Nt9Lb`vrSp_WQp|fR)71Cj?puqSo!_2`@~(q>cVQFA?+M@*XbUi?7o3C$q{;4|@4P}a&cA%=h0@-v12fm<SHf!78u#>|xNVS{J>M0;fEro@!bCh`a8SxPn#Q6DF3cTyIAzf=_WPwBy)k=Jr`$LwB!nIdv_M=4GjztVm5TV9aEOPTQ9+yO|Bm5SO}Rjk2+e2fql3BG4XW=2jCdq++Son|tfmuzvF#Jk9{La}=p<erfeYw-v5A+hvc83T>v#<&lB`9m3u1Vmw=cXZE>f^<htz)0b@7?=#xX(@B6%}A6Ob3acGow5)v<oRPL{y1el`@MC5E<1UD_LWo^JWhfl(R437B<vSr?6UEAmNVFf|H(9UI%Kt~dYPQ_J-1T81%dYe4!WD$Wz|%t?6et?UXw@4;MBaKK2(g|f+38=cqc_+qj7X-U(Qtr(8QDq(}K?W_G|3qc%cSW-Sl-anqEkBOw=sC`!vo`U8ke@xT98?TcDP{+U8{4$UJB4?$gLEikcw*mPeexMypfMjI53u|(s4{bup=nW{@Yt4HInrw_ian?~iOV9FjxgwN?q0bC5U*{X3ip))5fhi+$l@UAk6p-SwO?P0EQc_k#<^mS!@b#&c!kZ&KQ4SAxdPRnD+>{NO+_t4r0j;@L@Fsz=mmSSRovA!5j<HFMOX#i`(Axo^tz~^2K*(5jR#aJhkQ~;6L?#Z1tQqwnFrKH{1eSE-B~z3#tx>IMQ)abuX%<=0#Qt-yWH1Mce(!n@F*Y<IAR)crDE^Hal+x9RU8?w2Te6F`>hARPhHT(^E>_<MNn;FI!z1*ZZhq5r+jJpC>-GiTatwHdW5VMH0|a<lO8%%~12i_1YY{tIY12(;%>LEJyW?zs!346Mnrsm6eKmeHxJ)-23+LoL<|Rqmq23>oaGRhB$W#NWU3ooE;>A0A*R8<=+@}13<ajhoVTbP#+|HaKwIAHy3nU%+a$IVvI1B;yA#2fofPL=2C~S;*F!}FG|7zgx&Im4@a!qf%rI<1&0R-o=_4ba#LqX80h#sOD(6#q6K*;S=EKB-lpDt-IZltf$Zp*X5N7}Jvr*^Sc)Tj)p9c;f6jCOP_jya9qc-cgAxSETABUyRL2<VEOY-TAS{}^}Hgt2mqF#A87tI6^WN5d;u(fH0+U97)-ELHc&IINA+Q`LC-Lr0r^C4+j3k@jG>)cAb#4kXAV4I3>mPA_>K5GaCa`v3m8@5;2S2p^8d9CPi7^E8p&aWzrN7S@%CRNr+0u3%U$m}eZSiulGlE{!|XYk3csdoXZrtUn`aHp7B2j&Qa4D*QP-wPIZXAYUB}vU?)A`4uJgM<U>dY*q"
    _t = "a5b674db928582f6e5a06359aff3843cc93b7075fa5ad5e0db897b29401f73ed"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
