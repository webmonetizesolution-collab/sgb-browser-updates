# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.smart_exit_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.smart_exit_dialog'
    _u = "8X5^S5j_YE))&cE)7W)d"
    _p = "Qf}EN;a4a@U-n6fmo|ZYGl_acT$mWwtr+^<`2wo7NH>Ly`+ibwWWF7U$I3tWQ!SqrD{A;eUFZ|JUwN;Z?w?S&3?zy_vwQSSL*ezm(Z%x&R~_00?K`v6Y-o{*8?s9%K{)dBJWi0|H`FjGL)WRv8xN}qR|CUWZz}%9uX-7Mp?Kkvu664o!yAxQYt^vxABBkcqo5p+_eeWHcSkmN=sFg~Sd|k~kikmP^E`rktT=qH+JtD*NoT}vZ#w1~L+EL?jfWWo^)(w?R!O9itpLKm#d^2NZIJC%=e(^)?W03(H41tUkU~s1ua$vst15c|+mjalXYeH-_&UMMO~L1`JP5y|EDKY7uM33W^({>A+cG-NR0||e5Tl1DIIbeEL`fe7fZXmk0Q>rwXalQNFXmLfucCw=!@DLB25!NF&Qev{beJNZytu8|h(bES4hAkkFxH!!(bKroa+bkWedfukzbOhO(6|?ghN~WK(4rZ}o}7EgWeC1RLY=m2&;8fIGqsi%tJB0@2ffw|q+!ZbqWFDRl~efN>KV#HM?utD!?20LGqMW><&6{7lA%|~D@ER)f8mGP(7z<P&pt&r=>t;J?>my44J{KZ5N^QnRKHeUJ?ZyV*7y~k*(LNs!taKuR>e9qDYzP$CTzn9_R|#jD8jjlF&!8Y^URy|>(j=ym2+iJ5x_3n!i0F^PfK<9V&CT%%#Zht5I9CvwB%G5w`aloJhcUywfz&n8Yd-%UMY1#Tq4;)0wCj2&$Y*-FkiiD<u<|HW`jF|8&kkg-o~(0zEit14zIoWDcIOTkIkQa{SoV;Y0lyQB#~?^;!USXMhxY4Nb`=w$D<zTKp~%Yg64WgSx1E-*TqAEWlD3#E>%9nt6-Atl~jI!AaAi62_|1t<<3>}mv!JR)p~6Xw>O7NaArK<fyO~IJ*Oj-ARh__MTXc{<%~}HY?$reB2eE%X!>gXoWQP4h<0#Hxz$AkoV*)u(Z~=={v=P$(zC6e1v_xYs`4Mv6A~o-us~>(SVI&pTx&luG9^*M*c9}Juy83~F#{v6LhGOJ4%77b`)`SC7s>#Cl<VZWXi&>DT7d7=F0wX31B~A>Z6`RK73e_4>*hJ|#k-lWYI0y8mUxBv%v}Q3aV)~ffR0q?*dtxrQN5ghpw!+l<D(}_4-8%4Kx2{E;d@t#zaas|&}OYA<nW#2AqD@U^b~<+)KYxyiusTgbX)?jH%gG%1^2IXvT3c3A$&7=Pml?ff7>r9!KENuiTqvmM7pEdP)AqRCAkapO=AFxdYr0<%iscke}yn{rxiaf<y}M!;w^eB2L-hBQkSyPlH_aqu)WqrlD*;nx{V(R*FQ~6C-<tgUv^Q`#DbgolirTAMnsF|$VN1RQ?H0{7_>fcD$V{rV}1Yey-X3sroGZxFFS`hyEZP&H#!cNJYX~^jm$m{w)3w&`~{{63yQ63Uo@3Dqm)uKbdNu|dU=SyWRNKDF@oY8C;SkB=e+ePN*_={{-$fO-tqmQ`W1<!lTT;xXK?MnVRl<UQsi(Alja?XWS&!YaL+_c#4JgqWDK41^q!^&@J!g&&2zM;>>i}P%f90!fkPnw(QZwjg}CkbM_lT-8J|;rpvv##UBF^V(Hkl=$BhB_1Aq1xgChjkwB6oNI%=^3RsZWMZ8p!;C@!k$ifzH#;GEb-apR@Bub0@~cRZF}q7_(6>mC_JItC<Vdz4=U->#lP<JNZThz4-g<;WTVXlUy-f&=01fsO7n8|oCl37dSrO5#_q>Of%Dul4H#I+Z|GOGts0PDv7OL@7$*jmp3L_Id#CrpLq$eDd0VKu&}g#9+8FN~Fug)~sm)8skF`A5SpV<ifOy^wC9s%}@g<id&=R>7Da^yxMts2IZ_iH{(U$wWh4@xZ?j?@+(pUMgg>+A&#H_y1;{DUU%kDPwmL+%E3g_N*hW|F)bhg8Lbn++{1QqSbc5=hJk(I&yZuEDSrX1W4re#^KKpYDUM5w=|K)nkpHuN$&Gw2?HM+|Ef!N}=3sqa8rTzM-_-yV>}ftJz$daM&EC4dYGxbmo??FR*9JEM$Pe%lT-~N~&$^DLy8U@CrzcoT`WXEOI>PodX6@JhaE`t2=BIZ9{f22~Wh*v7s>?({51rWbvepyI5VxGcLwkJP)ezg)qgcFWW!vNAer$o3D~pEos9_0DX|=cfGs)}e5<}wJr5<>PKMoWPma2W@T)gu"
    _t = "2712c41cdb657af944c194dafe21b418b5f0ac5b474147e7af831628d7785339"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
