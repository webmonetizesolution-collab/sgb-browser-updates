# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.team_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.team_dialog'
    _u = "))+bZao%l;<CSNbh?s$c"
    _p = "acp%;brw~sMjLG)OZukH={|8SKaI}F0yZ7Y4~=YVFV&5`tJ9pX`Nwm|dy~vZsPb8YkhKnJ&SMU#x}Y(y9C!Cf`Z+RZlVom`Q#X9+M0`N&b6ox`{{WncqsOu#B3mO#btuy7=iRZ3wMm$xE<(SxAwj+pGFR+0?OAAkJo@=@=H|L+brEe<`~>$p%7ao14li~p(2Zx;z|*yI)m7s*Fj<Y7LFJWAjJf%>mfJZoP3%z-XVh`h^)XLJ#<%;xa4)VZN~s7|k%RnE3G`k28Se8SXIpu>E1nia3+0D_Gg?mr?RPB(M5#ac<_R`4CEci%PcQz`dt!e(+`INu2rgd+cD7^}nOFm+e(YLBF_$71-x}w(#~yEa3_2!Vdjy-9vn)5&i7}VE8C=o42r>A5->M;#x|-bMhw@)x!>__iUPO&U8uv4LaYYT`10I43{^SC6D*f<AC!PX2)4+;(-;60{40C7UJtb%8UR)(1uFSaF!>Ih2Qi$j!*7A~>I9;{YiJk}Kq1m`V&vHj95|C>&=8n`iil|>;+YoUgFEy?RhX(la(X7x1Vj7xcBN`ckPm)OSDG(o^5Alub)?Cpb5i81moOe9O_Pq=Mkq%^fx;Hz&n^+;X2q;CK<8;w2fUm5-8jcvxsZ~htIy0Zvz<@nLHtgw(1jy(0#K3k0Clce_Wh(AYa_Wa?;hHK&W4k8}v6iQxf}-F=-N?!i<@b6G4b(flq4V7YA;`1A`C#?<?oqAV6P%LN5j#@4n!oV544r{ixgEM%C{BU~df%RBjW6MX%-ZBWVCDiszxBO~Hs=A7Z<Q(1vZW~bT_x9QhpidVs8IO*p-P7euB2Tpm{r~*{ph#7o6SDNQ_DF<`xu{R(Wf(^$-G1(pGpsp9DC%FvH~rDuKf0uj0_ZpqfMr+3V<Ya5+Q3dsuFYE-JO@$>bbe-o$dx(-r<2U`-I_QS`(xAA$%-i0Md)PzUP=nf4YOU)2wW379RNqwOJHt1MxPk=`HC7T`@gm;;RfD-_7$sA~;Ol(8{IlarTlSrMy4<gvTS$-a*{wyY{&=E!}nUt7Y#kSX$eRzNMysYH{?@wQx``vRkX@0H%n*EJ5DaM-U=NVZ405`*^d@8@lnNtbX)@X0SL%QH7jf?&)>-EisI+yhqS1J=XS~CVerCdy!0brD)-rB~;?FWLums?tNLp;<X@{5=&gE!n~n%G$+ZxFp17!kPmWw){>f4GrJ6LML2HeK8N0>Y!Z|bNGj)acbjLnN9ukJG-6er2p6<`R+*MnE?rPq8)W=vs2jchfyZCZQ*Qm772+FFC8+te4v`F)lBSw`4_Nt2G8UWsCT=yU)XH;^qEbGU$dS0#%kmeYl2?CxnPLv_@yN<{VbZ+<;ub--3uy)fu!v$$-FZ#ak6NW5^zjjZ%|Q`se?0yM%+@^s%CDZ(in-ALSUBY`!6Mj>$j>dgRGW*E|6z~%`jMpzOmF8b2*EKLjAoGWREhb~L9}Azct@PJ!T&X4^E)6y>bF{|j{m=yy2B#+)QR-`g`U%(?m&n{Ha5dJz%^CI6RU(;{0syjV*vN^*lk8j>vWS_nP_iW)ea#Eq(t;(W{Ir}Nf2NZz@YN%FkQP)#=4uPvhyDbYKj@97SJ!!pQYqCbq{gub-d(C"
    _t = "92b734a6a6681512bed3de9e67e699fc6be2414b866a86514dcb5409129231fc"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
