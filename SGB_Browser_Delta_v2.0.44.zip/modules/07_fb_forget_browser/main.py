# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: modules.07_fb_forget_browser.main
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'modules.07_fb_forget_browser.main'
    _u = "cXgNAB}@|nW$WZ`(+8v}"
    _p = "MVKs%YHUj^Myg~29A1~Hhak>BPU2;xCeaHh!Z1o{nEZzd1?7;HK%l#O!?tY=CpsoYY{>Cm-e7o=?Lsn)FKzz{9RAdFHMY`p13It<`VzbcV{bjDX(pOv=h)8`+cas;KU(5|A#EdL@+ELNI;;C~Zv^|8T{X&IM`R2@<k_KwsUr<lZ0A<Azh@Dhn5w5wvIophDU{OWt{kzZ2Ba#~z41L%jZn2x9+*d|FxVO_G6S|AA*jqy7qCrJ%6=^k*JhzvKNwvQpz`2t<^6({R$D&RnIPOTog{#q#x6!}ct?6@zM(8Kax}|E??N$p^>3^ROTyI$`GlR6V9~Az;EGUj0Y9F(b#HjVYj*nar3WqO(dvzmup!>l-2qTXQc24M+Fj_t6-$8FqIQuCbU$H|_2qlaxAv?"
    _t = "0e99aa4363a552ecbced63ed4792a1a902a2c9ec55b0887ee9e5a5d1cd8cb7af"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
