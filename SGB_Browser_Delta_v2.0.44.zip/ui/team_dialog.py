# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.team_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.team_dialog'
    _u = "47=DHIr{gjh}8Cz#Kw5n"
    _p = "(u2yHygQx&72`J6ztpD};JY$L6TDEZG<p%^{duR>){2F>R?4q~b%9{~{E-fvs&rUtEC~uVMy3<dcTmCoRZoFV2#L?}QdDlA0Je}DB<p+^#Iyi}06~7l=>Q^Bo?8B%XDi_}cj{=4IMGE7><0A!UgYaA=Ypx2zf@kihHDx-kkYvQ{oO_2JlQ3o4^V}du5Od)E5%iKPf8Zz$iARMJRF84BO_9H)x5Jz#1+dN`Irn@D?3%(%VY&y;kVBmz31dSs(ryp4VfbQAVE{@8ov`KO~W9p0zbNMfso8Hcdd<!I>f`5!`&*^?SS!wo$se8uxFy^W+~g%KVTs?;n`}A7zfzd@ycU9U&1)15UtCRm06R|1yQ{b_|fK$K2I<12d?6>Z>((zYw)F{x3H*xAzU8BwgI?5O6ATUng7+oM_w7|7EeY97!MfxB5Bl*-2X5Ti}ORdN>>NeRdF7BOCn2dg6(nU2nV=ux`W6RRj5x-&x{@Z)s=h?-PhG2tRCZv6cfERHxCSPCvbq?9P;bE@hI*2f&c(Jr7DN-UnT33(^y&VDB7G-V`~pDE?zt!$^6u1`?->5xM}jH0(VNT2yjedkVp?yhEpdL{(g~|$>`v^(DdZn_Rcp{iPlY?$G7<muKBSaXiF!IIU_y;w*TxdT0LJRC^rdS=*%!h2vL(W&4TkwQDl41Z+Re=X*Q%X0f%Km<2f~1{0eQaJ^rJFmB51=?yf#)PC*XRt0a^hVT&<20y26M#VuY>B^Vvm+OfLr-x!pn`VwIpxMdYMi?b3roVU>cST_PK^=ANV1atG|xt)GEkd`2F**~>U#DR;h*TyDm5^ipAB+dEG#H=bA($uf!UF973ejDemrU4F^1>AkxSo<50FW*!3zY46YU?k{0=yZm12cvY+V;Tez%<rn1ZO1yQ9r&1R8}`0GB5hB6O|Fk2b#EpIGbR!+*wFSA`W)MmP0g*CRav*17yc9nr>4mJL#p4L>ZL-@xEbd}n~_AaqanC5-1RF3(`lrzT``;-!H|E`dc<Vzs!y*aGfMN1j~^i8uC%%f_{_6s6P~95g`sL02KHoS=thf*(sQS5(d=Z59*kc)HU<Rb^Bzu|+U)6|?-C;}3~dgV!Y50@w(#KLZtLYW5+uPwpBET|-8TsG10Imw2FlNk`<?ateE`|P1sd;@10#KF`>*R8UA#>e=x+T^RM}0pTK~k9sO%;*Vh9UVWR;~>@Q}8J6|<pOp0%hktqj-PSb&m09)@OsUjH`9l*YbxkP+c~l4IuXnY3eCeCgR1GrgSa3Hf`~{K2>rG3M*eV@S}(k!x`)@E`ou*8-)mc%Dai#<J#Q9JGN=8;z@Ky~h%qED6?_C&S@;5}o-NrO_>J676)0`Uao7HS!y{mIui5Le>A^@@RfNW9LV$T9-)0?JLgtcnQMs2Vu_K=KktI#FH;hoLfm#BsJT05!PGRzo8s2Omw}0-$^?#K@>}eRbtW<D#(WF+cMt3Kn{KdUUgu>>!_-1j_w24k<(=%ri3yEa#`t{wwrHgJIk)sl@^H9*#jgPAngxd=+BEEms%XWSJahRf-LpK707stR&7>~=B{Cd2v`=OvbV{*;_;-wShKHsAEE`}WfB2LocJ>7F(a*%ni%h>W{2x!25R;h"
    _t = "60d0950201c18a551876735febd9c99909cfd11d0899b35df956805fcb6efd50"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
