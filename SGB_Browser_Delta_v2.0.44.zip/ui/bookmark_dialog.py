# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.bookmark_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.bookmark_dialog'
    _u = "jjg#2f07=hKnq}2cr>C("
    _p = "=gtDe40QR1WO>dTTFT!!Ff~+6^ktuUWoZ0RCU3Vr9%#bWhhn;nG8F)4@u;*eB2W5ErSolk-UYYSwnh==5_VA&nHEf_hV)R6ONdOrDocHDg>GC-y?IiN$XzLA8P&;<{+#SVHRja)anGOOXXkygn`+&4j}6i+{9k-l>lI#aR6ODf&=)r6MHXY(N}k;Bj;5;ctA@``KjLCP@9BYbu)Iaa67?@UQ6E(G4}fp0d-l_MLXDp{wdt3^VR~YBc@B!9@18E}5c(u!Pa)UX+PnLyP1t!eR*NTm@u<*K%H<I;>sgj>b|ymA=uN(P)g*Pv<&h51{l?EtZ8@{cM<P|Lkrwq1o|sgI_rgJbo#bktE5{FrTY!*>D24Tdx$Wet5@VQLxCI=ekl<Q%?xV$cSo@lV5JjlbAv7z6GgNH^>rO23m%k4<%)zhcY2~DP>rzKuBXO=G`Wd68z2F<9)z$O{Q|z!1a>Ro2$%?!VAE~TauvGMUc|_wTQjs^2Ew^EB7uU}@L<fe7x(YTR+!_?*8g?J_^cy;w7|~`haLbKqZiX0ZJnedQ6#GUPS@fJzF7G#8N_w9RO1GTpr>vJ7Add!HNVaJ~P~)q9=JB}~`8g_Os|JeA?ner&z&cp%YaZdWO-Z?b;DVs59!|B~Psc-frDmpC`*MH63{9Lc&z64=!X)geh$`trE6^~^!i!dg$v}bDYMW@4M1U?*{mt}Aj$WPUxNz3HY{}2pMtSC_O;F&^o7iTAOz1s+VV!E!`~MG)T*uaJ!-V`2FFRy%g8A-kcALD2-6;n4L0B_63%Li4&MKr(3LqA>6OCG2kHsju2?p`_3}0fSD3k`|Wjl{M@F|(kJe6jo5p7E_U>B(}PN`)yGq7!pp)U~3i<M7Boa%sE=FtuWl~*QV6dR>7JjP!#4fi5TMpB-xc}X><%6B-SxSgaQhcqcerSy`gQDF(7Sb|EvH~~@x67~K~u=KFfT)qkE&`!1XNht&&J7Md(e-_A1SC8>HaRM#%KnF6l)eIjov?Mm4=uRZN3+_u$4%9Oo8;_CZDY@gMG60X2r;b>&mbt6~wqa#?OF?s+_hTf*y``LACzH6#%b*L|=Md1OiwCJI-TtyQw&QqGxWA-3>CM+uS_VNMulQHy=@5B5+b+aq7Z01{zA|H8a9ka`>(HXHFqR>z&g`|Ie3y;~XJ3t&K0t0@yuJT}Nmdt)a2(e>ISTaC&=93;1r3ND`)tP_o5v@AORTkw`W(UX{g&NZq!w#I@i(rL-(8xA!r$_?y(u-IlREY8i<9UUPFM?f+e);7e9r(6%IY7Ifpwsi+-$YKEkyJPs1z`LaU5gtBSlG2F-%*k<e@R2beBqUf5xIHNPMVTQz`75><zhQYu-AoGTIfu+;a8qT4Tk`VeHC9Q<Z)7R}mh!B%CJ2YiY``aJA{G2D_&RiU)zfEr1wI$s5x5Pmaq3b>Qg*l#xRi-*5Bs{gfSZt4#H=bp5S2kXP@}>4A+G8<YhAYoFWTk9rr^_mCAty(L)UyC$VLK1+A}yGqR@07S!?ouRgoW5Ku(W}NzKDDT>bRy0OXkp6(4sd1d;rG^-1bkh+}WLd#p==ECq!i<kyEHF}j1NaqpV+Q(`%NUKuO!<Lms6qCUh;QMzNd>ArFcu8(Yj(FBdiBFGAU4?SIl}UkM&pHvo-D1n_mUe^M-tN<0o?<?6Qfna=`qE=D2U+lr;)c9-5JL4SlwR>obg0i++(*-2<MfAR+@Z2q0U<ng4GaT#8~H(LX+i=2CTK~#tzzqqtw@QUSh5os|(}=M)<f}Kj)gLaOAW`JDx#OTo6lmn>r4i5I>_cEpYJUYzgXpcVfo-V|jbPYxeWvb_($t!KbS&l8wIhE$uZ8HYlLGlOLSNLZ;`(YrYqy44Ep0L<j8EsBx_4^+mO$-}1UT4~^_rASjykFpzpBog64woiTzXPC@iv@`hL|(W?(v)K@F0Egk%u7)+TuwDZm8PhNMpz%ud_KRd(V$i>i(2hk<0NJ}hka8+e!pPgq_|3W^-6x#b+zs74=SJHbGJw|1;SQBEt>=)Y&#R@^M4tvEbjTZ)#+D~E3P=?0ihZJ}AN@iyO8;<QE?BIDB&A@-qG`#}V_)2F{h^CBBbpKSkMzYLWp2oHR<7WxtF9xe>nhuE631K2`>9jZqkxvl!e}u(3d9Ci|sS@GKVNc`z%S0%%YDL8es<JI?JOIw&(mKDJD<w|ru4JfQI`YK)tI@XKTp3NKBF%mFoc2Ac#jr6(jo{o~$aejX(c51oH^4RSIN8YSJi=345nuseODYDJaW;f_4Bm7bkKGpm9ILU1!dz8ZMe@s|@<JoW*$wLsTWLV!yA0^x6)Bk8?Y^A;0znJ?GW|OSUpMn)4myr$1jWL1x2*z9XN@8;``(4H(9vfwqhi2~j?SCUbZrJ)HnvhR-uU({H!1!i_^s&XE{>15+q`o4&CpssIsQ_7G&Sd8oNcWp5!wMdpm2pyiE4kRWRH52*kf$SujwL7(nk9{6rqFfj*`wRiH52Jdr;E-9|=|Zxmga5!pJF8;KP*AyE7&QtYuvP*_-#CcDYehViy~$YhRZ`zAEU1F#dD`%0h9PDxDM;l%C}tkMs;U)IqXGyB|nuY547-)+qV6y+8j7Ylu<rO7GDi+E1Z&8`q@e#>Xr8J=mk43i<V`VgH)crNWNeu&ifCgy`ljl5|6sn#|8^dB3Ak8miOv%AdWZbN-|);2G@MTiA^q#X?wbUj&1o-C2kUe2V|%jQCj$>aT<VVU&NoKx4<#%K}_V2li&8Z!yD?^;VBwc=rC5+C9*Hn(Q>gLYoxhQd_}cvT1h?Y)=`mPp%BIhfn|${frZ?9dBFKR2Eh7PWg1%E1gDETtE0zIB*g<qW=J_r9DBY>xFy?(&K})&LKIO-aFK(f^$^5owR_mv=m2ffQN9OM^_-uRm3T?zsh{tFZQ<=hH!gNssl{oaDjvIXa+|>cDjL0UxKw~&3f`&3#aqDGo)emQ#qi3_s-SMAKKmwU4DvBHI0;$nZKk>e82^)sRjlAJMd00d9~l;oXPn9QY=mn`J~~?aR*pw4pM*Nds51A9Y%lUw7|wPT<bcIw!^(e^cMyzY&;yJb;m1y=)q1xeYKSETM?-Dk}eTvzsWi;li#IbRqd1N$NBc+of{dCVGF!=AwWR~RHF}s@SkMe_eF;WuzD{?j%BGIiSYaGjSE9r%dYvz-kG0l>-`z5R7hYNm$=BK?o|bw#knFW&um~<jZje3BkK3x=e*bW`}+J4Rx#r;5?h%Baz!-ZIhcRI-EbHW>UfHQPLT7`4e(m0v5foL-UP;Q*f}tpYINPP9-Qr&R7I)(y2-__%*H@Y)$p=s+VFr&A=F6NVl{afR&Aw#_@@+YiP*MCoJ&6PMk>>In4>1(@9>1tf*FRX!27Sv8FfhVc=M5UUtyZ+_;z%|Uxr0+qfRA81BjjOZN>efo{zjq7#={MEnY+!%=U+AeRy9?Mhhjs;U$~;j1s&W(o%h{Kqre2Txa@c#C_EQEhA<KIuQEUbxNmiUY_vBY<oJmyNz_%bkUYQ#NOQk)r~QelbS-`Y&CoKF7WYs7_B({A$=x7S{?`VaYRgj3{NAR=>X_uhMNg3zQF_<Dme)R;m*$yulF_n?uem6K<N37fm06|9K^2lHWwRwa@PmwDsM<8`hbRde4TR-F|yKHu3uWSA6M^m+SC"
    _t = "29244e6e03f01d58b8f5b7341c705816b976ce8eeb98c3e14fab68c4f05c135b"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
