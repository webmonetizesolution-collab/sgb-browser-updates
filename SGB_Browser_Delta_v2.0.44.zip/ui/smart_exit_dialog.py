# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.smart_exit_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.smart_exit_dialog'
    _u = "fHuil`vHMCpMyA*UjjZA"
    _p = "H@MTq<s?B0yT2b*&_s$I;ojU47b*yZGCd~n&IR^*wSpSXN%#E%O}7ET`vT>A2tDxB1iaAC1y|R2e)FfkZpxaHG7NF$A}QM(6N)wP^Hxl0({uC@JMuMfL6=N)pq!$Hd}3~j?}frRUYv*^3-nowTaYf&AK2&)FbpYbqST29Woh8$=A4TpIhJ2bkuHVl07tWSXrE9Rk;U`&(2YI$A4iA*P5G6sUv)Y7blUOIa|#Mh^2LqG`1-nMoZI?`X#txAue@z+YAPVo7nY9*UYGQd#oo!K>W5W1;bd}9bktW==0vi^PTCH-ELef<FCjsd+;X}bljBIxoQ^8w>6lLgG@T)$uCh+oM=^v4x*p%oPrbb1hg9nt6x^MqoW<tPoQ17^+K6ckh6P?K-F9K5B{0zmebt%^&IEnaYHjtQd`j=#mAp~p=o^OZd-MHYN->0+ZYf!}&9vseti#@^ttFPjre4X*uC&y`^MZzo%eB>&K1D$|PdM|-YXtyYx@ekP9rWxxUnbtn35DoAgC#R_tAbmewhyNo84u!+ltEwfWeH<Z!~K*rqxL-qYDPwo@m$as1J<o_VD;wN)6iGYQb+;`=<iWcH+WBmWxU5||BkQ@$r4b>my8aX;p4xUi(h|rBq&}lZXsmQJ8?=vR5#=m^$aA@7KNZ6E7;@1n}Fi+e#^~8J{azv6G8K%=U;70toQ&pmSbK#e^yz$EYL=*O&a}_9NdR$wr#JLPqPVW4hTx@2NckmpV!*^285S95{Sznce*WW#=lqzxKV~@(TH@Xp+d>eyc`KjHn5OdyKfTMk0Orybl3RdeS?{+VV{nV0Rh45#FurWU4tzObZzsn3>IdUn9bbrp<U>dibX#hu}GD?Oh83oES&uu*w<JIsAN`>W1vkJ=fkdq$d*^R-891mEg-?Zm*_?AJwr^^*T7pj1iD|&VTbaHNvTM3K2g<mKJ-Ukx8i!MTvT~_(&XI0a-9$#tTr-_9#4hTeUC^duO6#Vn)1;Bxt+6|I=(^TVCHy1bE-A4>2pKrNPiPPUw(vjD1ihjpY3n1w8g-wWgbX0|FEU-+n@x094Yya$)ajsN4#UAapsDbfK=h{q?r%HNAfdN=9Ns+y2g&7Z5Wg6PMh6J4;q<=Q>r<bWmyV3n!kc<o5qAY!w+i7>L^(jL!Dy4+3;GoUjNR9K^+z6Q^`rAFu@<1qrfYTW07Hld}6XrgJ+tX^Rc3i797<gIGA6@t-;<$h0(s#1zr{Gn_qq?*;Py!kp03J9Y<ZJMaxvmOfe)e33z6b!#V)ovs&ayT)PSx%-CqIt%iaEGJT;(SV<TqycXWn*H;3&UkN~>5QAnuj|(ygj*Nsx;bvS)S;X{odtGJ?*A98>fp}qgTT?h_AVP!ycv`PYFNTYv@+d**#7BZ;{0~`9YUw#Sp{A$tLnyuQlFwXmJK;RreAx_F=}`?m>7MYG;k3FAC{F`e)jt0K=9v=yzJ1eTm@I@Hm<B#@)kM+H`{)&O>DG8HH_hS*yz=lTP@B^?{k($0cH)oiVTB4gtu}%n?K;>re4u2d9YUdIiMKeajF&Y+>&8k9ZpSI$s+dfusHFUG{y?F?KR>!`v=D^-^kdz#4uVkc#yN)~Jv9nSKNw(8fk5J~GDW^<QjtnlT_y=F9t|suOdSMJxA*>iF&G+JOvWMhofL?n=EAxGB#qiGCtTE?X~A)Y6p2~9yi$9`P!q)bTU#EFsrd~=SRo^{md=TH4bSd&PW!L^M}J=$<lO015+i4!x2XIjQHcQE8=vYVpQy%cHg?7|6gi>`8}{yk$P|3Z4$UL0$TTfU(Z2yMCsl9iAVDKEbycdhPaAN2SJrSc)LkkDQvdYZrIvRR+Gt#k98@Z~YQGT;YMm7vk`oT%;dHBGCAC+I6POL@g(55=Tn>8UWwgh3{Z#$2ZXhY6+e|<$VKauVmW-6blFJ4Y*x{5#m?mi-q|WsdEfN8#yX^KE*qwYQkNF(v>+G1XkYnhTWA7MnT#?gF4(a*68mCvKsJ_$hO#H@c7zB6xMW>l?=uej6GP<DhZh{OEo>Jv+HIl7j)2WqS{Qg(T!c69r&iaCFksavs^LWT8?uaj8X~vFr#U*zoIfH9tf+va2&MCfr?d8NyqHykmPd5TGak#FI)5T<6K)*}ogKX@fq1NpxmLQJ5{G1v~Ie|YKLcq6ZjywlttL*zig!VV-vgq}EiCAOEW`i3"
    _t = "e49b59e28647542e32a7a825ddca0742230156c0f88f56950703535741dd0a57"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
