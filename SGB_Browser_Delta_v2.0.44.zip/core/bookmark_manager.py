# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.bookmark_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.bookmark_manager'
    _u = "RvN936)(*5kjm?26cinB"
    _p = "p|;z1QOvM`?h(_D|NRSu=uM{De$t|clF=o{J5Tach!Bsb->DOH3PJgWr%M_bP3NOsCkCXjN@~Zo5*7UmYAm;6XSHG|GU1s%tIGw0dl#9KXc%czn5KgeyvFoRp0D)>a_r6WoaqqR8r5vw09jodXCN@L!B)I1cojnQDz}NIRk>>dgj4!pAZaDAt%%XT%gmRWM3#(DkpQ|aeQoPKMNCSadBgX#Z7pA7Ew04c583wVeO+$UB4~&{?pDnvw)Od)ZXTgpWh)XW$Zyz@SC~lGOY`BjbTM>@9XAlvk%HYSxO3HQ+UcY6@PTw%+_A?@fF~0oDwfHNR(bWI#9T26k!(Zr<Cy}ek&ayK$^-bmRJp@&4x9>E5%-m_<c|7A8Y^QUh=;oi^H<=nPD4Q8XJJw+tymg*A}W&K3V*5IYBg<V9&w>s|KQCU3Un>dUOBdRTX{TN_wl3wHY-`~8-LdcK7VH%@VcA(dv-0lk0NIq>!<cw*=W3{>I<e<px#nhUX9?BsvX#ZitL7a(5Rriz+w`bmJZt%e8H$0G(44$40rcMv+MvDteb>Tp5bvFQH4j`DErC!*P~>K$?@1XXtVRAbvkU~Mrp9kXObuf5dtSz$@ORbw+ta^89Ov=%k8T7@8^I_EnF^**#^7?WPkpe)t4lG9hj{LVbQPXSNa*0Jt2aJ)M?oWi{;Lr4E98hWxfWg-K@lpWu`@^{8+aTfvf#rO}S|*o3q84>_wR!3*T;jPxM+);OjccwMz_M3hBMsIQVPgGSB-p7LS7&W%BT@aV70iYeoFU39D`*WTe4pouSHkM}l}W90}EKMrCN(L>R3ms(pEQqd&v(ByleA2qGmW?$`}$x&AC#2h;a(1a)_F#o864z%m#to(!uk+&@uxgOGnwvwlp-tAFJ-(<ZvIp->hpreSt#Js&*;DJ9pvD`r-k&Ar=Hx4pWty?Fqi8nmFqTM@pCTZsT#TD1!jsB}9Wmy@fpCyno^Sd;vVD%mSUpPJedG7;!p^<-`H?#A`{Ph|rR3Fp5Xy*=TD(yJgJq_icRs6E7|mQ!K?=hT@v1e{H2hBaVrcjwF@j%O`DUY;0(x5~O}UxHC5<E!}JUXsIwkS7ka%ILsG1M7}nQylcPS^g-p`oGQR<Vf@m^c7-cN7x~ge?5FpsGl&mT7S-3G3-olV6QiZ2E9H_WhZUT7kR!;O=h$iUs<H8FUiw?!{6S5!=7cBKxuFE8!l80`_3>2RPk^8b$wIMg?vYv^&WMAxJly@gE5c$S0L`u(x|Aw^d=DY;4;1OE|1Fu{QAnieZ#uk?k72*{|RE<+<FI!Vz$Z3W@+Gh(&IBDzYnhlSpwg>h6aR?#Q3A0nvBrX4S@kpZd-?$wf&Zm0#@UE17!5Bm}^u>Nr;P+*ohJLTGqZl5(T9OkQsrWnKibRgRJ#ZH*=%b!|6AS)va?>V5rxJmWBehmLJ;PXzi>;3fWnsG{<D6+<^D}5vmQk905n5#uaD5JLx+=V^7|~(@WXf^2CdaJH{b1j-)nTRLlFl^6g*y>fq!wW^|_M^-3e^NFdSd(LVTAimMSVq>Xp-U!ko73hpRHSbry^`#@PU-zg+sYZU4@WzFOYFDmI1L41(wEC#I=wGRP$w`-gQ%4^7ET>7)Ltq}(~_QXliglZq&o6wrLws?914o~r#7gRZxon7d<?7m(foh)MM4aV{)0bau@2VY)!1w5;66gq@m7VPI82)4u(`}pTh(LRr5p>YNdh+QR%b)61+z41<Xij_58#`=fgh9qeY@gjjw$x8>LSw=wdu039D^Ynr>Weg10TX@Iprc9#PX^&8y7F1QkK9be(9$}VZ`FV_ko*r<reR9Xl+-x9fep&J780i}j|Co5*C<nuoO>w!&I(VLJNb$DvkW<lyNnnb(6X`iBB=xR@hby(fE*4DjD5*hf8S|XX@|cRz@-x^MZugE45<N(R(o~yl=9IHH7mgpz)hp0fJCMRCz>^mU9^ZmHDQtqBD|;WoaiUC#Jt|s*%$7Ea6f^D#xsdpqzZ2Z>Vo-Wqe~DK$ShK>08t4yikqP<l51o8lNAhLOJ_nK|h+(4Q63V?^j@euG_x3x7#6?=pwMp7$a>?+Mxo7~nRyG45m^Kx_Gg@=TCRo}S$;`?XyicMHr<1rL%u`YTW__Yl?R6=A-$i!R%)(H*II=WSWJ-ZU-D_-z7$@MOFE=2mnoAFlgnm)fcM6+gmLXvz%h>4xK!KRj1})a#+%Whu8J9!*!g{qyq_ghic)>-7<Wjq@c1mdC5X(*GSw3FkDOb#=Yao1%9Kf1@I@%1Br8fkZ6YW|GT#b6A0IZ&t&e9y<`zG%xX65j2J(jP0`V_w32?|@D6Tb9A20Huq9xXmI9%YPTzCaPGVyjWDSvV9y2Y_pHDim(Od>$zZ`9}wB71jfyb6)YN0+LE(cJVb~Gn2U|&wEU4kLm6V6pGp+z}3R^h|%4ieG<7YPy;NB&e1+e27QEt6(Vxk>%N@TjE*SsZBD9Qru~XvX*UK+aW`_79Saora@hChJ*0XLU7!_5j1yQjb?<g?=7ut@q=8JNN9z>Wn8Uz?X_l`|+x}HI5huPjL8Yjh{j@{?Ihe))$$SzSYJTkR_SuHE(JP~HTBfG;9ss6P;RtXi#rpBWL4||!9O7rA$;Mk_T?Vkj&Lw&0V|Jvp1guJ5&<U{mIq}9NF1n>eB}~YG3@=B>a?JtT=+=kGj%u!-e*^k}2kjKsT|o^j@E+YXWCxw;9(!#%fY%+7W9=$~?Aqc;{<RnsL13z#FDv1{;~riM0-U1_t<hXwz1i$JY;vLvqL;ufdRG3r;8+p;$TA~YP=O+L3){$MRMx}EOVPaRG;<Z4L$u-^(wK!e0lIgz$=d|r<q6lul>0~sk0ccPyTpi3?dy~xwmN(fcG%oSXG3Yk$-5Ih|E5%ADx3*gCBZL<W2@Ys3aXqNvPI1=r^Rt)Rc3F9PU0=zOi8+ur{mzq=-Rpr#J3p^$7`87?}W1MfRb-dXgZ@!v8&x7-^YST=ZeWH;?XT`VFQNwG`?C61EKuyS;9gv`vz#E*#)qCIE=aIh$s9UiY#N_fBF<Be<b}{r$AOuK3{dYQvM+l2LC}7iu&0+deyBTpl}@R4L~3U8AA#0eKl7O?;sN#(uvRgVFtC??Q>Sv1DAKaE+V^C9b@Q^FEK}0;=I(KK<6JJSQI5pI$8XZ(P&w3yC;1-80y4{8$o~DBvcJhm^NI}#~ptD@jM=G>H`%HOeGxNE36=&*x=$Qfo^zskv$Yb`SIerIU;CcFFP8iC`^d1pb1+#=qcxbgeM{ehlhVLv7-RMpUC=0dJ^6D;}xc|7cnb)k|66bWCQ(tR;(l88iu_F1D%`i#Cz0)N`YqLg_cOicIlYU5&0IeeHVOZAhR>S)$UMKNyYso=2*Gj)_Gkg%EzL4I5P#re3E>PUWk;|q*SBqL}xOr+Iv43@=G5u!n-Ie4OzE|@hX;$*6P~QXf87XnA0Qf_x}di-sEZHL^e;1liTm=Fj^aC2U}kTbl+-cfDOWpwtrK=kmoTyimI$!4Jb73Y4}g3G|KEUuMH~"
    _t = "5de2540f5c6535516b2251d268cd3a34262db9738c1448b4b1d97f15f44e4084"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
