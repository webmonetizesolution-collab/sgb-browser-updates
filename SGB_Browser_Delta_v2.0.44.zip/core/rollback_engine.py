# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.rollback_engine
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.rollback_engine'
    _u = "gB0I}u^g7P8EZ$o3}1_^"
    _p = "%-<7feG1M<3+ziYYt_a^#USr#7~6+jx&c)n^Uh#kV8?JNVv;ZXpCT8^m<I*udw^ftUvw#D*dzfIN!zxUz@tooWaB`H=khA9V3>HyN5aahRc(Q&%0gp<D{v4N(>19U7UWU=fs|SobmCq!j@NI%KQb&`U3;^8^xm&*U^zjd;?t?CJnpAhx^@iU#B`7h?7BBlS8gjiYI78C3Yh#qksvpQfD{d}ElRp-{gsihTIzdvUY;=Y-vX;(d@JTaB~#Ch9g@7;gIB^>*Jc~0K1S(>e5!ykY89;(K?Q6MVRL~DD`5Ruf%6Ezq!3=;@L@I2_;v%+J9rG5F;4xZIOv}ZA$C8G`cM4WS0ps$9{sls*N##ekIbgd58T(wmGf*b@q|9pM$!_%d4sQ4ec8iouQcLMyhxvl2Ud)=r-vDw(Lf^K%-hj;{L?ge)wo63hXpboG-cpp;Rd0NS5^Wx)<R9BfrfI&M<itJt;CCCM(dfSn-8|q3w@m`&(KgmNrWtEuO=jzFWXP8poXBfyD8kZ*tso6+I_<XGl#-YE8m~rm)rG=bR5-?XJ7L-wLII~zo34+69X~JkrX|5V4&@VH8ku@*@A-%$nD#<S$NvTC7lElT+_u_5|v)|aKX={4cl`N;`YkV+NLu)05t|{BR{wU{<=5)!kHU?q(}LxcTiNf-<ZgZBcL9`(!Y@C-8Pf^yN0{5c&|L<7@1RIAuUykyL7Hhv_=l);*k~R^5BK-zv4HtCZc9tr+1X9)H5m?os1xZS#a7PBYL_>mtDiZR6#eu(KxjWIaPaW|K_Gs_jofCI@QJWFU43IYW78zg@({x?jocvJUWJ-G?BaCO*J=hZ1@nUraZfTWN-F#Y;R(08)|p%V|oQ&%94>1QEvMElHp!$;`g}#tqxdh_LE;QsB1SSh9jN#m#+g5j%S*6J>4znY<9R?cHVrMH${#HIi#}Q=KMaEQ|hNBBv1<U_VCn^PYhXcz?W)u4anR<+p2ln4_o!kUKe|B;XS^u^061X^V)_ks^~XUO^JF>4)kHvW5$EGyRm-s)wgnm2VhsGsKd2fhz*EZF|dHyK$a-@PJIWHvoD1xI9E1nA(WO@LgP+^*MqZ>f1u_Kxa_R2Q>QTTacO-YGz0PtIfP&idfg8h2LouU+HV>CJ#h4}+CTPkUt4kU^-|S}V-L~qAG~70vrln6JF2xyiQAw5*LNDvu?aRXa(b6rorJ(=$p5y)+j7D<H=Qd_oi<HFLO%Wx;am<Ovb4#KtoXg7@&;3M@8$UiQVFjm4j-_po9Au$U1VJ5gb8w~^rv}ZU#fa)knVw9A2?l04veMnmmIrH9HvS9MIXYIUgDE#IQ@A3D`T8Vs5S+sbkV^sys;jtmO~=DAi<@ou-e*=x8vj72JqNfo-DRV=v?Vq7vNicP>%8GyWCjm6P=kxTlo{!P|c7^0rKK0Iv+sYu&`OLr6H8l^X)Tt_Rr?it(Ey__gJu?6s;7R%TJX5SG`jSZj1YerwSY{%kCes_>8-Zsh2~?R35i&sNg5o-|g(9dD6)Hec1X{jUT3`eba<FjXzMGxG}EI{5J3@ZPUtU)zBlGVZG!kUe;=H<>0xR*l<s;*8^dr2qBha>-}4>Np8#wSq$|nLFco=fmmnQ)JycPi4L<+!Jd8~og~u-fx>u(65-<LC>iO$1Y762eBYH&1V3D3i9>v42fTRu54A!*olhV_+OroOGw3xV_$gu4JQ5F3Gtmc#cAUp(8VQyW`+1X9Q9oT0?JkulJ_+^UfASUT6C!R(uzD-=ZeFCZX~Om+Ro}sZ_QijwMxX8<O4c}T!Bc&ZXnaFSq^GM~UjO4(tgsbtl!RCF-!6L-(i(F4$&q05HmeS{fTp-y_OS4Dyae+;9f+Mfjd>pdz7W4XNpm*7X)FpX>Cz<bX#f;GMB%sb0vrb;n^DXj$6!wCV)(K"
    _t = "8ad68c6eccb6697fd90d65d6a5a3a345666461763836d7aeba8239d111acc077"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
