# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.license_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.license_manager'
    _u = "bs5@W0*ZzE9CUcRwl)g{"
    _p = "E}1^%)szsrEGm(>1&Q?jsi`al9dF>{G($Po3c1_IEd$!21=UQMx1M(p30fIh;7=KRA|F<p>A52{5y(zHs5R}c^R5OQO^ZcbtHE0BfEAvF9z`%L%bz3a^xfk+waH>UIXD{Jj=SgCW3g8dOJ-D*2uHvCHt4J^v(#_b0%iukgYY&}8;UqXr3EdjB6!AF04PHAKq)~`9$g;-T@xFKZZoJ$gd}`O1plIk-}ZmfRPw!;Cy}zrEb4XY*VBskF5<!k2WbI!fcjQez|52T2M7LuR{(Vo5k{<HMTl;28e<Rj8MCY`Q8eZbuv)l8ZIGVRAvh^?CUNEI`fd>nhCYI>wTAsYPE_A3oo8rg!~J&giJ#k%VE~7FT8@ouV77Uctr|I%043$HnAnnOHA7d_P#58$Etk)?%)~PUV4?Wef+;FO_b$`2+$3mJiSJGobJX*i&WS1AyvpU9$M)Tyiyjiur!gQ$-I)QzHqaZe@0Ms=Vd>66(tsrVhZ|FC`J%!+lai5@=ou*$Mle~gU#~Zc(6t8_aB8ggzaJLYc(X6>DInaoe?a3VyViXU&)z1xEy5}t?~Ze27i*Nr+7&8==-BNBw8lukR=C3_*$qen0sFScBUwunT<VcXbmrC_G$a|t@(fSpUtk<fxF6q!O{Z$!Yilf{g(rUXO9*k$=4a)jd2bsC-xcm%F8zTb_|jtbjr>uN-Bx|Exh$?ws1~BS+smpA`B3F*6pPo(J4R-_KngJKKmpk{)J_n1QZ0`G9@9;m(b|5)*pKFvodiK@qYzcd!~?a+9gNrADgvdgE0k$Kn64v%<Mxlref9=LRQs^LinR&}oyD9=Mr-&bLs1p9{2s%b%<Z}iZI!<9?ph&H|3ae1Y0Wh(@m&0xBZAe*E5M#|>m0c|p~FNE40yBO4{b3+f2R$ldlE;H;)(wo<^P>Mg5QSM!b9<iJ<#R@T}{REF+G@kGbl>}*`ipxvjckQ<fU;v;o<;4hooW$tbsk#qdhhW+kZDW!*@XiQ|L*odN2+KFMvB>|4*m!Kll3QN%mLosnV#BJGs3C1v#Y^-_g9hI~Y5Xw@cQx1F&iuM)a1(>y1HM#8%xi<2(hz3+i`5yvOolro8#DUDdvi`&QY>%JKl!1po?*X$@Vx1buHeezj&?3tmHhWi@}Vg=@^RDqv@L4<3wN*`bQD7=_1z!|S(r`%lu>6u&NH9e<39DDpnZc8QVhAh->hO9#30hik*`YNQOg>ZQHZ`VS@<&u-OpGLcJ-Zj*ExAN@v^Tvi^MUL~yhFBNDHntAc^bo?Se6Q@!gDsvKF8K%FMV!YOm;1=-Qr0!ebASe(z0;ta!EK^b2i7u%`<TV3EhUUeNv~%!+J|0Jm49mO{&pQ;{p+W!$ILqWtWkPhSR?egmAE$y5fI=%~gr@rdsD>sb0Hg35L_+WC@q!Bhab8yi25c*ujTp(}h*;rP`rp1YvYSH&!c4+}sg~Tf0>j-=Z)^av`dNv(x#IcvJ5{#aLy7G4R9vF#8NA=h2lRLPC9*6A^%LHvI&YuHLQ^#)l?2ph@RwL7(lVSv-Y10n{J{Xb)TvjG$C3FKzb~Jpg(3^Akd9r&JE3-bPOx@An5uS6$0QPK-L*UncEY-VR|))ibPBZURqwlv%ln#3H&Sv2I7&W8PQ!W7Ln8C>uqNdd=bD8on>~~JjMd+9IDXJh+Y%H4a&5-p%V(d2#*4HysFUv$t2P#aF{bss{WuY&8aiW8%zx_vn<OVr4NCEHg!J62pZgHn@-f6}aHqXMvHS1vw{d5A(I~huOjY&O^9nV#zA~V6+H2Xbw%g*T>qzg?`K|xQ3D(xyo*jk3WrY-~%n1PEm;v3bmDhaQetd8D<Vhd?eBMX{SFzE)b$|IP#!962UuW^v2&O*+w0Ma0GLw_I+hz|g8n|_x<+7wd-rEUPGkW(WqdISq1f2c_%l;Y|?H5*#r01k=-7^I3cXx63_m=Y}snTwGs&@*Qu)4U@KKoA?qzVT*z;OX+YD1*v%vKQz0LV+RYSgO+?|^cs6RxQ`=_Ls~c+5Ug3+PMV8q@^P5Dt2C(prKQgfBrMD#-Y{E5JJE%LIdXS3Wk~!AkB*NYkcx=3H}RLWcOH#)fA8iql}XAgc!Fd=DATY_=q1wUTj3&2h<|-itFLtzl8|3>j35K#t4&l^aHyX8d>bkB}CjY`?i=5pQU2C{$x;=gJE#+C@gg6Oh=KrQ%UcQ;-bF36>_r;Pf#{o1l1O=0evR#6X0ABxO3D->p#$0i$7~E=C>-jX$P{{r_IK(t+gYsh3s+*!TcT(#ljEjJv^Pd_0=I59rMFlNnJ-3mq7VHD<JXhQ}jS`-4HEo!EQ5ReZZK<4n0~f<ov0|BmIbIpAZ#vj)5`&OTBD*g?Y2i!0^pwqYl0!kQKXgBmSLbihIfs-rAWKChrWJk=8sl^f4tJ8xs49`rmNa;I>gsu*LTE`giRKuGIiOE!Tn(PJh6q=Ztapz^N~$RVXUUxzO$aWlx=a3L5B_YZc5tCA0}MoIZ}N!#7BT$aZ&&+T{-tdz&pZjl}tDsJ4)z5|>3k7g<maCK1L6udgdgie;ch*_#2LnBW#0x2yz`*lQQkbRqVyjUE{xJopeXW%5h9#{%OAepDp?PGMS<nLm`%<vvWLg8_@K9cdI<bLt>Rg~txzpR7IE58(~qia~BVJR<&b5Xs{CR@*0!s$A%MnwNT;mj*$-~~8!Z#ePFpW$`^0ns7Lis*9ngy7kTS89_H2B1Od^t1goalg-QN|aQ^;r4<ke@R}>Z}uMNCI?i7Cun_D%ljtpmP3<-)H6+?K2O2oB$Bxs(0Z|%^6T_TT0+3TDbzyaxTPZh<M_SKb9pX{KMvSxw)uWM=RiALMc2?C&_zrAje1z~_z-q8y!+lZc?W!~!<UVvGd>0_Q`Fa^OocxhGlu;1W?6pWQ1p-"
    _t = "3e5622324e6aedb002b8b099a3622842bb5ad69de8b40b3652ec0abbc356fce1"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
