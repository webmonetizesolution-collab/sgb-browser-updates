# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.bookmark_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.bookmark_manager'
    _u = "-_bv2oL0=QepSH}{tahB"
    _p = ")N31krkx_R*duOPT?w1?sN(jIi9fClylgM06(hVA<x50N4~j>A71BW<%>V7|JVtaGMU<U@vand%+~H{L5@kyCwf#BVrt>AC>!ZbbL}uq&U5!bVthH>jIKeS5#ZuVY6t04og}7F^T$!|5?>Ag=1=%?I4uPv{!}=01@Q^E*fDeH$=A*Kdj4P<Rxn|RARS!{o@90fCGG&|4O4OE7G&u{(J{VVFlafvCcY3xneI#V;Ah^M}w+ep3`M152?KNMazWA{!KbfQZH1-KZ0LikYeKYT5?&^q2ezPw@9Pk&p!QDWN?aT(REU?jmry#l|!{oL=U=~B}ka8mbRj`<@Uj&-U!NU5;0+BWe5{7Csi0+9Cncj(yUnafJ!u*DVFDqK>08|H9{_1q1ZN##XT^3Zp;?<On-and#h6o&2cZEZg=@0~NL}5=qXHa4y1LAtqETh6sxsk?&$;6{Xdwrx{T@lU=4Md|+jx9qVAqtVFWzXlK23$=$p2Nxw-rhn2_~I6a)L77L924{3+x|!q=_}J2qj_Te&yRTrE$njx#=s@3Wrm+SO)=^cPEE@*pksFKl77o6ft#@?j7gO}S$JjmN%-ZvkHF1$6hm(vbSQoyVuEcZmrbS*=?y?n+s0qJ_SCjzDMX+xr^q*2&HoeFr{=nHOY*d9l29yBg$$y$Y4sN3DCsqW+5teQy4lasmv;i*2LGSYh7fqbe!I2vb?KwW>2Bs3nDOPWQPY`=P=;O(Xk9^8LXfCTChuvBL?}uDEzBVw$%>96?~+lCyd~+QON;?1WKxmxtI^INL3kyvu|v5wBPF8bHvnbp?b0!GdG<#0fwI;$Q|aB?K~a~~QT90dJjS_zi}I2!o0w~aT9uk#dYtyl6%&6^J_YlXXLj3mOlD2DPgA}2{+^F=vCb9vw_mtZPh@?RfDn?7wgP+*K6S1m6PkS7qGZlcOV102D+Unpvo*YLh=9Z!z^>{_dPW&>w4hB4JnlVDIA6+%wt@v1W>m$f^0^4lJ-qz^AXG0(mriAGe6wir6Y|?x*TBljjxK@H&O<Bal6zPc#s=kESpvJ<`kQxGpZ$9FFtzpA1J0q;`QJHty6|trDq(++SJZyt=`@hw*Qa+9dKhPN|0m1>#);u75#z&LsQcInv|#yovNL%I%+HM*`6=Y`>U4pTK>$aQj`9UhV@Z7M6T%v*g<+*dO9q(1<|^}UpacItMAeu)D#6C=jT2Pg`<&7h5z+iEqxdz_;nvD_A-2}I6%Dwn_TnsbnCoJ9#q&@eogzW2rBEap^nhCTE0}y&C+P|Ch%Yw+L4=H1keiT{y+M6!hFqvsJ4en{pGX>$pJ$RIFoV^y>pKtDt}R7{uC4)GK==BW5RZ3wQpfRu&l)i>(AShTT~nrnhsr5tFyDOC)8?#vJ-WG5z!L;q0?8K}KPq+4P?=D=oo@HZByC=9%6<$|8*@u2>-#?0R8B)W*e8ITDgk;(r@R>Er1v;dA9xm6Ly8ScFDiBM(<f~K`)K+UhyydiP1c{`qGto0?_=Aqq2Z5?gIWw|{jqs-9_1j=U>l(p@(R7fF#MLwh&WP-HMOdrXvNL^=41u>FDnF6Tx<U0&X?~7*=W83))9?g_GG|*AiGAhOk2o?x^s=Z!z>w6wc+LLO%5K&i9gt~`$|jH3Wm{Ic717mHv|{wMx`+SLO}gneW7a&_%F8@00q!LxrPe}nlf(NCkR(=H|ow9J7FRkGbKoiXPd$wx4<T))X$tXKZ&UoN-0?$_<(8@r8cjoGgcazoe{g?HxTTt6hm9yXD|&u;NVlT;m$1$wuu?VYQZ`@`QN6hm74)RoVl_xwii^<l$NXs6c7fAa2+7mD|x2Bhzq={<pE6H_s7(N+(+O3{FUbkzB@U)sO`zA#&-4jS|1PpRO@2}Ep?z1{1=f}zD^l14TD76jeti4GSma8yeI(r1!SMz@=hchyiTH=NEL00T9(f_x&+FlpfVA8i@?3rJCkx=#WB+;<p{;}{JuXHhPnIAZW%D-yF82*m9|<0E?5j|sy(5@Mb=CFJsZI_zSf_K5?{PQ{eX+~_@^6mQcx=L4?obm-%-?9)}`Pj1<JdFe4~04On_10O}dq3*n`ig0q%$+a%(Xn)zclO2fJms%`&n<%L+7NI0#Cv{v?M6qr@WDAvPcI_qt2e8Q{QNITs=|+&D;(s6B_M#x0ncY!K|p-$m@PHERy3Mv?|Ff6bko8{otRHP?Ys5@2%H{a5jj8*qBCp_t4-&;#%8u(fIn^w%^kc_M>lMhL_{=1Z>Slb!PC&_;;_oaOOsCo<v{Q%zOeN=hr))zow}#wTmj7grg2t6K>+Qj3D;DGWOIc%}-2lKnznE*?;B!ps<Nu4ZcQDnkp{&8GSx0M{+yKj5c|wCasS>^1uO4Olu*q%5S7paa9of5PA2l>ufQ>IJn66CR08w`S#A_GT=3_YTeEmfxo4mh(=jF5$b-Fi^UcK#*a{!a*IVb0aA$y*mNZL4)cSshsV**L*CCI5qD@&l!&}D&031GCbA(KDg?L@|CJmu7x=mpd3ls#%4-Qzmi+GTQg;%M)~SlO26?=izC3&Xz02n5{&5Jsqd9Ov%dPCVQeWSZ?UO;=Pn)GHBjyReOi{nO@f0e*K{3B;cL(7Tru%q^oXzQF+QF#O_qOCb{FHpL{K!aDkCl{;l*&cMr3i#v5dL$uyrD7+Up?pWX&V|ErLC^w@~EXm;;x8J{2(l#%0f|Mdea*SGVPA+KHrS^uT5GL;fe=lS^Jo_4f}}c-((XHAWq8-0r@EZx+{dMPA<qz*M^~M$A<)oqqR&ye(4{FPUcw7Y(gRe?kjW1Eo|MF%PrWIZ$pFa*yL{=sws~1GOxgb8{-%Juvz=3>3%a79ZQ$y|pO-lgjsK7@9)2Sx+1bnE+j3Ypj^TOOFLRBgIkcC&N5}Zf>Y?#Vou{R0HKseTm+YOn0Y;7VHDyR+RLMjP+MHAvqX>Kl9?U&O~<OOO4)s&7<$a)b#q>Epi)@fy&Ekc7+KS6cnRv;%dg6z-$oJqvVPdkafIA?VE;dr&DVQy*bPfrIni4mBG(2l>8q?oKB1?y&r(BXB==%lk-Oo+xhw8u}B0#a0x9f{9Stlq3V^XV>syOWK?FH=Y@f#`{{s7q4*}Y%JB5HyUC+^DMvw_l;HzmMmb;x?KNke(Z+^Ru3zJl?u)(4@%wPy8VTnbLV{3RbS=XGdnKc0PcW;a{EtaQ?l1|L2fK20$JXURCp7YM0~aal`}x>(G=n{a+nalnGoBMFhKzlZxJ>8wx6z0WB)a`={ld}ft9;m?;kAfST-3eqMt}~Ui()~%c96v|S$klKQ~<5T8Gn)bOo<MF8V5_R*%mjJ2$bRFBZqi%3)lMIEE}{w7%7TWKY;xQFC>`lx6;Bi)oydZgIkBfm(7`pFSn%m3$Il5Gs4&lKPrnu%GXu&DSOzFoH&QqXeLOIHtCSrNLZKEYWsa<)<ta2)4;k`;__ovY<wTxIqN14V{$3QRHVIcds%~7{NCuFnxq7<_n8^N)GRP+L&GjSc!*V-CCw-6hKEwFYgr%!oNu>iZA7#"
    _t = "b835e55ebf036091dd3ddd82c439d17ad9de16f44f16ceda0bd73c4d4511904b"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
