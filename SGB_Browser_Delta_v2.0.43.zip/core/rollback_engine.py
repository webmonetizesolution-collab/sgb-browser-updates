# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.rollback_engine
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.rollback_engine'
    _u = "a1^!bei8GtZ};9vP-9vn"
    _p = "$}_iQC&Tp_neH0FrMB0v<3?KIlD7APSbfcoB2{AqE_0?P3P9D7*tn2t*H##Q_KBP{pyDSavvNt%2m-CK%AAPQI*zjvKB#SW?~Oc0-?2zo6vcrtPss@RGwTI?LhYaRt>df4ZVur=6)n<Xouc<4@B43A231?3iwC{$kDZ&)&Qe-<H|Di5GaATpJq#^)@@%yjky6BolngN&T7Lre(oS%X#*1iweVrD$3*vyddY-d3FSqn)yF5y%gVshWHtZt#W1F186Sc6h8%~7=yHvPM(v8p#p|xPFZ;9Lh7l@Wsi=Ja`_>z0H4c4uxfZf9T@>Fk8Eyw3Mc`cY5&h)4ad1Yh|*JD}Fu+AM+JCBecI-Ndqzy1h7z_re$S(y^{$M4B_bo~3H{4nwprLqXF&ld)h#=K%hI3c7TA2t`pP9X|Xl~vEE8`<#3BVbkyK276ia5;3%phFl5_C<A<I`!3I^NKZ|aua+X@oYjss*?op5-A!?w=aF+1YZZ7wy599&H!X}t_cI?2HxC0f!AA2Qma$iixP@RuYFf(R;6eg;eaY7J~(&kS!Byp+HSH=xwfHO4CAb;4~zW;pI8Se{Zrrc6my>{mz47XfM+f18C_NYFi4>Fny{7Qi3Hs=<ggyMmg`j9)ls)K)aoDAnk{xAmOB~|I1dQjILt#-D_6A&H*jY<KKk=RJLKW8!=G*F=9ULz5o)ait}zr5hFU8w*Q@(D`ge#TWGEG|v(J#>SnI$z-XIr2>A!?2b6b6Kh<6|=Hv};%FM*n?*kc`vNLS{ZUcqP*&h-qV(Hi0eE9iIc8nFXllroSXbX_LEkB@t(HGY3c+p)Cxrtec9t|z<+B9*N1;|a~CKef9z;~ja%*wmw9WqYTaJ%BSS2M><m*b3HM8L7{aU{m%yAV2l4>9$dzAfhzT(h?<cpf?YIA(j8wNwGpiIu-rvg-Fj95ohtw2CC~O0_R3QS&M_+Bf9mF$e`-cjXVJMH(q^=QV!Z%n~+{17d%er50c)1Q5j0>m9S<01Q`4<wI#dz;rZt?pcli*(hZq@T{V~X!oZ9g$+lZ6CU1CRQ~O}7i9j|#LH7y1jI-B=@nUeQQcymC4hv)K_@9)eCX!`hV^fp|qtEu#E{|kg7dWlQ8pv#XY!j8S@K2k?kY`vn{Yv;5-EC8p5jYE@g|dF!ip|xEec)l%^GH4Je#RgHzj)Ovc#V}_e@9~+9--O>kV~wU7^(jtJu|+7lNopi0I~lhU-HdluG1IICt@#3T80as>3&_o-paZImWpK)m^4Wh>zkh4#<Oc5Qpv`-P~uSk;Kzdo201I2mWACptyKKA2k)20i$ZF{{ms5af8M@6rKd8HpYQj7gIGtQOtE0O+%@V%ezR8Mx;RL!kM&e;s$s1NLkj@OkL!)RoA>j#Mg{pEC#f4h_N4yWVXdCJUz4ILM|Z2u5=ALR2%YVXfBrMB_l@~Hvsd9>D8CL;`ag~{2}}+<!)(wknMsJrV>js=T)6gn1*N8NSE<o{-Lb2$`*`-k2PVYe1%0nyrB;W)I0qF5`%{p6Pw@~=?_;4ewo=7%SM$ba{oD&;>|x1(2t6}H2Zk8?@L|7L<Hb>^VfiN3PMgaZSup29#f*Y?WQ?>AeUr+#8@hq13*BQr<dM7}oFXIH<3a5LmPzb=H{BGlsrip-l@YzyLY~DVCGf!0eRhWp|0c-IKNaR*En)Tkolww2lN;QOZQGMOzrzms95UN~p=sr)LD49B3l`#x`pwB9cEd_wXtCJ)=?F+ZeJZkhYTQ!a_W|}LUtb4zl9$aM1cc=H+$3mWw-9KAxFy+2AQ;8J1ZVq_!z*76oN8tPWqjgz4o->7nxa1540?h_n;#y#<hq%xJKG`JamN9I!#HB-Nd(#q|9X<=_qyWjwCoD$lUXD!(f0Ms0u6?X9vuKIxSNt&==aQh|5|**_^V+"
    _t = "bd78b11ee64b5e063f8953338137251a2b269076b436f1aec7ebdd03d2eeedf4"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
