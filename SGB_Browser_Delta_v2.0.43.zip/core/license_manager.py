# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.license_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.license_manager'
    _u = "L?FfqLFfAhi_IfzlN6s%"
    _p = "S$xu$3u;d+jvLRr8|sBJz%KGSOr?W2TX5uzmj4oXXkA;hr;mjGf#CIRv+NXPqEf9B8<~o^`=`KDPQ`LrB@pGiGR$>BEX*uw5|n#jD7Uu=%EG?K9SD2rv#Un&cA@d)JlJ0N#-Q8mL#<MbRG{C26Q;69JIv{*sKcLa^>NL61_%cX!*$Qfe1bO%=plEGeB@|{>*(7o4%{8>fOmGynOU!F(bWb{fvd_a><BeurI?e{=x*RD#>|{oeynt~!iaLT7DX|PF+_a^zm)ggq7NuT6KCClgms?OIEY(qy|mi24)UWT+F!`JZNeWQ*4Bk*+5mMr^xy0FLK#blpiGe=;+C}-cx#mCnjKzJnEfJbGWns_&2MEbI>xI-V-|@xtHB4zc%dSC5t-;Lq503Yt0oltRXRwQ%rU(;F6Cs9)&*pD&ya!P*wVCG0ACxdek70^`zw(&?r@R_Oa)ja2QW&0`+a>N^Etmio^6z6Mm8pW0FQdY6EA-%cFx;?ej236oFTr1ZiQ!aQfwp*^I2RO5CJs{uOx5`HBCXvNm}^aHreP>tPb~&hhU`d!K^f;MFqin=vY43uH~s=Ojqm1F3&-zF8gt^I+JCDqx+-UF&B#aOr(y2g$3%q@^S{E7&ex&MNKuX!U-^^5FT9?YrM41Gi`)%8Naqm?ZbpqRTJI{8sD~N9dI%U*Dl<9y`-b}W1SMcMskr}d%~qX`6BBN!&p9f!Tc-u$1&->eIoQ-_1PO;wlZ%|z*7(DrcoXM&Cr#k_8cl@DYWPR{D;MdlCFFnX3{)$g*b6{DSrWfu(OGzE^h{eUtJj3ZOs8&yz*mu3gJkmr*mNBos(q=J8zRQRv>!%<IypR$llIwO~oRC+U-^ck6TgQsN#)JPoJGM)gNahBC2Ub6Z_y>Hwc%=8t9lfK2B5VL7VndM66aRY_8)-H+Iu9BL$^MPd_(i@Uh7+Hohe$t^PPh-*n2(IZW@wS0hv$#SDbqen&jik~!49XZ?=*x%I+L^GBN9(0KV)HPpM=`dxs71!<|XS+qjGM4hpn?068sO(zCxwGQ|C9Cxa4Mc7@iTsNT48SQ}RjH1S&NG4&>d#;kw>+ju0s~{Ki1ms<M3}RekOkEih9F}m=b?I%m%{S1>ih1pr{|_Uvl1f{fa<oZ!yP#myDkNE?UYNIA&qTIT7?fwLW(}gFFh4noVYZI8k6{%iM>bf24!6$Ar*6QQDsFD*u^7EXQ>Jy~9Iwcf*HId2DDE%1675qLbWk}phmW~{cShNj`+g3H14sC8V!wkwdI!Db^_5JW*QETAOGan}(XGPeHsWKwb266Mt$&^pv{KXWR_|tVBb&oD$;C|Ee3RbE4l_%`!Bc^q5)?47k6rBjfB-vuI&5@fv2yOFq(`oryxX{o(Fl<drNDe6@C%wRxoTW;m_m#;tb~ucvS5iWgI~?#!vx)H>s3zutAjVS!bE@^PDu2>+mS{HY;uZhodm=cjtF-7ozfVOwnvsby3Rk>KWctFcsm#hYcf7IXGmDNeOD6Y$KtXOF&grVP}-UZ6HZdyGI~c(#E~Pr{M~1DR>*HkzrvKAJ8y2WAZ^~o0V$EyF_ha4d9a_Lp1s066+VZmyK6($9u?%l36JRS!GTII5+#=1m9$}wgD7_s-1VyB$!R}7CTmnVm|pWAHEPOm;J~FX3Xtwi8i=C+DP}j&t!Z9b!`MpepN!k}cwrTT0J|rZegr*sl3uD@q*W9z#Wzm6Kwy-IxF>{5GOG8Pqc8<Y-|Py>A5}i-WKF3eo@X)Ny+RIv;NLSFf-Y87Egp`QC|;QKq|Nn3VR=wwlB3JHf|@;H1qRq&eD_rnGm_>)sskb!OLW_0`bk4`(78j&Gj<j>&=0uxZSA$s+7eonB`9==2#?8J+&z+(x5dp2Cg1Q(@o*O6lJ}l53+lgN)H=CYKeByehEFmKE6QBAjfV3%BNG7vr;olM^LVR+H#pLB<Lt-&=8<<oQ{NxfQ`yPCA^2*2S(|>!kHI@>A2V(=8cYXxJ!XQzMdwM7ig~hY!fitlbHROCvP-iB3<Fn4l*#Lh`JB67Ty0}beRmGJ=o!Z#P+hSWwg#6)53S6oK~pdW8Vj!Phnd_7W-8WQyS5FIe^IUGl|UnM@9`SfoWwhvH}P-co#tra@#G*AC~aDtArBx@Epzs^O1|yBgAcfdH@d#oU1|Xsy?3FuLs$|PdenMfgq#hpHC^Y$<0MRFH4WvC0cmOdg6mA=Z?s>Ne}yl`3DWJ(AV^&$!rUQ!?O{7$7*lPm7~}00n@&M92=HzAg-Gt@o^fH7uwHM=3yCZTQtxNE0O}BZ^mlR$vVPX-Y^AbGd5>tQy6fM>il9$p^bl|lRq7z)Ut75U0<NO-R7W>TOI;1`yEM$MxP;getDvT4+0y@<T6HU}WglU=CtST3-K2N}x@-2~UVR#vnD}bXHi5f{!sAx*CoFHdDW+u`B&75BlfJiMe6YxVQ(6d<+A86HH2e&%Pu$uztfE^dxA%twmsvmBM`knu0gqe90*9yf2sQ`E3Bg*@!F7fj>Vx}~b!?i~t9auA?3g9U_;zW%@M)nDO=Sn0x&A@LMrTgEN~saLCx2CgP~8t)x?@~MCjf$Br}_u&WAP#1SWm!#NsE$(IpS|-;%kj)_j1JW&N$nT$*XtJBqN-;`W!8h#$#^_M6`%Y>@?JEv2fLT1<`?7D9!Kywki-kQGMe*)#G}yMtT|ym?jGEq$cjr46O~;m`5I2fh5nT%#9p*d+zu<5tI^S-!4!)Xr**752%d>FGnMfxGbD9-pxT2y@n_dF?L3mf?#6*=x&?aMsXsVFUOzYL^-<<u{v#9ML=@C8;8UA|F;c;o0Ea2Win<MRj>&r8}m(hGZfX$DRPb(xX#mNq)il(+ZVmow#GFy$EE0GQj3s#_64~Dg`cgmU|gRSsT^M!W7H2wc82!"
    _t = "2999b4ee9f9b3a21bb1c9f0aa90649266167eb3b8887383087ac92e76dccc687"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
