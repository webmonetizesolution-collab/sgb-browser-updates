# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: modules.07_fb_forget_browser.main
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'modules.07_fb_forget_browser.main'
    _u = "w5Q<HTz8{FMJy(w^yQ6N"
    _p = "+#q=%f>jt-s5=Qy?Vuz~a;|h66(MMPStf#}XpGFNe`pL}qo_)nXT9|Xe2{%G<s0`5MoWVBJ_?^~%vsAEA%^NxwlSaS4UWWENosA-;>8Ylpp33a6by~VB#E2S+iz=<aGM041J50&NIa__*R=N+Q)*mM=0r|{s>;rGSUq?`n!eBU!c(l}DJ4<MG*wxI4vv}R3nF)F6&{6$&dI;Uw9q*><5JbdK7Klqx@%X~nk(1fG}z5-p@y)P?FjyArn+)OGurBi;4$Gl&)LBl5;(58+TNKA_^SBoQPTW|bpu1UvuO~3>eVYhlhR0SWy?G=F$F^-i>e3t9>+ZAwkH&J7M?+OsM~}7y*2T)K3Xz!2}peoQbrq&=u))WxHz>5EE|{b$LZWLQ_y%tG9((;SdElhpqy0"
    _t = "147fcb1a5750db63d5a7eb728233da1551c8bb67f66e1f93a4dd589349431a1c"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
