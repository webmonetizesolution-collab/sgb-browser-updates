# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.smart_exit_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.smart_exit_dialog'
    _u = "T?>P1iH%;<M`ZTY@Dota"
    _p = "P!&vi9jp9PN}PM4ZP+Kh<aJhR%>1_dgkq!Wsi!;sy{2-bpGm0u8S&^E4s%l@Fvtb!yk^pkj`)XHhRAdAr=nJ>mPu-8UF6PfpYe#(h^)gQJyrBdY?aE*$A(SfQ(!QVjD;C^YqBrPmX<K39z8$!%$)!xVvI(0Ls&@=PD+{6>D3SDazz<~+1-rJ?<dZ`%-v7RO;C&JY~LX&<da}vYgc44y(&P*pOBWv0eCHHLGIm0b<M-lbri`yw89_x>fP_QLgK=g_-NQ268F3T`@?i6nVD`yFBSi-O5tfs5q37TXs;-#-%1(J1{)jlM}HBf%OF}#$pxvOzf$8N_`&r~euPxUCgyX2v1_IFZ8L}8m@)0-QhWl|QJKe3Np9PEwE6^E57{dIeoJayt0@e;cO<oEJc?>njWpK{o|uJd)*=a8&rh?o+=YdZ3Z_?go~`ttqWF46*b1TkcYg?UO^PbW#6$no$Y*UD&;Vz(x$Q|qu?@BE%CokJOhsz3!oVk<28HK;n=bi7OV!F&qZD)(lF4-_$)4FGBNNhkCDI_O1KE{4lC!7VSnddRoC$p4PR^=?M7K4kFJO*vhKz&&GH#UTx)a$;9_oJ_2sKYC<1PHOV*wAzD245)sN<HwMm~<7RU%7OWqPe}7@Bekdseu_y|vtWjXOC};eq?VrHxUKAij32|CAyY>zN8cK<jMy>)ihErSVcQ(7kk)yM|ho`RrT;YZ6Z=xyjKUx^nNNa{G99zs9MqC9Cl6IZ|*pPY<s%VaZcib&wF*k81e54dI#`fc66^B(W6Bs<yKT5U(6J-2&a)_Dl){Cm<oE$Oeupq|YQAl^i-$4~}-2^Hw5%aC^sDqkx@|GD8;8g1wf^n5HRDzV{Ni)CKbTz#3m9iy8~!f5Mp1@PuYWuB$pOLTHm-#Y0eCCmBGZVq=5c4py_MX>))5l0V#mWhN%aITMFN_*Rs=UD6>?XdM5OwE0RaXUSq&<E;DeZ=hb3mQo`pt{u1_yQ(|LrWUm(KP1`q<dsTRFyoT)>Y+?maX-M`fV|``-qD4iejFyWx?q7CE`V?XZQAya64~+}@fkntk~?hf8Wb*wwV7#3mO@O+3TmkV_ZvQBrF7n5pFZGpF9T{gVQ~fixUg5o3K#2~=s}G(-Xl-7qGeB-iu~ZW5z7?WPB`;xC7w~DtyE)qm?y202N4E!#-vN<yD6ht?^L8nCGP;dXRsD_RIrcN0S4KH`|}+?L!>cnyls~{kKvPpIo6Ct_xza}+TKJ&sE|{DH|X@Ae4?M<y&fRXG5BM=2A*FIm+Z_V&=L;Aps8_Ez)ZZ@!Lq-KRu>%<Bg2KM)1$Iin#|-X^mmoAW*M8g!jJC1nmBSPL<WIKy6a>NdWY=QT8szI>rNdXrj9G#6!}G-TAToSax4V!Ss!wyc~E0zRaguHJcD0|Hp@7MFnIm2EVb{26m)gEDW%xd=P8j{82-jjfdmE)Z4VyBfgVWfmjr1tqr!vCCF_-^jh-5blB{3wJ-{-O49bgAmCoF{;_&Qm(@eM0s0!f-w!oTGGNtu%rKg5o{YyRM)qAq|CfgL*n2A$roGR}PPZ+n7VolBEe`NVqdkGGXas_6x0QFhI*p;TXa!(w_TB~4ykSSpasKPx;-s)v`bD@KfiR{qnrkE>TQhu7Wuc_`Mv=VG;%-y<6ln8tmIXB{RE)ez69}p&(!NV<GFpD3TpaxN*2WI^Iap&$%@yIqkwhxuuky-bW6VI5*7*m$wG9rpon_%zM;cL@IHldoGn)-CbEp<J|UGH#po#0JIViZ&2V}aK%jfk|u)D3piVYu`5rAb|oQEg_L7e}0BpzgkxN2TiYeRWWlrgv%@075Ar`Sl+X3a#&dcm>G`w|Ez>;MJHlZJl-OobCIq>BRyTRmTKn4^CXgabuSPiIg(?L>#dxY)kN_f6$d&)rXcHeur$?kVyG*&~P12O+5LEVSw)`5!y4VbqOwES0~s+22XM#!+toRfkzts+`&Mb+Xg<hHsw`2g-6j=qhLG62Cx?|gr{CQ3>(20uwJ(=NlL^4et$BP?#qo-%@sg(Zd?~o%88^S$O5vv*gOv4(!>;5LLMUsL+_fZAwbPM!#KDVkl>jP{AEx)(-f!Lqvl!}eWmh##BcvIgT~~PnO8e$((KWEcN|hjt#VZ^UGQtD9Dq{&xWhOAG%jvs$}$B;Ivf6|^QjTr3u?Wl7(G^C|8=h"
    _t = "3832ddcb893ad1fe433378459e3653efc364a282212d77c12e0a80e47aa45e9d"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
