# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.team_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.team_dialog'
    _u = "Ga;*Ch+A^sLNQMyjgitw"
    _p = "%*LftCg+s8&&~RiG9)axCC2LfjH)9Owi+EjmXDC|9sj*l+QdS3hM>`hY;?Ntv=TJQrmy)Z*^0okb0v1e5rWyX@IpK8zg*%djJCJjOsv~wc>Jnjs3_+y*sYeWt2$jtGM{Fn5x%L|S6BnO9g0bWdovL#FgLjHDh0B?&hK9VUTSeqt>-o+*9mfR&Xw~F6f9}#qg%@brS_%m&wJ)+_@^7<VwwoeHGmzz!McWN#Oz}+m-~k%{3C`#4s|OdAI-~AUO1Er=NpyT7zNw|W{t8Pl_=|HWGFLDb3w)zYoz@3JE2+*k_eZ;roM$CQaru|&qSkyq5+Md;O=+5lZ$k%?hFN2W3Tx|!ywCRiW;m6z`_{6DgghfOtPB@wvb#n)Zj_NFpR1ABDO~cj?ES8ApDj@HU&y{VwzVzS^tArjj{-4)yPWh5+`vA?EgORLt0bU-#JhDzB>De-#=*m4=7#LkA9)8$}*<#W3R~k^-Qf3u=+o!%B9ZP%u*x`OKUS>rlm>!gVKzY*6D-Xd<{XpadN5$WQ|g|33|S1cn1$Pe!2O+oQFKLKcEiQo_A?9P`^{41n__e?7O%ZpDZq|>UB0_+zB*)f_{W!&uC7}3jnESidgO<^lpfP<ndBJ>S*#po1PkeFQXIs1O=oB(?tvrnDj750R{}&AbIy%)UR-f&gj;QS~GM<)$0U%I}qv?tE*LR&d(|7k=^#MWluc*0RvI-3NSN>tK)q)oU|i_TaYEA7BDA{p@BZrL!4{L&4kt)wkzsrbOyp|NR>_o7$TQh;*xwO0v_a++pGhdt|oj@QEYmhnk6ghB=0DKAc_A<{$j8^X9hcfVWB#mK5duzJjS(nNYjh#4yrc^>n6sNy8)S@_2)6ff5M5JN9K9k3tR-@WBN?WEFc_|^JVIP5(=GYm;0~(p&p%BZ}n@}FXP_JV2;?YGntq+22XnPrpYL?`sXyUZtHM`+kSmxc#k>azaL34la?VVL7WQE6?I1>tTUDUW*CO4$xh1{KM91Xnlr-R$wXyMLk&@N<Sjl<3E;#USGI<mik?U-xV2sMj>(?NLYkrW018_Z)S^zD;X?v9=oZF0Yf*9tEN?J{OOutCxAg-;CPSMqf9mqYX<~2@Q&`^fCVh1Yx5ucN#AUkJI4&Z~YC*JF8t*#7DX8L>_hz<Cn*T#E+SYYYWr7t5b;F#A-L?Xpkv2~PjG7|_ob|04WLl-`cBB=}j(=e6S6b-|0g!ChveKe5ia^azJui*T#z<fp&QCBMHg(Riq)eRPRgE0!LB`)n30Dv)ClKl@{s8K$)#)W&$w&KmLHu)`3=O!S5{?LOI0O{>F0F|AJ<ceSGlBTZVb@n`V!W?Si=a!7T1Jm@{iAjO$HONx;iSy1hr{r1Kp!(`H}}9G@9xj|QJu3?xcrH(WaW5^9Pnw^SZ<Pl%Bgd%4Yx4rSw+NIm7e<b#4g+9v~|J#+(!$w(p+|N%$_Zf?!@B2tsSI3??rm2?1)+y7z!(I9b_(Qu5aLnrNUTGU|V4p>Am@Dv8)*CY?AfHqLs;wN)<B!xglOeR^`HsFig5W^rAQ^&sbai!G7B*1tF44{8vIS0ta|EmShbyxbPgR)DZyOc39f)uELmx#N{AsrI+t%TrIu?5uR9-ZJ&r("
    _t = "28b367e1283b384e1265148834ac5e5e2cece3d5cda249df2054732bc9b536c3"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
