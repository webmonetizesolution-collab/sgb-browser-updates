# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.bookmark_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.bookmark_dialog'
    _u = ">i>**8j^<JY|tyX(P5qp"
    _p = "A+zO_L5%NZz@Y>RmWk&DO6m~YO)+uNo)2xU*x_1<FOP0kIT`U?b}{{zrvk)0>CI^O{n9v~i5<h?S#6Hi!CZ-tm)A4Z)bc^T6hvzrEfO9`ZzUR2ZXwr#)ma~ZE=W9w=esJgWjuIpncy^rhg38`yE<c$K*yP3D1&tp!J>QHk|aG%K%2hjRgg(#8FD<9s=(A0`t9gKA>pK*$mrXfJw+AC+p|h*=DD_zyNOdMt+YW@O&j*063Zz^mZkv#o}vN6PnqU+j`*jypsR?>qq|1NIvs5y`=A@53U-!CetJUYB&Zbobn26H81}+%s}d08_)Q#{jet^nbue`8o^iwvHuyiwL)xW7;%Py1{$Ng^`fzm3zn=T(%~8i2!73Ln^K)Y}uESbAm{}%^82m=ac!+;WdEDkwvd~MeEe2fj=P3;s*{~bUbI&c{?SX7<$VflM(Cr#~0v@m%V7uBawwvt-#aGxI_cVc%4d+tRSJ9+j1(}U4v<7YlIBPb<W8B80Q3nWP{A<I*i$|jmdAXrmW>ki*0tG@h+#i%hUT4E@iZW=)2*U5DD=6ZqNe+S)wHFDHA0ixLzXJQn=MM!1!Nv}b?EO4_ZtUr(&`^#^8~KDH7pofZ=3<;H_ZcQTjRdX;%dbst370vL7O)o~Aq*$S^XRwjy{6DtBAlDJOw+Q*NPbiP?fagG=R{NJ>{M*XHrZOOkwJ(ACtjs_cFxRt0(8s?*FKP@ZX!r6JdeDgq58K5TY+QJXiIHjwo3D!8*&^DV><~DXdZ(C%%0xyArsAmSRlFku<bt_t~yOYU!S)$8Ha3SQ5n)54upD5Tu->^(gC<m+dmdEl9edp{7zk5yvvhekp-yYe9dB!f+}3t97)K3Fskr6|2pB;H&_T!e?~Tf=jLvg#4#UQTWGjGO~hs+NGS>Dmbq~KWwHh&kFRlW^d@b)2DfL0_zYuFJC_itB=M}<@<fF#;_J_NA!xMle}v`SEFuVT;WW|WRpT9nugPtIlrXkYw(qnfbl;(KcSxkcGKuZsvSuFS*~T>a6~Q{r!lEvY6)O=K>rkR&R1XKTSOj0!zN~Jp2KnLTL0o2il7hFS>%}7>F8Hiw?VmgO^*S~;70}YXmP!|u!}|c8XX^s^N_!yYN4h_^-6?t3aN8t8j#9X2oHc8I&$m%H=_r=*{|niR$uCA7P_rU!7Xy^<>r<uJ@RfJ&AAcGJ3sec$zLiqI62G1#Qj?U0Ca@pH+5x|kZkPDg)h;M)YO;{eMnmo{3q8aW)+CApk`p{I1*8rYFn;DE46i5DL|+qL0L?7iJ>zyA#Mb{-xy_6fIX@y%z%%kw7D!vxc4Km)H&^1T3g2(3T8f1pGqX$Ck%(!M8miNi76-OMwDGw2_AZ|BCKGDT;WqG=^@6_aC^D@h{A1IuGMr|`(|W99d;F1(UG8RjYqTelRw%=(xz7YF<uu}N$cvFRy>Wh{qdP}2?7yK(^OnjcY+A8C|B$a$1WK3h?Ghi1X;kK?L@Vw77ZQ-?YK=qqrOzrV`RB{@=lu(YLYs63Zw2FT=2$vGLg1%07hVCtG`a=FZ0%@z-;6D@LZ2D5C%=*EH@s?3{8<h(!gB2vOJ9jFX~*+7hr8(dmN>CUfYn3fb<*?M1f$$z0qVj}+P;Tv`aBy~upGMOVXss$0)Wi9i~fL9h%xyOry*Lc)M2-#>N{?wVk+x?A_k}P==Qe_!3@s_=407?=W&ouG`8*RzZrMj1dnWeY>-uj%@(X=Co2UI@h7sEy~Ma3%QYl$3|)WPQcg=`;{ZZ}msZ@0vZ0aOin7ZtZP9s`yDfI}<D8V%nU)D`TR}jw%`2rUCa#G0!ga^f$gA~J4s+)K+@_Vs)m8Ul2NoT1$xJaR#TyZ*md$*0B5y1fFC6Jpxo$?fjt!Lv@Fqgo_4bwjT4h-Q{xDO(HF(#-D&e5$*X#3h>($m&=9SolCr6W&_7d@2i<h^F4Cu|>b#2pB!ke5CtrNKOAeyv}^n2c8DrrI(9^2&_q0LTDk#y8zr!I?9V3bqZV&n;nGufdp-;Cd`C%NCk=uNN(o&u<wIDltM>HUgx`6FDY1To+EMCaf{6;%NS{)A+7actIDl@U8aJ!dT?@HxE+Cn_d+r@xLjIj-P5x<%y{eR9j$Nzme)@TDm!NWC1q%<>Y{1L0`kea}C{m*Z;|1sqh*j!O(aVLlcbk<<BJ%YImQF<1)Qk)_*n)9q7kEusNGcBA@X`Ev2B{Ix*XbaroW@DB<Rv4A;faC%l2(|x2IQ~b2aY#(+IsP%_2s6r&73Va9xBk=|82X0Mx8q+tF+tDT?xp+1-Yc$P1)+94y^+tYOfO2aJ;)YfI^wPYL$4}01bxX$~!jzb@9L??xJ(AwpqjOBZq2C<#d09<TU}mnte-Df({5Sb4fE>V*n&rCb{Ek_^xQqcT1ylh&hze2z8Mmlk7FD}B2gasx^Rn|m<VsBQpY=UH9|F(!v3##0)QN)-2eP=;TqmUe+Ho&NNuNqabM`6)r)XCamQow*(`0<dF*X1nevTxRv8VbO|6(urEY|3?)Ti0hWodF^$I04T3zE0g-M43Qk?qc4nzdk7)nn~Yefsh*-m<uGAR+($%`MY&;(sCydKn2uX#I5@I;CG+qZ$P^S(cXH*j#Xj@>=T>!#dtvR?_Lspt$1KvhPJ{T)Ggf-1-c=ru0C0{&XDdEkw6`DBnJr(nFWGC)GT>BlCtIx8VHCVfI+?eNcPsrd)c!`_4^<x*KtX>Wo<O{)W2WH|we|@vTTzPZ7piu7Se_$~#q|$Q1I=NMz36r%rVD{ebbVFNzTpgUw;+XT-fhl!b&^OCP=Tf&W;IB)@xEQgLdcZ2if8C=~O?>H}$3@N8NyrFnLKjXLwE?qoUxY231HS4YIdX-jHm-gos!W1z)!J<EL8*0U=ea)nEy?DA_90nW7ImlocIp?3Kr@~k0*riFP7_k?mt+|4y>LV%2ir|pi5N8yNj>Sz%VR=9A**;i<56;(L?^})|c7cH#=p<U~ZZ%1zk+goJiuJ0lB(yT=$ju~d2o9acT_f`HPn`|`fmDzkukSRcV!{gM31?Bh_9}gIYyMIGN6Jjyk9E^6bM{#gVorwIDg=&Q)rdX6$QPF>`W-@YivZbyk>|zw&7`&(vA$#*~{gXNstp%?dN|$4m{J>DJ1hHC#Opg=yNg<E>{^USn8&&xFJ6ovfX7LKmvRLO~Q|XK~nh01GOYF;8bWvR4xHcM!(^3`@)cg>DjF67lk$$~)sv;aXk3(Nzq>Gk5;Q6?!%+1=6R@S~Ln?x^+0#y$QYMVm!h98=KbPqapfZ2O$ek8)i92sS|@XFR!2FqS?wM~;`Yk^{tk!p~5LVm|kNu^onpy}9i&ixz)Nck+{%(GO16!5+@-m~AB0xQVO^8eLQNg$@8y+bbR2P)Cg@Ns<aDg6!CmvdeI^}4^%vK4h1<=^oP4C;m(tc7>J(a&QHVxh8qV17%ZKcItU$sTgrE`=B@@B#W+ZQ-zwE(rw;z)<pvW?<0qftD66t9KJ5!4F`oh9ND#JhRgSNB*L{?zuNu5ZsY8G2urcw}v9I8qoZ&)Y@aOe8p)SxtrYk?W5-YH9biAe?f>5UMiRYAQYuLsk=`O_EBG5_bk`KGiKYio2`ucO1S(Ac+7~>Sleavu7Ag~^X#=$5rGBb)i$Fr)S?wbwRlE!NSn)S?t`}`@B|%zuvLkw8fE"
    _t = "8225aa4fc83d7289ab31743fdd0a336dba6a104981d3ee7fb5c4b3de41cf58e0"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
