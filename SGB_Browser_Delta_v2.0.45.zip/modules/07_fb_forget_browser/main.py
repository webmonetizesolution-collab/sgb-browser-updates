# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: modules.07_fb_forget_browser.main
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'modules.07_fb_forget_browser.main'
    _u = "SkXdF@)GQn;g0DdD+1Z4"
    _p = "!{UkWe4QsHB~{%@r}yzS)h9%tO&Zxfig=Tn=;Dr&n2olhO`S7`SO+njgF0^BM9ZGr9uH4gMghFVQ!tXIqUd(nnQB9Gqnvdr?$oo9FJqo#_<}MXQfQ2M3seyjuS5DIhxz8afsDFx&uj#-W$~27nngEGGIohW6zv^=Xlp@>_95%lc-j5xPG&pk!GZj3BKi=U;N&|`7FH={p%W`($AmdFrNT<ov23RjCY_P<V;_;|C8Q$go51)BpS_#I!jaNIq8%rHCA`sm(ke$PK<5k(D#UjDx|A6zu#+I5OcB-;uNNF8A!JZA{>%jJ$?CKWNqJq%3qLu77Joi#?<0VQEMU9)@LCeE{6YFNcDl+X!O5@g#J;j(m({1<Y02OkuUdKIrf|8CbiI160}ew7GSIjrv8mD"
    _t = "8a9984a674678d0da802246deb24cc5c9b72ff4ddc932254d6df975943674b89"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
