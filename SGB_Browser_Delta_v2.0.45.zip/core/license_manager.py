# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.license_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.license_manager'
    _u = "{v3a2$b=6X;N6DOk8xAG"
    _p = "KPJ?Zqey5uRtRC3EH{Y+hA1q5<2BL1@OIH#a0%~|T09`)ad0-loudq03tMWg?p7x3+5O|8W6M-iKhM;3BpDr=QomUawJ1(!?Xi>_pf8~xD)37bkn`ndtRX)Fj+rG?6Br|wDf#<Oi}P@T=HFUUb;}hqpxw>O9(eFUm+EGf8^~wZ<y0c&+b*3P+Ti+g^|U=<n@Gi&uX6Q(n6$gKxPIgW#e-bpkZ=)=<RQZ1l(~XIp&fteiJi9}OpX`k(cGyG>8+q=cAqD*Fc4gV=%si_!alz^JNvW#q>WTfhB}@lhL%$gcQbWGF+D18w*<kU@xYHeN;$e(3T?ja;-d)D=}}*IrnCfsUz*>V@Sp@n-v#tzODO(}L+Riu7cvjRPpvB4+O>Ynh>Gs^2|ltzn(TEt@-~PjtrDW%fAH5rG>Q4Kf76ibvFN?^0SrfO(+{C?Oc~g@YP9mZnPkl4rVOg_rVaua8?oORKF!6OdiI<o@nK4fxczu6h^{k}20>K^h1|O0YZV!WChLoqNh<@y-1%u<t77e~|3BM?70P0a=pAt`N5g28+^EFsYgFQUZb4My(8bdSZ_%XfiqiL*Ek}8AQ7?(?iZs;Cfzv_A!bB6n)l`U&RIp=L#!5AmIt*Y0vr<E@y^G+O9(7$pTx!1F0g6QJx_CA0-pqH3cn@%(gdy+~eS#zEn7y8hnoHduODs@D`3%x)Ww<e*03}J#kon-4NbY3awk58E`Um3sIi$CV0_?M9Qz@Ce{>Q}^tzqWhz8FN7%!z37?$uUIA~b9xkf0(SXzPAk+UHyGu+!)F<3?TjtWd^eEwph8(qrlZ?ELBu#c*|E$DqjBZ%t%ktqyoR?DItf8F|L&g}WPUy%-<q>9{&?$gh0ii%8VIluXqp`(EGvOpoxJ0uY(RFDO?OUaFR5Vri!S{!n;B<rEDe=-jHJ*wHN!6AczMvP_9wZ7U%<YCw{}OTyFTzecN0wdMz!{3462GEZ|B;R0sh%3rGxSO)>Y{c3}lhmHpqGI4cs%zoMOC?wLr*(_{SJ_*PV4(plP{LFML$+-&o4b3qg6ZVVf`4r*+5Cn=E*v5+2gh+o&#*2@oa2MZw)LFnS<d+N)TyTZ(9&f^+pC5^cfdqmLQ^uE%6ue)&8r6g|;_Qwnmh0b*enk&c1PVS+>;tvlfz4S#e_RO)9#dAe^P9lmDe{h*#+mTt-b2n(i)Aq}rOw$1u{rXXM*a;Lzq;d-pQJjQ=ua<w4d1dcVl7WaxT<;NbR0Qq>gyIF>a=OKJI6a{#YVrPQQ?R94asF?uTc*(1cr{F>Jwg-jh|l4{YC_F<>In1_*GGq5|I_yRC<d|$tg2>k_eaqMgUnfRBd}SSjVruJbp#ktJpmuDg?$cB`>tWGXn-NG||C)EjLpzd~Et_1GRc37<tyf6g7ntH|M#Md|8&PqOb*DH=A1FY)N)g5)8P%Xv!)rhTLEv3(o6Yy%7(gk7I)*N1s(eBu~m9|MGj;*_LJTcpnA%J6=1k1ub@eg;C}Rtwl@|hm)}*L%ma?e#9mb<EHKg@3GFb>H?M4Q3t6E32Yuw)eDDbTXag(()94#3wLLW321w5!0E9hQ{f>OfI!&m&=Sm7hg9`BN;fg%!8@@D6yavv3)li5i@@PeWDLBBbr}^(gKjc}Xxq6g816G>WUPt!fd!FAOk#L}pXkvYviYaO=34HNz@V{Z<(MIF(58>#dZ#W~<f>^dwI*MeJ9^Kp30<n7?GxgSuTsAr&?@eBhG<M@63ye%S?7ZZj!qDaak+`aO}}GLkYD_t7^u@gdYDFA5#FydOJZcto77sO`#Mn$Vf+2XG<+NPDEclW=(#pt5@4b=R1Uodb@;nikSA+1;$kCq20hIff6ccAh`EEP8%jU}j3ZgS;1g9#!#p)**!`k{uLUUpfD|26c}tT`|KLGUzC3yMgR-_eQN>rT7d0o!{9Nd(8XmcapHR5^>lW6Is8tUj_}j_GK?h5sr`9y0sK}RUY7!ReAM=#P;4T1NcwCEnV86Hyviw-`&;AK_U)w4UDRm@J5I^+dBzqI3r<9_|%+`E)Ie#reZv65h0S4IY8xWGgzvWlh@FdsSs>C=Jz<MUr`g~rY{4l5ck#CN5CP*f@aU~@zt%R7z`3&ywcpB|jf3XP|%JLGyM%NKOsY<TA{&Q=?qxi$Gikf$<h0C+p*=V_DVK!ieBuv1)%Ox4pnS8@Zdg{(`txl)ASua-~*ks6ho4&@3)VSAFNEo%qU%Knw3AOY<!|+-;9S1{Hx>GI3zgvJkVK-_7C<mpHk_N4Oym{={fMt6Rygd}<${QSwe#}u3v)M8cIkCVV<#F}uA<m~1VR~#Ie}wbC_nU2pXdP{(z8qwm9lAWebAog29ge^7-=?Gn`rocjF!W4!90r_Qn;G^fB@94v#r`hCSuqv3L{SQ}uh)D4x^mCcn%E>#Q2~yLaEVJEvhn7*grQ3c5)?4!II1|HK!x;DWHhK4F$41M0;x{&iv-W0<ES)B2ltSlUNIUCm*~ARaq<fuJeAy?&H(j0y!H1cWa<Aw?-@tjqxDpgJ9S%%RYbI7>(q8!b%{$*qjau^m0)kQ8@93H)1iV&8p$@y+^3z@b$;e<WoI{APcJd`zUJHFVG1*QJ$GC<zHjAwJXk&h(r#GI)_v}Nle$s_M>6nFVQj1knw%_3*lU7b26tgaBApYS{Ai{0H-+Td#`6i(xmsL9eUb;nA;l?gvD5!d`FxlO=wUGH+Zb-+X67eP5&@0~1BC>y>kI~i5tYNt05-aw0b0c$ct0($9Tk1&=1H;gW4_wU(e*ESw^43IzTF-!Tay%(Vd1=@yi|s1aSrkhYI#9cB|d2Xo(h?<VEmMt)YbLrL0q0#gjgp*EgzXxHa3(9h3O+jHh&@^f;Lk-R!7=vj@3j(DgAe<d=Kc%lUpaNW8zb<w7OC"
    _t = "3903a928fd9008274e78f59fef231237a3a41ea15fc95707f22b99005aab5b2c"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
