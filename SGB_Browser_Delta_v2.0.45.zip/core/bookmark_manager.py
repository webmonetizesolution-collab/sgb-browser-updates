# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.bookmark_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.bookmark_manager'
    _u = "Z9^S7E#eLC$MDjZ3Xu`0"
    _p = "dg3~mTPf?(LOBq<zK|GR^IGl`ELHnXhrBSXK+30a(cn}4()cfm-3f@qgP|RwGlpm8`8_aY7rs@$@4tS<fse*TEFPL5mW%XP_UJ9dLOg}jyz=mFF|EbI%6^O^^lN|bCqWPmL;?vq2{>|`fKrQ$U@{Xu1_Vv~4+r5q-NSq@vN=hs-PmD%a7#YG*l%oU>ILpvwk-?EFUhE78RiO$+&EN^1~_P?Oe&$7BFr}DgDL($Y2h_={qo7Ng1eZEu?$7}UC<XBDX%z-)MWaUX+5}iz2xLqG8_To>sqH1Ipl#vo!vEu8dV1L$}_M-K8|}h7j`>9W{==9kU4+@UhePMO*O2&F~q3NQ2qoQ3`InEePmE!P=@wcZo58Lzr1&7vsd1OBTz1v6m)%0)!lb57le>gUBjfvR)&)?i<bEp<14(GS&HU|IWX5L&Wv4hqqme!*0(JIiX2jBz9oYADe=>c#X^Uy!Wuw+0o6<e^0b45VIR6;I_*Q6Pm&WX{PS&44gJwF^gD$v1$BtH33MLML%J!SNCxAzX5q=xc-lH*J|MV*XRyN+Po@V%fK=U})I+voI9h!nHXW^;yrMc7bm;v$hTr{$Fz<FR<t0?D{qSSXunFz3S@&J4+Hv?(i5O@t=p5F57pg^7t^&cR=!>)|DqjGNYQH1APX8Jj)q;A$V1-&+3~Iv@Bb*~S6{FlGMR1u#>EK=7JVFF{2PX+pNNeT=k+FHB!u+-<I18<i!~4R%H8p9S?bIvp%mhe8S{S<XmxXDakJ-Wel76#!#gjf1SLj1*C?ZWi1W*+$W$CI@h^&piPbltDT^>_u@uyP;?V|RG39&A28lziDeB)<}qPVx_Nr-_~;xnQhEgROpi&@5ICrs`ymK}ndv+jRDrhW!&6Y$h@&)H0-=2l!yuzq^5T&DmC`w^_Bw=GB2^-0w@_42btB~3;%xhPdJx!^;4Jq;2c2ql2r&#ORF!{b|%wOW}$w|{6imgT)TmzWmZXYNb~_%LO4v?^-3Tkor7#eN=v(Np0{NHp_S^8zU>)i8??C3|<_=CR!YFK1AJez_utu$8PNuKLLYK_(q=4~g$h6;WLJ-_|b#q~;(<4(D6*#&th}I(!|=tsKH5+x&H~t>o<aN~U66udtGW=z$bB^63$+q!I53`o^O>5Hx$r^Pq5S3~wi(Ht)>n`lHCpsV;UnE8@9}=f^mu0dA?U^NrcZH2)&xRParrM)8HRy)b%WCN|RY@*{41YRQ8anjgyftNfb&n15>}RJzZ(9_;Um!}p1)#!k(?N{A}Zqx-Hg+-?$ixLYIj>~u`?p6BoXbuX_a9XRvnW292C+y4JuYn*@>#?zV!D6upe@_BDd7~uRp0g-%5po86fe6pH2R<UTS>r?HM(EgSe<yqy>Jh!C)Vnp6FRk)>Y7j0mIGPKWnSEZ|ZkLd!vTa(EH`FuS+x3pLA>V6fe)Vey`bc%kOcK)2Y_ZXJ3I{yM~>!~(sbNLq_hEampJBfff^EF2Vjh*UY%6Wg(|7Wsc&Vlq96B_Lp`dJP=(VKSKR1A_@?Nw?lY!O`!eX(8{4|!Pl=JA$WHX{gtkOO1Gu<~1(+ACGgVz>XLiey=1LV6sWf`=3HX6@jFe;_JaESvf3Ty-|RiO?BWJX-B7S3`hL|3Z_rx~D!*M#jxlT;8pKg~FpG%{37(5(jxn{_Z*i*t5Ue&^@kzR0Dwu$9W0Ip!l0(xc?xoWpk)5zBivh=zMbld=|YK{!nSj*L)4gY`Tl1hoHjM?s!NmNZ+T20G}>FyR&+kM5fDe_rUDD7ju_Edx=tE-js7*nU$6ze{!1U)8k{=u@5yy0^BLsfB0AeG8cKz`SIHR!)vIg>=po>NiQXn1=y5}7)HAX)d8LFz#%88Bz8*28#NWq3E@&x;e5KQc0!x>E(*TXm9hba=v+%7m;WgURO}tb{$0v9BX{Xker~gtZdBa;NpA=rJ7x<lOx0PrP(K1p)Ml7b`s)6}{ZtMHT9PJz)vfirQzyUhy>B-SY3<i-JEpsIz7pqI>#|i6Y|DXb(-Kp}m?18gujS_v4L%jNU&vO@115S|dn1u$MLmPb1N&t>#`JQbUlr--v6u`f@?wWcyq{$GvIDf@in%wol&sKcFixxLM&10zWzHe*24-7@*J`tB+!*=nfKN6J=4(o;49GQRc=%F(@T6<zh{C-{cvJ0ioeaKEwjot3Fwv@mF-wD=CZ>Fic1_-@t8*+DA{f<?8i*^=*<&a4P{vg0_*p45MjA$gzrLy1+|0boDOiJOTGjVx$;1DT5f)(@$7vS;x=^nR*om9GC~>@+!9_w%kKUa8Nf3usbv0QoPn}jEM-DaO3C-*{&B~eobLqA2*_U^p>(QZ=Whv*Ro(1ig7N*>?QdP1iMj=t~|4t4lXLh#h(*;eTSEr^FfbH&Qd+C=^3>g22zh=T!b0gs*VTZlu(y_eS8SJtN*mR%JMj#c9_!nf1&|gYXPZM)~t8eKK!t_TYt$sT34+O-#s>Km@TvQSos^g<49D2XYH<6e?+ZkQP*je=38<?U}Gr^b6VF%G?LJ79&88F)~*phPI^=?9XpPPdVSWxh-K5;1@!FIl}%Id%@F}&<x%L^uuj;A|kE)4(2GkoK}yil;ih2`}*++Ci->Ls11rJtbGe1254pyJ$*C}#C5;~5uQNP^OH{>|6aN~InY^6+|G<XL?C#uY?3GR%F?)CfN`3i))<IKg@ipk5?ibNBWv>1m|dC)XqlIR`q)eC6uvIB^fFA`ZVo90kv?;Ye%_`X1e8R=_7TIBT7PH<7*B32#XsEs38-z;_d^Tuc-oQZZb*d5Wy?J7P}n#f5*#?0)rue0>&zWTM<UDrMVId||-YB49g2GAP?0K-qY5i1}8y@Am-$!hq41SErT%kO4aZuioo=OwXN;#Jdc(&3I5+(i#yQclwF-y&@jsS%4-_PTyc`-%1GlQ7&z}eKEqU@bwp);#aC9VvBW=XZ&{8b^u==88e|-zS;Z<P~()?WfCoG7v&p^S#~vBw%mB>Lchr!F)sOL!5(rr-b7z~cJA*s?ID;`n$g&p**dAJ&>-}d>XHrRsy6Zc<K2G-*IUTJc&#9J$7r;%yP#!z-%VP53Tu%7YuTu&QXHeituXgrgvW~&IkOPVI&$LsV>qIK$-s<(EIevC2(inC=>i2Gj9qw>VVEX8ec0~_WNdJa>rT>`0}U@6`~H&0?1xKa=TXtBq0!^GvR^*fWK|TA^t0%h2s&&I_O^)hj)^RfM>hZL#E@PtVCEWawDw&hC1Qw&WIX%K^<~)g{hE!6q0CxbHPx!tKz}>qZBhsv(++bO-IU1J4LrPH1^sTu<eC8F%iX)=POL#sYu;U?ek^PQw5||g^)6wx*32T6rSr|gDf|SJO{G@tq_ts~JTX$A<D~-qg;jXSk-SlpxX(ZX^zsUdwDdPFfm6fuyAK!rokA0_X7U(%8ijU^cn{iI0hPFXnFPa%97AR)o&UqIKxGPoNMf@`XZlOEUt!96VzBUNBBA&OuZ{(C`^F}VIiVRdm*?;{F56P)_n{IM&SCaHLr3kr{Pg;rJrsT"
    _t = "b15cdea5808cb667ec216f4daf31bdaa17ea74c78af01bc7b6d24febe8ee7f21"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
