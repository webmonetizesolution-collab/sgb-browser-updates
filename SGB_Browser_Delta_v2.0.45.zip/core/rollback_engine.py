# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.rollback_engine
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.rollback_engine'
    _u = "4J;l<q-Z4f)@Jg2#Xva~"
    _p = "qlmtxH$~Gbg(u1j<rEB`C$*)c&#)*ur2GaN*)(M>K}@*=b~BV5Apky{VIEyS-g*twGwhG+TX^lP@l;&d;thgWW%|soCrf)|9AXzmdK*aH_cVE??t#p?7idEZ;oOGmfRNRf<9`toN)vj<D&dH)VVx!6z}Ap}1YTCJ6^-?QBPf~>sRm5Q$4IcChocClRph-5vOCxrpYe%#Oq@0GzLkvRB;3uP@2+`z*1XRT2xEaQld*%$!)o^#2V%-;pQCO?nF1W$k)Q;(3`;*u7-WhqA+7~wQm7d%xw~T94+P4CcRrciI8`WFF_W=LzvjMA*y`_QeP^rh`)+<A>J61ZGiZBih*}9S#*a!p#Ozx#tTObFTBvZ|2~<zGb$3`;=Qt-94QITL5Y8%|2>l={P0VbmHV09BbW@Kv8C#Z&p6G?!<x*?z$1;&?8m%OwDNSr(peLy3M7{=%XB1hxNQI$@G=a}lP6h*W(%^$9SB)aj!gnj_1Ge0~rpl!k)UfsR;mv14mvtSHN2`~28xGorZzzm7vq(!ElxNd+HGz}A#{zDYXHbC5v+oXUX?knv#)hsp&27S-kMk-+8*xpOonYU`MRy%C6_}8Z`YWhm*mTzS_e$DQJlDjq6VYQH`!*%$(<>4-R+Oq})d?t~{vo7}OD&d_dB5SdYLIXdB3tO9l70y>b880}Kf4mNw&%G1e4VbmVB(w6-UJ43Wd-G}ESMkfL^sA09f4YXkR4kTb2<NHo)VjYsZSa4_?-N5+c(BKl5~th!|5hP&!XVShlkElP<Ro;`fSf&{4KKV{fqEQFhd8kOh(h}1a~^sqFh>E@N~ReZ?yxV(IsU89_pDzd-F2#uyli4W(V^kc3={m40B<YJS8oZ1~#s`3DcPbG^5K5u7VQuXu7@xnpw+jK9%9~CTq%BHraINIa1L6_|BmMD3Tv-zdh#@^f<Ayjy8s)VROaoJ7LY#)hg)Q(J3Z+K`~|G=Qa^9@=pChU0nw{>2Z5UptumqTDm=WY_-g&02fu@Y2Nd2kaB>+Mv9tlH*73%Rz*3LNH$x}<vl{viV3E4sJgRHpBr;%vRDYFe+5Zg+qMAB3q6;i3}&*U|0hWut9oAmE;AftlH48*ox$z6b#^fDKNaY1&WQ*$Z8!)0?Dvjrgul-VE#b62NBxwSz*-2629D#t^fo8mT=hcc2x?(barFe)S_G7Q#G==A<UGTyQmZVodH|(}93S^jr)Sul>dy+HF)nlb#?nD<r?97X2S#87OaXuCq#aP-ryuYnCC>SX`3DildfWim;&mp4HNyk^%gu9@fiZG!Vw8B(i+o_>{y+_Xx%YA~jvF#mpG*ujp|ONB%{{0I7m_QnS1sA<t>bUkX@5!(oTG08IZ)(aEL@2*V_8ZvIkge~06mUXB?-^OOFL0g4zpuBcC`jIYP$#wIesoNLaFu}v30|NV*L>b%980nGw_>cg|uo^urMsiZLy>QU^8J}E`e@{n^B$aA!6-%M!C>Un>3uhV%E;iU8FmS@;rz7b+dw(3zyosJUb}Cog|Bunp~?i?<M)Hgz~%=^7=LxBdgSyt)rY=5T8`E*XRrf+UK#n^RGP1WRs8;?VzAt{|IlR;#4}*T=f8&F0soi2z1eRCr6VqwC7F$aKQz+&quGcnbG7{Y3H-5&7#mfsPvqQu%(jZ<KU_5t#oxsIrLjW^2Pj3Op+)^V8OjTl-A2_Hp>1{yhAa8=Q?Bf4V0{S88x}u<rL4`fa+^)aV-qAkZ8-)Af#;b;Qp@yOD=YP`94)2(x{N&1|>zdike3f?oHB|RTOgyfcXE&?hzVkYVp*zbtaBYNuRvZR7?;teGn~xlME4Nm}OzTmp@E$o^KRaWG<d0>unf)2zQ&8c45O1V)3WcBLtF6Ft~|DK4g>vr9zNH()s-YP8@7HxPP*Ntp-fYM-|_dtRG}i2^Y@"
    _t = "2e50263adedd2e5eaa4cfbd1cfea322d9c5296c26e9700604b2ba3787554a035"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
