# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.bookmark_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.bookmark_dialog'
    _u = "yW$^wWSTRNq%BsgP;NcU"
    _p = "QaVB+UhLRKpn<T7#!o-stxIBSKT0enT@x2RVZD05eA^O*?~NlYe+VP$Atu&UeH>F)m5L`e@8?L3DZ7CmQMUY3IO^HYC>;emPcMg#1CJ0CK8t4JDX2|Cd`0Blw+79l@}?!9m1J?%V3gpNEtR`WlWeko%F&J>tN5hY0_g63o$a?8HuCi(NB96<oLpM-!$463F&^f7QnN^zDy4%;$9IX8SrCn*Go-bUS*0FZVaVblc=d;ViKrjc$g3*snXQ1h7@bj4AVb*Q4qa^^9P?_)xoa_s5zivm3q5LAYA+ukpKo7EnGQ&_#N5Ympy&GPU=XtU3SnmPa8P(V`yn<j^CeSh`|}lhG*oY<jY|@v$;rSez3i}VFP<p{L?m0;<G6^igMCFIj9hPq4r{R<!0Gbfe>SQM!@mUweRk$#-wh^XaYrz9$8>;+8@A1d_)sUz4pa%Ia6gV{6b!LfM?!{p&mSJ-(Qj7IjH=4{$W|63zS!rz$5Opn1s0gSpXd{3|GdOSQg3v5I<7K?69z5Az+eslOd#c=)In8p>wR>W68<d5J9s#w_?&%hj)%6FyUz%dU6Ld~O__vx@-<gaP90p(n-x|$0Ju2`+VK`>;WPgXmblOP>-Y*`X`9)ugMY$(v`1J-j}eHnaYW5r7F92o(j?E@mirivLb@)^#1_NLmll@}k!v8=4f922T4>Az6rJU(7R{wn6Tx2bIxC1^V%z8oPz|s35G*u?Q4mmZ#-4(Y5)=}TT~Lm>ih_%4IdZ#89QFMuJUS9VN1gN<uggg$vA6O!!o6kt=2^TtjqqV}7{t~RCrNPeUv8Mt>B&=IfBsUQDh)Od-U1la`~ePHnDz)KjREQWP>FeIeZ!7v8MOGP46k<+C9><7R?hFSo>_EQN<RL~+a-Ol9LuOe)31IvsKS4Y79n1O?olN{?81>4gzJ9KPEc?^TrZEuO!H6_xkmTcN-9km@hU5wl9?Qohg}LFq_hK+OexdZhul(*@e*tA13(u+(J8o3@00ejJc`JysEh9OyXd8+MV>uZ^OKyK6oSDuellRqlUmFM+wuDzvF1t#?D|>!O026_QQ16i+?rOmRY3&9Ni$FcW9}?%|EU>~Rts9wC>p^^VEdVT(GM@YIEi9Jjbj3wGOShQcFy}FlW5>!><a6AcAkR0Pg0Xj0KR%_xkXZL|C+23^gN;GMGY-^wH1nz2PSX>t2tRfwEDj?Js_e6Cq{E6@V#CU84d`b2loRqSuaZ)s<=N~vO;q|tgJ{*$GQ%wJKFq@ok)K)Cwzp^Gi{wGt~#W-5%+JO3RF53*e(Xfhh}kJ{VH1d^@JEgGd`-+i+K;L3amS}RBp06n)N_60OKcq0gqid?<EeF6T>sgWIz7@6%K$`jTfYt4JlzMzVq%!sc<9yw1!g@Js4A8jL~tzLDIVxJW<7D%ZKs0Y?ji82Sdw+Qg{}*o3>7@IeHV<bYsA%mfWb{+iqqUD%-Le`s?=%R3Ce+7ohNwK;SG(ax`{OG=)J}ujhmTu9$#pH)<z&0XQ65U5E^0qq@Ew*e?th{OFRFo5UR`nf0<{D(%YNR)F;4?@H+k6B*uZ+}X^OLc^(dmYF(g?)PX8TIEv-I82hM7Fv|52;Ys1W@qc)9x;eOkvA(VB@HvDU-MbJd)W`E!MRCofCoo^{SX60f~A6RaT)X@nWgJTp#<x$5iT%|{eg5zMt6Cmp{a}>+RLQ`{#eTW7e+eBG5BrLftIug-M~}@(^cv1)r&C0!aP~;!}aKJZN@Hfjde&v!-C<`n($f9TYuYIC`YZB4rD`0Q*GT^3c8aver<N3<L#m^w|m9^Qmu2j_A>vnnf1OFDO}=cR~)CJ>eBgDkH<d>kK*v|LgqF5z-;SsCLW!WD+msxK}oZI^+e8S7D&>3(a=1Rcs1}hhf||Ym2rCj*kNECq8DvCpUX>T{bW#P1Iz$RwnRj{JFY()r>mZD#QLVb4sqfa1t=%m0}%P&ZACX*?Ht6Ua)p{tr;5&!-6CoL*^9vP%KqXO{4P=Bn6L-N8u3|R_G&>KE$KlfTFu&<(7ICYi#J$_zn7TjJI)MBgt~X3;(H|-kh7OP3zj1#{Ysx${xKm@L;_$ZnRn=dW$km1+R6?J{L=69;L&+!1Vgs{I=lgY1D4&&aK#!EON9DL%tTiAxutN}v?U}4XC!23(|c5=_1v@{NYKXZC-k8?fk@PP?q*hShhe4Z$9d2-BN#66DZ4v=SoTuFt5AS`L8<%?FmnA%xvW)zD3N^R$sptWS`_&$w<9}3L(f&rR!;+ecj~0*6c@Ts_}%stw@<(*CqS|L-<NH(EBybLf}!-PGaiU~ec=GoVe1Iu!P0+AoEF^-Q}2r>L_kd@%k?(dS~ZnF!_2h~J<J!L95JOQ8^3>%*Y^ZEEsHwaMtv-V+6~B3uK!b6TB)q2pDTGFEBbP5?b+<xUy1&zxVB|K8(f`<A;Jc$H{_dWXWK^lVosH74UCQF)G-(}OHqFQPPg}coOA$109abDz=|r*%!3#)PKR(#uTWpg?<yaOY`@;)s+tSbme|`+W)9uFK_l~L8Rr>Xql0+Rvt<HDAZP9dL7D5MqZF5mBxm$a)T4sGHGl#74`vf$f}3?e=fst^mhiM*vQtlt{7NKLsGxD4N-!<~yTUj}T#Z!DC2)6c;3@BB{?WT>=BzXdJ2UdQoU4C9$4)2rtM=%26zJ1_d!MkbEc3^<<}^`(1MNjU->2RsD7I`y_l7%NWeW+vgf<)c4v;bT;i0iqrT9YKeOh0XM)o`y_551|XD@t`4#qg6de0DOL^LBen1^H?e#2#b)OUST+--{0r(z63;ECw_`ow;@oH<2G+K`8t#r?2QyH3;Z>c-qdOwHk;f?JF-n?A8Ens$N6#Xh~T>vC-E<b6X;MMRv#?Wzo_C;3Wz)~@sm2#gwWoRflgX9}4Uj{BEP_d0x;5mNuR+s>CsPT3C0JH)KOJXHm_5#biJA(HErdhd%+qfBi`Y#;fKsOUEL2^Vdp%f>Ss{kp5E1;aB48pzM=xP3TZ`dpEq_&mk9*wEyi=4|_nP1EuS(;gYFxpx?vpUPbK1R2IN5EhP=6ZUssS=72)2;YNeAAn4LG3D&-+k@TzXKGxXb@VBQaW35gPYeoo?L+`^KGrOV)+8=-J-_6HG!^kh91Wy6C#R<7&?D}G-!Lne=C62U4`uJf4if@PD&5@CeDy4%l%my{<~ek+iq)JVV;Pc+xtTAZamQvpkUPdrmrL^jxs<|Co4NYO(+W)Ab-T9qs;Gs~+0?=`d*bkXDe!nd*&SpE4epqQCemR1i$(tZrpSD4@`);9dYZ#Dfh63{e0?G|8}~tz?ae2AvyN<!)Vprurg@fb6lG@K)xxb{Bz<_?Du>0gY$e?V&^!sFa2T;{A~S5T@KRHNnS?>8^JUIlv3h%f5UMv)Bu?LvpU-8Ec=VW%1TC8X4<f}~SCW~2XQ&qkM&XI^IGEH!8xaQ_2dV?T@i|}3pc9T!VF#%XH50Jot7QwifmfdbRI+TMAggS{k1EQYssGQ;TH8n7^z(Y+uq~plwnJWB7ZA@w@ApP<VZ3)Gr4^q8YjRNqyq*cetb1t#2AE_2p|SCsUEjE-rlNdc;WoY>k-2!$ujdkdtul%@oE-;|iZ9>HB<EtMKNY|a7N}g&#<ux78k6;tsWJjElst&|o3W3*$7S8#X64H!Cq@$SkQxLN>#q"
    _t = "6f9cd4c29f2293829d94783e75f6eba5f078d6dd16a8a17611549c14e8fd1420"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
