# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.team_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.team_dialog'
    _u = "Y<-DYK#XbDco>IjV<t5C"
    _p = "HQm_|@axXwZN;jxai##+FEzMZ_13Dm^&qJ%!pmN4+p57oY-wY9!*CX*N3}%tR0rpLoG^Rs7Pm*v1YLw6F!mTZ#>3hCaHA{A4+Ttd;{@hu0D)4lp^<xAF`z|c0_fo^7U^Ilg%^-iE{#Qcd*|;DM(@T7d6@~lFpqfQ?><`2grLJi<9U_|Polr10d2l5i=d17>_vLoKu}v76!<3N%!;(yA)A0}Mb}Wr4EMwT=h+uNCB6kqAwTrN<+VDs!)MQCMP)+KbjI$X%*<>}6!p<`?w3z)^t!$r!5QEOFXxHcsFVbxP1tQ;)Gs60kkpdyIlx&Rw^P;uQ@GXZT;Dv5lT#lycNINxtQ~{<U-4dU3y3b3-<+aqxDUppcxp`8ul{g_ySb*$Nx(r^`K6jprYE~e=M6<K9LgH${MZYHYxQ^h40tp??~rOJv<C20+#*y%`H$k)OtYp2DU-vcKI1WdK5fL!q;r|)oJac34q^oaa|>+jK7h44YDnaIx{eA9vaWW#b3MuRl#NQZf%<MV*-suwb=AB@<`JdAVXdhdQ<2K)RK{M%@`I(cL8r}4-4U-Prdxpf`A2;D#T-!BDA$5Z$MsfJTN&<i6b6BAL02AnU=QDBU&4~?0SlD0qtSKa^M?MXBe;$QL9ndQ4BQPSu#0iQJ$s8Tz*9d5uP}<9Sb0gSI<4|&3E^tbH9cjT4O6|rmGxPZk$QY)yU+l~lORAMw<2+cT7Q<j_>4VaDUk&v0TE{!xi)$wsv*`EaRElVr89R$tyrXp*>Eq1kSOW@>UMUn#!DOsAt}YJbk9XJ+d>!niy##cxCcuvxYC$nXs)i9=sbgbgYhDabR2W?USD(tKf-XPV*lvL`Bt}YoRa`?I)6*&AZZrK<ix-*b$^|Rp}hX)h-k;C!ks%+dVrrq@MQo1*hcOKVN#8m7E6=1PEA)NTn&hL6G2r^$EE@Dh+z~5TgGLUIZmX-2rwariE|zeCe{#O4POzoYFKI=u`pXfD}12`1AxyOarrwVx9<dgS+>xxsaCvpRD(I4bkHM?;c-p&7(GW4a(!|a?R&Hbjiiy2$$mDo2mad03&%<1P4^Bt2HuX=5L&mtXV+dJm!1K(u)vHk)Gf3=7e?vGuv+Br=2T88&r)JHzG~|J1pB;If5{j+p)&(3t|2vv{P_Zx*Q}YR6BA`=q;lU%A^ZDN=KSTmfH!VPWvr?(&Vd0B?jp=9dtw=~JIO`E;$*#t;B=i1D)*QMDXiD@v`&E<Tazf+l6Z6_VZ9c8atT?KGCtZ3TN6a&u9@0=KHC+WleVFTFs|-?oZ_jm)X&HPy|V54AOM;jnBgS3M(viHG`c_i#k%JVP!dhplOK}=tPK*ySEq}v2mu1+p;u!fxefNBDB_t<;qz|c$MA}6w%Oq@gct8>bq{Az=m4W&&DTt8)GAm$qfy%d3PktU!l-E@6=x1*gD&OG?;69(ikvOwvmE5+r0(|xXGgpV65DfNJw>*Z(F1YR6vnQoo)v1xZHFX+Ebn-Sc#qXaqVpD?xNJ;Xrps-)q%%-6*X6PL+<I7`J_VYs3TbzHY>w}frsJ7nD;Pz}q$}Bu{B#CvHQ4yiw$TR&>dof}72K3CSH9*=!|jZ;+9RVXoPbKyEru7GR=cKykG7OD"
    _t = "e081954a7489849a4a2bb1cd2f862786c4f381045083e450bffe8e38dcfae6d5"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
