# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.smart_exit_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.smart_exit_dialog'
    _u = "{KxNtZ}nvLpf%Ke?7hbt"
    _p = "Tm2+x0_-~OTqGY4vzSy335x@jFGnB;#Gr$nIhZr*GhA#@y8OwRPnCPpzg91#0(t$IBGO~bpabA;8XT8ci_cjCRz#5(AY}Cya`}Q5&&ZoR^_4rOaXjMaLOABw^YI&R7=*+*ZYROQhh$`gep%#*<1P{$-VC2~qfq1eV^o1bGr>VSSi#iX=`_p!T|VL?W-e{V05GMdBON@OqwU4oJC6Oo2bo!?@!!_OeF9d@`vl&O+ZH@A#m8w<ws*2l09OZzQco1!S-RlKCW79IF?rL@$5**0m%NTwLXsisy9ILA#72To+otpgX+$Kx<_d?!5~==Cja+6#c%wOFYG9P-I^h`WW}o-_JRrlP_Uf97g-x(}#UgPfxby0O1o08QEGUc3^M7}yd)sLWVjva0!sJMbG=h!~KW}oknBOo8-(!JYYNrdNLQ@COncz4`v%a&%<=rEf4U8h36ir4M|B~jX#j7SxEU%ai6fnlGE9AaM3Cwo2u62{p%_=ex2v2OFG_<wab5CvhH2rp&mHQ@Cr-d;z@<^32>l=yDD=2xYD7`$W3AmJzFD$OkFXW$(8vfgJ!noV}%9++3?syW-A$sq&`hX$(NHFg4vZN3}fqkCL8wUW*Ota<}9ceCLlb;>gQG=w|#tz5{MC+{4R+?Y)jBwn&XpUCy;&4HQWGmLokX{nsEqg!t$3A+NlUFCokwkyk!ahn&HTssgwbaTm<3}x4f0kS6kc|c@*wc5)1LonCMD<P=tPg82c*WY2Sv`5iA*LSdQ70rRd~0d;yNoQEHu`J|RWu+hfq^_?w6&gl!pG}3QCvTX2ikq^^{mfEpbT9F08FwQ={1{U3~Jn$g*_ZrMMxY~iM4LMNw=5cuj+q-!-#Lcbu)noMkp!KuP^l=C~MX`d5<xa$>BJ?Cz`$_n<xgk8#7Jt+ZcS2RF~0Y{+X;zp%AF=)Aw%VZhbZv&zD9)w-J{RXc8ofQs<pifl1mGC$Mgzt|3`;^D$|iuXRu+^+o<TS+R#7EswL3!PxbBTwM|ug=XB$8><ok2upZdM6$9Yc^!JFc#Nf;;Q9x+opX<)+*-z`(CO2xs9dByb8g9?OY_84j%>RTVwUQNb+t||kUZ3$5e;4tq%^!5Y@@l5f=$aG7l`WjNHpM4)bmimDg^;X#Mn945EuB~@1`=oXgI(t1rb3j@5F(XgVGtx3D$m@NCoi+xD6{h-1?QQjrbNxqIu%n7YG@dZmgZax}|81622e8lwYvka-O?I8iN0b{eJf0wz!VNMRj23y3s-sFzu*hG%kmy&fMVDUwsqXrWDbRK5}Is%35G<Z<R$l;pN~7VDuw6_n66_N1-HC`+Fc7P2)Usx`sO<A-~;+HhXUK9aXEh2*gvQx~9oxxzE<BOSGqM?+c_8ZruA|h=T?JC5`&`tIfAXmmT+Tvw}(%B*h*nHh5*y!24roy`z6{&`n{DASXnLk}0#Z(OlZg(=QqV|3q`V=wz}l4xHM1zSY!$57;IoKuF~IK28QP#XR1r-BU3v$B~E@h>8JK2J)>CLP#pI$_x19$CaZ*xM(h!md1s$hk|b6tD>-(IC*U-WPLayVR@G7c1%LgnbyI}CG2VC5Z~Yg>P*U2UEhqzHJB1rJtaeJk4>E(4W;T$Wdoo1I#8}9?;jPNt6UQv4ytt0y>Xuz@+q)Df*Z{}D8v*$lg2s_+8@z&$q(h$?l;nV#^Fw8v&rF-3g>}8Vjrtiw3a}mXrg_)1K!siJa_5R!tckO;fn(6IakSxy<P>4q|?syzQPHf`z>a%mndDQBp<2*A+RokVf3z$e8f}UsK|B#bNf{i1`3&;{5CuMs@+gb_kE`DK!?R=H?$og=Fljcf8offzto}@s|LEGwkWo(h}uy7*Y<l^_0ZW-+wcraq-r(nvOi0#NObkJBX5hjM;I|JslE&Unm18_{BPV<Ba%~zp6$t=Moj*!&=<y|dhuDxK}U{a592@A)VQXMDx;=he8L^i?SiVq_Q-^Zq&fp#6gsK+@w9M|-;l8q*H7G)t{s|l`lDF-DFZqoO`ZLbCKj|`d0i=FDS2&PyWSM|7oU$Qzv-Nev4Ud^dYf1mc8Z7)8uJa|PmSk2vJ0%>G-HI94RV2dKm(Ra(kDE$FlTWU`YA2rxT_%V&eIX*)0<d&_BOKLCuk;`I&O{jcRKH!Fly0?4U%N7P~fQTmLl*a{?;w*{|Q>RQJH;>m#~Q"
    _t = "d83001af5c02e3531c473c7d9fa22dceec27708e94d21f2ed7c36eaaaf24039e"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
