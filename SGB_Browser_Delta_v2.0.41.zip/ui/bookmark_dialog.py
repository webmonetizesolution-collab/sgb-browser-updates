# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.bookmark_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.bookmark_dialog'
    _u = "hymrg$vC8<0ay9=(<yzS"
    _p = "OrPD5M1^){6eu!#h;I$7!^I-V0&hAZL2($|?3Ps2HR`NGh70c5c9&WNJ}~zkk61Hu8Y!%q@UsNj*B45qM+B+S5ZbM>1lgyzUWrIU-ou2O)S<(*o}O$$OqJeY;O{r|xk4{dst2n6MEf+Q4w0nz*NF9XY)65s6a&xnom5yRYIM5Cu#$NLN_PXh{!3ap3QWZ_*qd|nG{Y^e)8OZ&r|6#N?2h66fXN2J;>4+E>qnRL56h;+0xtX5P=&}F9j)F((Gp*#=*#ejMGh2hJqQr=C(F{w&6I<V#=gT$rFvLcbTnT^%s^uKZJor~k^7Mz?eN!Hfnb&L=yt{zW3G#`VgSs_$|ki4E0uRq%G3rne)h2rPJ?wmX`{?Fuz79-e)FBneU1FoYayri2X}jg-8gq`m=m0R<SDR^`N$J4O$HW)QCat&s&&1vn=k*JDf&m+hPKmf0LW%l2rO&wJ%({H)IuP+Ll<8|1pMO`0)yRQAzFw}*!?T7;FIb~Do5mSFliF_DCp9%v=5FQdxK2<c)Yt}^G0G;Y5-{E{tw9CH!AV%?&M`-%`ec^@_n!Wq3s~BtvOp!=h@*(aO=u=)PP;cDxMWRHNLKPoVl-&8G|!fXm0v^eZ+kH@`;YNf}@&!J`*&Om(W7{#6sGhR0sgWD5~du=8sW*t+KR+eEEpr*eIf`*}%2PrKs$&aDs#m+rHv_ZPIYkF)4XDndy>R{&h^#zb4jve1Q;-u0R@kC69{(#fTXl+Gy{FiVcr{CEe3mGU(tK)8Vr!meUoK1N`Z>84l5`{tG6*Q$(srTaqAbR66Q|@~UBT9&TwW<_ouYY|Lx?fCNr0j6f_ZABAKV`+T5$6Ej0(l%d)-kleK$`ggs2+lnA(E}}QWeCrsS44=k)*Qns#YRpst?I4+*vZsQqBE{X4c|<&gGQMuV+$NL~{1ZHz3M2c`_hq6DfS%u4VvI1^tT+BCoD@OfJ0<CI`e2pLupF(PbIYwOx^Zl0kP}=FAYzn<0`%B^c{@$j5ikpEn9BV4e6AE9_@gEsId+C5Ka4^$fR)NPruGjL7$ayEZ~#u^3B>Z0Av#{!yyFxBI0yG=-XVQN!+UDAR|l|B@kcEe3RhbTC~COm0`8NyyE*f4$?1`K)S-w=Pc3#6V|6MLc>~6fr{-=>^=7_=b?KzOVev-2ixX{jSb$%!AK8K%7>A~vj_a8o70>RO^fmSmYCtOB<1G}O1Q(r!s<p&#dONznMfF0sEX7L;U^+x`_ZsxW7Sp+eri0%kUT|#(o-8~ntNEa{G}@dijAO;wEy*nh_-yD#LAO$`+Nvw>Hzo&gkkn!)Ep{enBkXd?Qtq(p>?Sa@qU-o>o7JeEjsMX`y9^1Lw0TIK+M6;a8UCu6^)B@)<MTB?uXHdHoSLusVp?aY1!M%3ZyAln67k^q8+Vp-RHL3PrQxA6R(nGGTk$FmHfE9~(DN;byz-!XOlN0XRRO#n?eJ=bg;J8SDKOXBvV=n)M-9YU&q5IPFhxj!JR$!4VZ%X8RX{aZCXk`cyE)_;gK$Ktz0W?4)#Zd_8CysE0{dZgq%P&+TWjM<z7uJMPjexj@x_%7(l6bz2=ubj%x?>Js>it$NGy(9Np)Q;mbllr%th7E?bgcv{d8;XG;+mtK=6AE9wh-r&11T?bTH>wijMxR!fx{r-~btUo{sT{VLz)dgVe#L4)D#26pldj#f3N{seH>E@9blG4FKPady;7c3k{apUNNHMg<;7f-|x#l6$y+jb{HO!!SFTm#zZqayqMGk3fY!b>qw?3wyq9FO*hPxf?od+`-F$Pt!XA-p*i2LNwS#>1u0s#T>?63$By1^pd-z|>OoC?TQ^WK3jT;FH*zWfq*C+2H+EyJ?5}eg$wjXdeo}?+DL(KGWO6nm|J~#NR0pHy{*Re(El42LyFr$T<!8}TKq=!e#dRQ=1k6A_8Awf+$8&bFh>1fmoA#ew4PQqTuB0?v>RAfG*@_`$^#=n}E6!$4AK<kaEBsq({0mgOA^ZNYYk-384z54W97%-1Q@8CCLWrOF=;>-<^Es;Uk}M|o&0Y;jRX(GO`D$bRO<%dd$uO-v$b5MDQ0wLxng&oOUIoU}vfK^aNW5<<Ed3EF8BcUK5M{j%??x!AlF>brB~x8go=;!`ZP#G-$B!RmzXkPU<k0&QM5Fm(mkZ2ODm>v5R3;anz>5bW0B08SbL*K=L|}86GE;HXW_!bx+yK|$8bRnvlJR&Ssl$*bCW|^VNN7@5T^Mt8qB8>JLf8qR9->;fTbcYBy0?#%tJ&4%tcIHq#263U;A1)k4&YvwPD1di=Uh%U<O?<e0-zf0#M;BUoPDC6ddFPgLPU9<iA_1*|1|J8GW;<R$4(jP<V^OsQxX%q8gf8eI1AKE83wl(kiX|@y3XgXS03X(ZuQ|SIG?SpV|N1`;hz1o+~m-CMhS~a*zMF95h82D#~jVfQBU)XF--$ioW9U<*E0CT_DLrrQ@B36)@En3-KQ%HmEa9p2y8=3!$EWYKp)Xf%yo7*3Gf&fy>GW9&J3c?rByFaovIX99sX=0((m%^(w_jGAA;#3WV#*T<w{+E?~i<`=xgCc`tAA#n`J}nP@X;!&p;rYe3TLw-)_NmYDc)`n$!8LyjN%@3LC7HEOO$wX`5Z~g=Yg+mJNKD{3y^ZPV&ub+J&D?aoxOd9`)MC==#6@gkWI7KEYgYZJ`8)VK84#H6`<QTHJ~cu^P2?8FN-mv~_y$XT5Uym_%h;G5!l6HrE033W;f<dH=o>4fiUrFv9wgg7yD@R~M$N!az}7ZHv%_&&=7{Pf2$#AQ~s0G7Qcg=Ds-^Ta5RR_IaA{b419pYE27J5FxqO=87ss+0nvnudGuz6$$1^&fZ<J2v&ID1ra&ltg~rw4byn#f!SQy#2RJnd5AB3w|(BA;7zE`+F*12WhD(4ZP+RTbdDcIV_?n$SPk`i$=@EVl73-^bn1rz^-RX44SGr!MW>zRK7xrrBDoRLG=zI7G=oIZx0zqJ9qVPpeovc{!|qv>Ekrew_*!y@6MQn0QS_C9hI<<=>Q5#@&YNJ(0S1N84z$l7WXRIfUkqcSHdeQt#wB_C$eGKIHZ+heLTd*p(C{~l;8;Cc-%Oak-!QWkH+*P)>u5l*CR0+oW()vdGuc4`{gHphH`kMn|0&?0E5}=c%#M(3aw0%s*fHVtRiMQgz!o8UNYoZQo+ADwpT?DY7%?Fm|45HGb(f01YdD2ICZ$&dA`bY!kLJqnw<ydYfbfp_yK$Y*LgDPjkF>*TIxtjiHo(d|bZ^l&=G>?;0=#L|@jE*4f~KFQ*hq#iBX~ifc*W*D9DPdNQX>;|?Lh=1jcqkeL9HR`DmuE>{F0z?rQ)g%nUE3=O+PUzuzi)9*upTNqX-gJkhS4s&cMP$dRt}_N_%Nq5W%WLZ1eEw<uYGy+`O6USv<K6<uFf2TH<2CC7|W~Dqn>f#rQDDMv=QzA&msfXx4q<JZ~WILd*`fj1;K^w0{*A2B!DIW4GFBx61#@2MokeNc*j!yio@MYcH>B*G+hf?&-#N5FqLFyI9$HqK26myczfgc)<{i!1R#B)pZw(73CXR=A>EeCg6~1g><*s{54HPR>ab<HcLL`J@n5<=b)CJ)W4eCBumK1r^bULyc(1gd$}LiI6Zz9{6|^P^QK<!!@GfN%6U7dyOj|GDIK^3&U?9C?E?"
    _t = "8453e950b20f9ff118bfa4afdbe83ff8fb9b2f88d2564955abd0555a174f3345"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
