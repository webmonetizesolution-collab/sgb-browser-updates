# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.team_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.team_dialog'
    _u = "5LzsWOzq}wDUC7+4*3Rt"
    _p = "9F0~nD6Iv||L}1g*?2FMsWTW$M1dxW>2v9G4K4C{D&S1s_Pv!13}cz2s*r*r5-pjXnllRaIQq8cOrZGgaELuqF-A_v<%0>t*kEcT06wv7A3!{8im<ki^&n$J!lq8yB6$L#Obp9MQ2RrD8D+CjP{LsVXQ!}U^<14isP3{Iki^EB2Fhd_M(d*>gU6uzGYfwY;7wW;yB>ez+s<q>#kS%Hl`|#iTZwg(lm6{T&%dCbX3n`$Sc&cgtFXgVuCg&UftST|^b1dzf(w7pm>v~Xa|@e18;;n(AT8h~$!b|9dOHfrkZfF(sJFhz+M^=Pr<PY4pz0ztP0v;`p;dM%LbFU>Yq&RrW6U`VHv#S>#y=RoaV$e6UC-;%k=aWJL3Ox0^IB)Xa9@Cj(Kl1tygbUJ{i5@qG7k9_e)G~SvkA=6aim~d?-h;^5#M2B#}kC1Z<??~{lxlhtw@n;XrA))uxSl__2zuXoHheV9$T*{;F`Yf8?u7Wpc;;KUqUT1cAzP&ieK2h<Ja?EQJ6anVNMy<$|w3_^i~Sx%qy<pnXD0J!)tPL5K=PfA`Hmnz5f>Ih&~@$Bch6#vBYhUNyjex=!bHJ#dLGU1uTvrcW??tnby|r@fv)IDxeTq*rW3OJG^(NgU~$hilEVb=idJ$^0%m;59)~*`7P2^Sa5jcr-xt&lce7gt*xV^OFYxwN$)D4ium#l-~)X=U=to)8#iOM)5DyTU5E!coNaJ_qBF!+xqG)%#RkVdcL?#1`oI>cGN)!ueX?w+VzkI1(j{_WIBU9RS)I#rl((Lu#gF8mltGwR^Q=q9dw@TzOf8t<E0wJ`sfeHHY7$Jf$?mdn&d+iNrt4de1@UGYD90M3l()}qVD5+O<DiSw`_`~BwBkv1(9{2$pg*o|#3d5p$j@T4*!)A@zw`7|U?1hd;M1nR(9>+EOOAXfH8)Xf+y5Pas7iI=E6XGM=YPOA7Hi%5@dpRCpj|l7(kO|c-vf%_unP%--Oa}>ts^6mie6%}Zr3GqSacA)_j8PhXC4Ziv&%n&6!uk{#8P1y6>dkA$yxZcfM=TD_Ksyt4Y7busaYk?F~K3Th6G`;b`Y}+HquUayU-ClEE999=P!iu?E!X(%6{=3p-k_+`m>;nQL6Px{+Ue8rNG5zJ)_S5nc(2v!a-4n%sn)q40*J;eFl1$9vafH7rtaT&~r%Gk;~0$71Sw}!jGo^J%5vRs}dR@ugbSc2DBb~q@|UOOUP@T@<sHMTU6wSk>;|i*+AA>t?)E+wYL6nztdMLaQ+)rIb9va@p{j-keX)=W|Ypiy-g=Ef6Y<n&pxRWHAX2Xxmz294n|X?Wza5wF+F@)a;#V3yf&`|?^Q18HelXkxFAK&2>|M`X6Sk34F^V`wll4Q+T;ts-Bgg<eGbpw)m2H_V3oh0r=jqNihiaQ=&sw{r51ZDu}U=wl3Kcia0x+*4ox(XOzf@8><<vyTF69=ZF5MRAH&xXIJ()hT)|!j#TSteuLmk6N3De>l_#W&QgTU<7Z1N2f#n*c$1vK~I5?l%e}WVa&Q#E`M{l;OFSk`~NpD*M-W=hhxPtsFb+O0Ubaf23|D)ii$+c3{DvnDjtH%HNzt?}p1L^a(e1%EU@@?dnT|AXnVS33^"
    _t = "c2d4e2eeabc950a6445f2d031d28909ab707f62b149a8b3c93e5b671bf47116a"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
