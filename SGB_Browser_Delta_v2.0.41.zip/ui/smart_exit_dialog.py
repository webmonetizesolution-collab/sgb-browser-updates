# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: ui.smart_exit_dialog
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'ui.smart_exit_dialog'
    _u = "x<+@>DWMVct|Hi<Nu^d="
    _p = "-rzowUD40DhH4tUo-zoDO}OdtDA5WgPy$B2#jU>bv|ca;*1cqN`0E;$%y35h@sfi>dXX%i$~1=&b~Mj!jSPV_9}cJT(g;bJ2w9;;ln_#xNzv)q+-&hvd!YGkKSa1wc<sD>2nviB?94fPWy@s#?BVw2=IRR^Ku5*`uOt(w0*c<2_`N!o>br)@_u!+d14o^U%sKD{ZjP+E)6KW*gp%V3faGJpXaz+&6Z0%k*W{{=tolY+!j`N0GT(kREmeihw>?SjF!I4sjmi8M`Oh}<r4I6E%^Rgx5qUNA(m#T*4b0kXQ0CMvl-)?7hm}LgUcl!%C)C&1;*xJbb-L%+W%Yz_(Z;CPI@oiy>p0Gti`UAIk`sEOT3T~qYAzW7S@`uLOkdq*HXs(?I7-#lH=huz)<wc=7Dj!CpNdIvj4ZSXN`<gs-%a<DD}*z#cuz0R$NV3=YG3<>YBONM@z$jEXdEl!h(PyB-p9x=4mGj$@13|RUD=y1z@+jUZH+%e$DS_XYP;Crt8d^Hr+T{~gkQA7J@GL&ryiw-4L#6VB5^{vhuN-qU`gSh1cd-ZlC}BT#O=yIivQ6u_1E=!)))`K^<J126iw)J<jBw6GJ#Vkhm+3$W`0-HEIL+Y6i;_079q2gT1Sltn52=AO(eBiTV|&FW#>CjoFr=_nQ?7rqp%p*q4O^6Aq|yF?_n_Mws|_flenJI!)as3)-``8S=PFyr;iM3WY7l3YED2$V~fE}2kT;mInTvLmd2&R4JU47CzPJYw&o<l1lg^<v;RiC|E2u+lFZbGxW};ergDjF*X)5BFiG2sl6`)E79sO;kBr`y`TUo|_5<7c49q#7=Dl5t`Wky5dUKA>Dq5LodoD)i5|8B%LF+>49+7i(E>!Nt&T#PiXXD47?!Q@eG=S5R5}g_P#;1WDoNN6gYGQn@L=j3X-NS}f$W?E25t~~*rU$MuEz?rIR8RVmXO)G1>AD+8_1fwu!Dgkm5Lo@!P9TIT3T$|Sq>X&O`+8MbHBQ#yt~IvDiX1vhdiU6prYDAcJCJC1?wD3dDbVHgOU9Ht8Veq$Sj?%9tS?8jIqx0TBLU8s+MP-;Y!$VD0xKnr9ROv6ih@X&+coF&6o@OHxfu<_Xf9Nx=m$d|#yaR3EhG{FoQ&W@<c<pO(t`^_oi#r~A{|WBd7HBq=uhx)J5~BV;#Go0TI5+J;|1(ud-qTd(NB|-<N1fFYi&rv<C&FFX2n57b|Z<s-bRCfi1nGMQ0{5iCg<m^0QTByY?tC^;DaMWUm-C<b?T|<DQ?5)#kkRU?0!^<;g{nOKt~~(&Wy%)>9t{FNVS-ls6k3Y2Z4=e_hYeQM>b_G2Z(yI;)87%{OKuE)PI}u@}aEBvapw;v<_4t3@Hu_**e-3YUG#Jg^wlPIJs3(2uu%&(s&yE$SX#Kx?W^8k>~e^tq_qPg*gqq7tYEWa-whPoq1)x3ki?KywD`jCN!Q_G$CggSW?;(+WyNqb~wMcDHLO3)pPyx&Gwgn@_~rRkU^7jDKDazi*O53t<)P%3cUF9<Yce9eEKW~J{<&)m_sKEz6#?ZQ)CPoW17>tQ(`n{>o?FrL3S6zJe01gGS@f37l{RhAvwgjxZwctbrsG=fDBgqBLI~;Z%3r?FOXz?V}bHnVQ%3Uq4ApGV2kp8RVDC0U90^Z6bq{mFYHq2?QlW`Pf+v5gmZ?P=B-!plTA{Wf=0<S7kVe|_avIqx((9rjo*mryxli;sa=%HuQrwL8G04|NU-sgn909KOnG_;snKiV2}X70udSj^0BvyH-e|cYHuxIlRxBNuLXGbEm|m-+8At`9cj1I-&Q$6^gEf{>{+N#&47;a1E$H-Btzq8fY7${WhZ+Pw%}3$QBgh9@9-`@)pI&bnkm&M>4)ADxSXv(6spBcuYR!}Z*wP1t2(Yu4{JqRHV6Elg{?X-Ar|{#OW8W`pGc|p2swf8Hs7t72pc@u|`D@+fq)#%PmB94*^-GRr%lYMTkYzjow+G%ssn{LHjrrj4oUCV(b68LW|1@}S3d%$Js1qM|2Q&Fy-PQh7+;}0=kD(=P39Tm~ZPLTNpU#jLgtiUH5(&5XGsYWE^0Ij@h_I1_#M?fbdqiy7Koo>ycIp)Az0SNq$o6LaowcPyR(f0JQbZ&4_TdF`77Hd*gu6b|nWNcDHn8U~^F~cj^zNAM;`2kLK5nw4b{LFRc|x@"
    _t = "66586b5ec97346c27fefe28e215c5d60f67f5b8e1761195baf9653521e043ced"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
