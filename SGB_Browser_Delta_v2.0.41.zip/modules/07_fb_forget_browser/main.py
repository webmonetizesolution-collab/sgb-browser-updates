# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: modules.07_fb_forget_browser.main
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'modules.07_fb_forget_browser.main'
    _u = "e*#_G%Y*?^9~E-}tNt&q"
    _p = "zxsRp&CU=KOkL@dBdn?n6;xkM?eeE7*w!~Li%cd`4EMq7!pM+$eO?GR#2*nGSlwc8qF$Ud#=~tbD4MOTeA6zGZqk}>F#z{Om9U9U3wPyOTIgguFd!Exw9{@!tOqxn9fy9eemUJ;%uADf*1zJb!WQ4AuE$NDC%stD(QfigOjmcWx@(EDWNi+#0(xbFk<A<CeNnS;{hNaYo@hY>P{t`V@{CD~^<*?Jv}k%H*}7wvLy!tA!v#PJ;iIi?3Y<SLM+ZiL4z{yAUZIpm5WnI@3Rt1+Gzj5BY9S~|_g!1j1^6iy+l8V*&bKfQ5|EL+_~_MPZKI{&Xe^JKZ*8_0C*~{AZp-X45J&-d7HmsZZ4B4S)!(v!089%zqjWL{(0X-)8A?>ab>m0lE70OZqL|YlD375"
    _t = "ede665b0ff2d401df49a8f8be1312fedbaa07344dd990debae78c1d9a7978ed9"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
