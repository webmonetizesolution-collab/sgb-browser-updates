# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.license_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.license_manager'
    _u = "Jj}R^nUaTv&8A#lxL_F`"
    _p = "QN*K!Y^LV!2aE8{KllqvjP~nkR?D;r1+U<5O8m|q?0Y_QeRtyB51CgK4z%%#+H+CGKWdn=wcl{Y@h2n(I-i}MCzg4A^J-#i7FiVmMelt?SGo;q?>m+~<VjkA8#TcG_{u+3t^n4BZ;O0-opID}CwdD@;DR&8>i<l4*lJj~nEcd@&QkLrLbs4}J=Td_L*vLlr(WhTFJ4S$?6YL*@Lww|)O#nspk$G|OvrJ=C)+xZ@h}cW^hn+PpW8RFuj1!lsyNd9gHl&iGmpG$>40J_{e2(oHHVOtMfypS_8%7XDyMKxVTb$K`1nSJF}FYKzt`E6%To&vz%S=bH)Ie(YiASEmHdXsC{_F}n~}wkK14;(8SqzWxL_XAihEGB^4BO<z(Vz~Wg_RX6KMbW6B7REptcJu#rA7^F1a0uHnOJ?Uhc$fo-C*Z%*m6dR*2d1J!o9$=|*R+U4^pNGT?C93!<9K6cV@zx=l-8)~MP?{B$aX8%zGjUhRrqebVwqraIa{OQtl#GR<l8J_h^7;nywRUl5&OBpfY*JA=o)xHxI3Pmrc$;0}*IqIO;UsVo`qdosq2+bd&Y@j%j3FMk+}j4DF_LDH|ZwZ)vU=|e37@^nAh_%hS2x^6%iF!?};z_K+YkYCkt_;V17qqs=Ju#7jU31|n{St3PLcP!r`3L_=&){E3R9$@AaVqg4be^AkoC%U<gNY7Zej?V->7r>IGcvUi}W;Hxy)6dPLK{S#APdtO)7YB{1gDW*<7R#<aZn^!1pXSaX48mv3Gi@yPiG`0BRnI_*#N*T^Z3RRYkFS;a?2>iQtO^ahba+tm)=#}Fyvhs)^|}&I#Y<63$$_I9JKG$jZz;_L>;u0FxXv$gUDYD*k$gV7;5G=J1$Z3S{=M}D*xh?nsy?Oh^%>o-9~$@+>KyOw*^)phU-C~#ak1q`0JeN-j{RK|*$;Cez;1$_A=pnBI?JxZxN%YBv(;EU89-+O*2*j0Y{EtEo-Z`+6bK(;0*sc7c9_nV%f2sjd8kwbT^<bk(&~Odfm%8;7j<A`ZoRs|FcJP$+nSQ9{Y4V@!L_zH(+#hB2-#wxAWG-kwp>bMu8qh8Qf+x$5gEdxd^~QF*m6mBKfB2d^fH@Grj=F`=CGxh821`-x=q|RVq28*7LsUC(cvog<;*e58$C;T6^h@x%ZXj+tMb^P*T&ek9qYAigLHcM&-m{PpC8oQvTD`c0nYKr)5y~~LYKc2I<UmbXt5#e+)U+Q$uG~%Q*@~`?+yoGzU<c9@^su{;C$}EFBWvhz0ULt4Q5sA{^HC9Y${Iur$bf2C1r$LI0u@(Q)*32af>2sle5fX{T=cyUmL+_+-mvt<?IK|D>?DcoaUgzrgOr=_>1`50(jtne>><U`SFU-a}37)QOWe9e7~x^m_1FwCpIP%7EzJOSt}KanV296AlRzRDNCU!4I2{P<(v|9y!R<n^b|wsN?I!v&wZSlnEX)GpmRs;!b=j3y4`b3T9_ou0HFGKllSE`T++j}9{R_0mI7<D=S@F`!Xx+3wL(=nHGEz?liQ*L`9uuFJQ$O}ES~2^Ae8?-eYO6JrL<Cj${O7w`#$6w7t{l$!~bm~9$boTFv?mTr)%M4GcCg(VmK@ow7QRX-NFD*6Vdt}cE+vs84-L8)T715U*~Wo%hvXiCsX)+Es1POq6P-FO;#SSt7j(C!*P5{Adg|``eKJ2R^wd6z(&~Do=9+|PXvu{8L8j`Lra9gDd##-8O$@<s{I1bv8qoKxbN+<vC0CPB+aC3Z{|>jzr%J8Ob{WQ<!+dX_KH+Q<h9mF$Z@@IMF0H7#KR{b#r_Qg@Iit%#tG%t|G%&_Hg~wh1MN&(>9~deOW(+z88-R{BP{S)TUP*}x&CE2IiTwm6B!GZb3eKKcBN27-_7_eVw2A&%aXlAu#A!)cOiG#hl!(goPu=i8Tqh|5DO=p(L1EX2?P$HHiAwf&VTFTv0&eqUfQ#URyr3W%|SR3W=Zo7>H!PD`M)G8(zcqIgfA-b%L>^wNCr8$(OWjv#5P^JpZTfHrBsQg?*g)Fi&{*sD5}%lb@{+0?6QhbayMY^2J*3&#W_n!KjS>B^8Kk`>cxVomwRfR#ki?N0m&{vGi}b80jN*V&miRBX_c!Wy!Dn%mc6v%It=CK(Lf{TVJc@`1I(9!E#b9tmD9YyF$mSWHDUF%%It%6rei%LO87ig{WOk&q;>NKB;Qf&-#S=IfqlyEoE^+~jYbS{zvv<?M0ih1b&_h-qaJD!wl#UhOpXCqL0^ef`}Q9p;Dncc<c#4rp&*4wLgDmHYFXuty5ktRUL-zOr+qDzD;D(o1*A5^COJ4twZ_kbe@^w46!e?>z>ufovZE5hhJb+dYof$t+%Ox!&+|Hiz|%r?jv^^}fZE7UKsXm7zE}>Ml^3747FYN1H^QayVPb!G32Cw}f)F*KdHJ4@6`?^pez~{v6G#+M&Iq?-gPe?t)OWNcA3TXj`qP`{se))JOuM-sIs42^n38e#G(I?<-Z5h-iGwd$6L_wV1FJnlykwQCp;=Y~MU72&LuJBaiqcUY7`kVM9v&ds#kZ|F<+_e%O$rE$BN%QK2TY}HZugga{133f2<~&II93HfLiOWX^a)h%wrII_<!LEBd&1N6xJc_gn-5>RsY<=Un>Wnd))=s-WL-OqUmVUyyvUbTketk>(Jraj#QPfju?bc|(@Vq8fmY&W?{BA8*GI9HLPgd%=%R+WXSYAhDzEvH8Cvi;jWg`c>D&^14{jTvJT;@B&e4;NjvS>uGgW4^sQxXlco1jzR{YRoC_8+B!dq_vq#iS&Oi?0hA2Z3nY@7i>+(AN9HIJ%|3*7&OvG+rPb6Z;?syt@6>zs&3^<{MiYWi(eblHgbH`xbHV`hv#0K(5C_$Wv$l+R&CE{;>K_YGyb^*uNwor1I"
    _t = "a1cb182e8c7fa4eeb50ab09f30e6869e86776324d64c2a72606e0692668f0145"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
