# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.bookmark_manager
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.bookmark_manager'
    _u = "TvhISKwR%Fh<$q8kA0n@"
    _p = "e;`AH-#Dq?!lY?P)w768)A3-FR-FD5%2Q<@31=nqc|uesaBBdsd#B(^T3gL39GKDG7TA#h$KifWTtm;XBJZG!Dr_}w^wM;-KoorA2MGp>_Y%@dtCXTJa<fz<)8vu4--|!9r(jOIQ<5!v5)7ueRuuaEkJFd$_Iseg$wb*Wv_y6iGHd{H#0@xvH9IihxCv6loMT8KaUMDG#85yy1#sSN#E0YXR6qG)1t!G)MQ!U!O-LAsVJzRx^Q&B`DLn?hmEK65P~U9yVOG|&@>3dbZdF6b4DVw0-jTRYCCOCZ!$P~54VAW}`YuYzi+3bFIX|Se!eI|(DMRBYc|Pbz4|*{#z3qS1>hzXB-3sbE`sD%pkrd8_<Jwr3XzlG#6aHRzEZ=xo6<}l1Ql~;GDRMhi5y1*OPGaN?m$W<uN)o?iihi^0ikpf!#rb4J>*1j_9R)st=3QmEIopf|@3!a}HL09BU9XLFXAiE$hhxed1J|@Byv%WWR2lyp4=3`<959B{Zy8C%yWHT;L??aV6R5#C2m}Gcs+t^lOoU0`7%O@3@moAgBT)&NKlFUTG&YJ~Q9I3(!&S^=xUa-wsb4A`a0&Rm#t*C%>T>oYMMYGEPrzG{kD*~DG5Taa2H9|px~dwmOOH8_J*v3KX{};McX+`$-gmHn%sg?@`XQL%i07UqMr{O6%-`OrY-!*l-MZVS*_Z8um{nnN4JeSIl1yRCmUe}R|IM`VfaC9avr`;|njcF)@26*P^jX>$@|dqIfJER^fkyD-_jr|rIK@gDEHBuq;;4ofLs!Y<UZ9f3+fDrQK+C~e>$Ykd86|tz9M<)eDHRz%AJ;$(Cs0k%LO0-r!(9kNyu}Hf3Ny{`HlQEv-|njZ?yJXyM+d04yBMKBK_5K+)3!eLe`P8R`NVWgDPbQl(4WjrtfZ7jg3)2<ntdtZk(8N?J5zyeYO9ox(=V({?J3!r-@W8WZ?t2Z$l;Mj_4;C~?}GtMBr-<l{-|unye5hJJm1aOT?RGnDPGS8k|QWc$Ii6R%KgOHES#c|&R{xrQ6ASh_Rdf?foxR#{|Ho3J#lh7=}d9$=+)P0EzKM7ZS_QzI;MUA!^5*nY=MC>Zf9H$U+)+{jVPv}d+Xw)gR+=qNkT6;Kf&#|hLP{pGGD<!bSmen4eQs$CzRx<IeH<CypUW_N}w~;Nqk+F>ta4fgPZLvqxTYEJkKkT--j2>9`$h@`C`y;Y*Z(6o48-s69S!Ae=tbzqNEJHCNzXo+Pva$kpaTVuW7-DU15A5jrMz`=WWTB7UEh*D&@sxeYiZayfjx?$zH{*Aaid5+i4U@C+rgqIjGH^yM`-Hmb1tp@$A+J69)OJ%xC#c0}D`O5{rsf3geaCRUUCN4Q=%vwPM~QW(|fAUj=^@hv*^zejVTU(iA-e`2Oh!MrTnY)&6q{bvA%c7jA>)OR0ke^TkZq9A)ka4L}>B_-}hH(@oRjg(g3HFDL-cM~dKNQ4489I5^e@-Qa5+*c*8By`P_lWN-rKMabg;5)7G)?1=A|KUu=nw3Q#w5=Ey3n2k$AYM_W}8YkGNn0J8SP+7h56KzUF5(S71+<5O(%~g(i8c3keFJY2rwg(+m4wrsR#FP?@6Y02?+5m>5O+$YJH_vdA`#;%XErMsUnHHh$%OxuLH$7hPXgQ*TLO&;MP>#0nDrm*j6MvqcYB*o#YBKU$iMV^)1AM3>*MH%D=6^BuZuUTWzG(FnN8*=h%uyAPYR~@ResnLhxYghv6p=PF%~$t(4EXRkrVYY6XKWQ?yU+V~A8<KPUr--FuPdPV<#lC~)@O!|5V4A}gUwjGh#;=uiBH?3TO>rET`r|Xb1fZaw6|y{A#am8XMku4&5W(;>SQOUMX<=2gc`(70@=A|DFTON8V8f%X#<)*#s-NaOoB7gUzTZPxJ`dkf`+?(2+N3dDo(z2*=p-Hs`-Lm5Fh-19l<+bSR&7t)H$y4+c&w>_Qpv<bf~r8e;CYRkuOor?~0uz$UskROy5%-V}(JGo}-2^xJ+nO_h8l&#PJb10i`Ux#=o-;QeR(6j?7b~#MVZ^M+Tk?@h!DL%Cwn(ez8zi3N%n`#M8H}=xgYN=X5T3%L6%|ZD*c_)^P{2>O{U{_occV!=&;VJ0+4S6lArT1I3lF+VTh5+>-<7#ydVNF7@>;h(=xBea|$ag7B@fvlM2ueiQRGDjzf0-@6m)w;=YnqY4PaUoj5@(TmpozM|<qB~*R!7rf-T`<kLFFM0&88B_q#a^6d+r>vshCbTVN_c{IQ^h>Zc>0>wt|H^>&6X&0|GC~0V)cV6}Pb;ljyP0m74q<DUfo=p?>mLLVEswo*l$On<EWSFlu@qq1MhaMD5rB*52HxG^-X!O~He|7{XMTS$(WJD@A3dT=EmL+u=85&{RAifmV}yuI_AEAHsrEVfPOK-`wxU@0=&jDLSL<oq^PVghj1Pn{lA9UB9$mUIXBa93;aGf`Bk-2Z&aQB)z>ostScYZL2rEr5uxL?_V~0)Cen!10d~{^ftvzQRCi#X|47x?0JEO?die>$j&GHXnrBmR+#3>Ob{9+gpLx`3m<Q4SuFKyx=>ztyHZY+<@Z6o<0r<y$A+^UeD6HXTyO2XQ_tqQo>#&Y*VwTVWDdGC!dJfqadJ(AFN_8XI|_h$p84eH4F-x(|TA&#%_yF4|o-9jUgP!_vW2|uA!bW}$^X@KI_zei(*Bjr39zbzqw>aA{uKxIf_Y{I=NlL*53Ut990(WnI9)TR!5>uzNHw@iq3(<_ry6x2^ip(D-gg@U^%+&n3hrnj)}Vm_{l3oKU-;Dq*2AgRZ|qa)RZ=Sij9*30v3|M&vTq#qSSE7^;1WIqbD-)l*l;V0@Zlb{9%lMU+i4L3OtF4O%lQE*m>;QoqDy%peNt@#CL2_M;m8(8MRl^pdYr`tkQA4SpFhgCWwzY3Q`4}PEe48SG}vg~a2^;)~0okhm)mDMwihAn;Ii8QC=ha-yHqzk+Jky2Aknevv}5sdQ5T1(zTpWX=42Nfp07ZO}YPl1G`d&;yo7w8n2R_4TgH+2GI5^2ef&_-DCF@bK2@I;NLrw9zw#!yUh3n}QQFFx;~x0Mi7P$`%XM*su*@{2Pap3#dL>|FTXytCA;P~ht&vhZ7l5*-1pRRfA>4o)4h_)TXZP>fXfO&j)(l7Jnx=S-4=ug7z8BlhLU0}=kP{weCbUs=FhD>pL0Lb=ULMhoV9*2}<f1f*NAe^wRdPurq=V`cc|Z=BRbN!=(IEjJqc-_ulYCW);pekeY=4zV$}_J<MNyRVw<*{CV}f(r(iVLb7>_K2CJaD8Aw@k2CLK|8+OIUox4DQ#6jyWo%_TJR#z&=<#7v$1q8Jp=6ALI`%bsrM|OVc1nV*XY40Es!@JQN>*8js1-RG^PeU?U)t#7c7!Sd`IbJr$pa55-a>Cv(^;&^!CW?SW!)TKRt4+)xZg(bvu`NKe!i$GBw!MGW1kTYHtwMv)mLxrL;0SqQ-4eNIwfQnQ<hpXMG#v@~5FludtnZOhL}CZ(>J&nCOwixXuZqyA)Gb{5Tl"
    _t = "85690ef895d2d7b460b559290d83d36fda9845e8dc50f4aa6ee6fa0a6f880c15"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
