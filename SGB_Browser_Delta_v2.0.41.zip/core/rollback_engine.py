# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# SGB ENTERPRISE HARDENED SECURE BINARY
# Module: core.rollback_engine
# Protected with PBKDF2-SHA512 Stream Seal & Runtime Memory Hygiene
# Copyright (c) SGB Enterprise. All rights reserved.
# ----------------------------------------------------------------------
def __sgb_boot(_g):
    import base64 as _b, hashlib as _h, hmac as _hm, struct as _st, sys as _sy, os as _os, zlib as _z, ctypes as _ct
    if getattr(_sy, 'gettrace', None) and _sy.gettrace() is not None: _sy.exit(0)
    try:
        if _ct.windll.kernel32.IsDebuggerPresent(): _sy.exit(0)
        _dbg = _ct.c_int(0)
        _ct.windll.kernel32.CheckRemoteDebuggerPresent(_ct.windll.kernel32.GetCurrentProcess(), _ct.byref(_dbg))
        if _dbg.value: _sy.exit(0)
    except Exception: pass
    _m = 'core.rollback_engine'
    _u = "T2eTkvat;?#B2Z@?eoIo"
    _p = "$i1LY$rdt7XV0jtB@Z{4)wjF8k<~$OpPKi=@K=t9Z>s+;q26gR*ne7pn!ma-*URQoiIu7l2XnXcXq??5;PAk*%mH2P5cM@YPTfcx=AsuHlVU&H>kQ>kfA~-(Czkz|wI-_&d46r8q~aT@H&otf*UXv?i(|g3(2SD!=qy&Q2<~z_*uNH=Azqa^e7;Z+#9@8>hU^L~-x(Orc<lFu!FdJXXOoys80@Wl>(-cy7cqGXMEQ%UnbDe)UZnfFX8YR9JX~k-<-`X?sK4aYe<Zl0ry>gt&f8`(t&$Q;8+PAQcS&ov*Z9=Hp@-_r0BKp3lS*?^Za7HIek^;)zR}qQAY3pUZ=R`I@$oNM*8c}Fr~kGRJwYYTiej!s@(RzwyJi?ub{{Ccj89fk(Q0J^L}>CVz$NcMa?$WN>+ly=W}-(7{aE0xUlk{InR<J&eNERAC*7hd`O}Q&*2d-4C4M7fMozgZuT*ZbI~#41CLI2khghz0)P18@sqR}0w6I%(tl32?-@rZ1n;w3bA#8Dc&xjA5>AU|mI|lKV|2ZkYgLwcdG;_`ZDT}N0gWXE<cef<O17$a)vVGEnJA#hf=-HIYd;%a%mUOOYh8EQ1u4?_H5R9$#6=~pPlOWEG(*H{3i>&Tk;7MxRa_T<5ivAQ`t}vwiQX^X@B2q!NyfqT0n2oO;^6nF*qNX?2mCN_8RLwyunTGbjihQ<MqoD<y1C4xv{`~OnahUH}AO8pHLvn(@p@V4k-=$mai#B&dm<kj%F@^Rz0j8N<T4oNEjdf^Vi|=Cqd(s*8cdp>klZjPWG>AQ$uBG|?wq{q6@M>pqyTI{vLL94O$Ykm;{ALeZ*iv&bGTJuK=VbJ>s1cW6LurMXlvc;DP<|Jv&|zSIXParSocHzd3|J`{{1y{zG(~7^BcI&_YK&B-B5cAfVe)a7e(~HCm;yYti1C77OXdGs;oHZ?M<YO<6zIy@9g_F$;HybD(grz^x{FK}HnA+(ngNrdB0!!{xlLAls#Tk-8}u$T@;h{Cg%vUM5M~(@_1z{2$KEkw3@NawFc>UR;pF!h;K`@TBlv7v)rSp9hZplb{}WdOU-*mL&joWj-QVya&%~#0x2RoUe<6Qa0S?V&->IyGDSii+)?4Vf{@94vB`egDiedg(taF7&bPPq5Xnvr_)e6LTM}lJ?NA1)PI2zqU``|AbLZx(Ud>yZ(d$%^zg2lZ@nohMs^@|)CopUG_jN*aER(hM|5$oTxhNSmqp8Y|{Z=hk~RilLRx50s`|MjS__v<z?Z3s8F7EKKu=AQoT3Ixp?n|Akk5Jagu)19w5yFn0|`Td6T(&mdF2L!$ewyY1^d=r<av?aWN&@7axZRQ>Zmu$OpF7p;1ADc@x?oK;bjvh6X5Q4Fv$AfupAAG2>=j|r(&u5BnF?H+~vJ_C(^mH?A6WdI`CdNvV%&)#GxcedlO`JHoa1%1oPp?mV;M9s{za;Ldmrix$d7FQ#z&AsUuc4sUq{X|4*$`F8n7lERc%gY-(l|ulp=~UTA!96pd#(D<&e_{`q$N0Q-{o<b$3+-QQ1Ke76l|Hd<7I^jZSZ*USn}1Ws*Stm_$}+<HyDahplgcIIMfDG`b&<F7n7g4Fj8;82#2~Hz4Oc^=BV8JGl`)A<Pnw+lHXZDO83<%rX&1Amee$(oI!8=691Wl2KgxSD-06ZN$=V{HSMbL0(AY7Sk2SUoW+YBd2mbdT)#8)7s@om%4tD_>M?2n=LEB4CH@&YlDKA@6xl886<}r*Ryeq1M}1g5X192qzjA#ac;&guB>jg8Nv~Q(&n$3>UkLstR#}yj#vHL#2Nl0Jr08X2j?NZ=ch2=g?$tZXQ2=5l+*cr|pm1)whz7X8q+;?Kks+E2TOBUi&>_eHyM`r?GueD;5v$MmQ1K;x8aejF{47J&E=lFxT3_NQEe4|"
    _t = "1f688d88f20840a4a697fa05ce783f6e1e6c5f15ec5670686bd922d5bfa97761"
    _dk = _h.pbkdf2_hmac('sha512', ('SGB_ENT_V2_SEAL::' + _m + '::2026').encode('utf-8'), _b.b85decode(_u.encode('ascii')), 12000, dklen=64)
    if not _hm.compare_digest(_hm.new(_dk[32:], (_m + '|' + _u + '|' + _p).encode('ascii'), _h.sha256).hexdigest(), _t): _sy.exit(0)
    _c = _b.b85decode(_p.encode('ascii'))
    _ek = _dk[:32]; _n = len(_c); _ks = bytearray(); _i = 0
    while len(_ks) < _n:
        _ks.extend(_h.sha512(_ek + _st.pack('<I', _i)).digest()); _i += 1
    _co = compile(_z.decompress(bytes(x ^ y for x, y in zip(_c, _ks[:_n]))).decode('utf-8'), '<sgb:' + _m + '>', 'exec')
    del _c, _ks, _ek, _dk, _p, _u, _t
    _mf = _g.get('__file__') or _os.path.abspath(_m.replace('.', '/') + '.py')
    _g['__file__'] = _mf
    _g.pop('__sgb_boot', None)
    exec(_co, _g)
__sgb_boot(globals())
